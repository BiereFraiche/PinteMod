# PinteMod v1.0 — Aide rapide

## Menu

Utiliser la commande Chat configurée pour ouvrir le menu administrateur.

Navigation :

- Touche 2 : monter
- Touche 4 : descendre
- Use ou Reload : valider
- Mêlée : retour / fermer

## Musique

- `!music`
- `!music 1`
- `!music 2`
- `!music stop`
- `!music status`
- `!music states`

La musique est envoyée à tous les joueurs présents au moment du lancement.

## Events

- `!boss`
- `!boss <joueur>`
- `!margwa`
- `!margwa <joueur>`
- `!panzer`
- `!panzer <joueur>`
- `!eventstatus`

`!boss` choisit automatiquement :

- Margwa sur Shadows of Evil
- Panzer sur Origins

Le boss apparaît au point visé par le joueur ciblé.

## Manches

Le verrou de transition a été retiré.

Attendre simplement la fin complète d'une transition avant de lancer une nouvelle commande de manche.

## Noclip

Le noclip est désactivé dans la version finale, car les méthodes serveur testées provoquaient des collisions incorrectes ou la mort du joueur.
