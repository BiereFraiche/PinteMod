# PinteMod v1.1 FINAL — English Edition

Created by **BiereFraiche and ChatGPT**

PinteMod is a server-side administration framework for Call of Duty: Black Ops III Zombies running on BOIII/Ezz.

## The administrator menu

The HUD menu is the primary way to use PinteMod.

Open or close it with:

`!menu`

Controls:

- **Action Slot 2 / key 2:** move up
- **Action Slot 3 / key 4:** move down
- **Use or Reload:** select
- **Melee:** go back or close

The menu is dynamic:

- it displays actions allowed by the administrator's role;
- it uses the currently selected player as the target;
- the Music category changes according to the current map;
- the Boss Events category displays only boss types validated on the current map.

## Installation

1. Fully stop the dedicated server.
2. Copy every `.gsc` file from:

   `boiii/custom_scripts/`

   into your server's:

   `boiii/custom_scripts/`

3. Keep your existing `hotfix.gsc` if required by your setup.
4. Remove older PinteMod files with the same names.
5. Remove temporary diagnostic files from previous test builds.
6. Fully restart the server.

No client mod is required.

## Default Owner

The default Owner display name is:

`PinteMod`

Change it in:

`ezz_admin_config.gsc`

## Important security warning

PinteMod v1.1 grants roles by **player display name**, using case-insensitive comparison.

This is designed for private friends-only servers protected with `g_password`.

It is **not secure for an open public server**. A player who joins with an administrator's configured display name may inherit that role.

Public server owners should replace name-based role lookup with reliable XUID, SteamID, or another permanent identifier.

## Validated boss events

- Shadows of Evil: Margwa
- Origins: Panzer
- Der Eisendrache: Panzer
- Zetsubou No Shima: Thrasher
- Gorod Krovi: Mechz
- Revelations: Margwa, Shadow Margwa, Fire Margwa, Panzer
- Moon: Astronaut

Keeper on Zetsubou No Shima and Crusader on Gorod Krovi are intentionally excluded.

## Special music

The Music menu sends the selected special song to every player currently connected.

Configured maps include Shadows of Evil, Der Eisendrache, Gorod Krovi, Revelations, the Chronicles maps, Moon, and Origins.

Zetsubou No Shima music remains disabled because its native music registry was unavailable on the tested server.

## Noclip

Noclip is intentionally disabled.

`SetOrigin` did not provide true collision-free movement, while `PlayerLinkTo` caused player death on the tested BOIII setup.

The command remains registered and displays an unavailable message instead of risking player death.

## Validation

The release was assembled after real dedicated-server testing of the core commands, menu, map music, and listed boss AI types.

The included build also passed a static structure audit. A static audit does not replace testing on every BOIII server build.
