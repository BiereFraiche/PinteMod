// ============================================================
// PinteMod — Chat Router v0.11.0
// File: ezz_admin_chat.gsc
// Created by BiereFraiche and ChatGPT
//
// Chat commands, role permissions, and safe routing to
// validated framework console commands.
//
// Special music and validated boss events are integrated.
// ============================================================

autoexec function init()
{
    addcommand("ezzchatstatus", ::cmd_ezzchatstatus);

    level.ezz_chat_prefix = "!";
    level.ezz_chat_loaded = true;

    mkdir("ezz_admin");
    appendfile("ezz_admin/chat_commands.log", "=== PinteMod CHAT v1.1.0 loaded ===\n");

    level thread chat_bootstrap();

    println("^5[PinteMod]^7 Chat v1.1.0 Music + Boss Events loaded");
}

// ------------------------------------------------------------
// Bootstrap and player monitors
// ------------------------------------------------------------

function chat_bootstrap()
{
    // Allow the stock player system and the autonomous config module
    // to finish their initialization.
    wait 1;

    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (isdefined(player))
            chat_attach_player(player);
    }

    for (;;)
    {
        level waittill("connected", player);

        if (isdefined(player))
            chat_attach_player(player);
    }
}

function chat_attach_player(player)
{
    if (!isdefined(player))
        return;

    if (isdefined(player.ezz_chat_monitor_started) &&
        player.ezz_chat_monitor_started)
    {
        return;
    }

    player.ezz_chat_monitor_started = true;

    // Ezz BOIII emits the incoming text as an argument on the player
    // entity for these client command notifications.
    player thread chat_watch_say();
    player thread chat_watch_say_team();
    player thread chat_watch_chat();

    println("^2[PinteMod]^7 Monitoring player: " + player.name);
}

function chat_watch_say()
{
    self endon("disconnect");

    for (;;)
    {
        self waittill("say", message);
        chat_handle_message(self, message, "say");
    }
}

function chat_watch_say_team()
{
    self endon("disconnect");

    for (;;)
    {
        self waittill("say_team", message);
        chat_handle_message(self, message, "say_team");
    }
}

function chat_watch_chat()
{
    self endon("disconnect");

    for (;;)
    {
        self waittill("chat", message);
        chat_handle_message(self, message, "chat");
    }
}

// ------------------------------------------------------------
// Permissions
// ------------------------------------------------------------

function chat_name_in_role_list(player_name, role_list)
{
    if (!isdefined(role_list))
        return false;

    wanted_name = toLower(player_name);

    for (i = 0; i < role_list.size; i++)
    {
        configured_name = role_list[i];

        if (!isdefined(configured_name))
            continue;

        if (toLower(configured_name) == wanted_name)
            return true;
    }

    return false;
}

function chat_get_player_role(player)
{
    if (!isdefined(player))
        return 0;

    // Runtime overrides are assigned by !setrole and last until the
    // player disconnects or the server/map session is restarted.
    if (isdefined(player.ezz_runtime_role))
        return player.ezz_runtime_role;

    if (chat_name_in_role_list(player.name, level.ezz_owner_names))
        return 4;

    if (chat_name_in_role_list(player.name, level.ezz_admin_names))
        return 3;

    if (chat_name_in_role_list(player.name, level.ezz_moderator_names))
        return 2;

    if (chat_name_in_role_list(player.name, level.ezz_helper_names))
        return 1;

    // Backward-compatible fallback for an old config file.
    if (!isdefined(level.ezz_owner_names) &&
        chat_name_in_role_list(player.name, level.ezz_admin_names))
    {
        return 3;
    }

    return 0;
}

function chat_get_role_name(role)
{
    switch (role)
    {
        case 4:
            return "owner";

        case 3:
            return "admin";

        case 2:
            return "moderator";

        case 1:
            return "helper";
    }

    return "user";
}

function chat_role_from_text(role_name)
{
    switch (toLower(role_name))
    {
        case "owner":
            return 4;

        case "admin":
            return 3;

        case "moderator":
        case "mod":
            return 2;

        case "helper":
        case "help":
            return 1;

        case "user":
        case "none":
            return 0;
    }

    return -1;
}

function chat_is_admin(player)
{
    return chat_get_player_role(player) > 0;
}

function chat_get_required_role(command_name)
{
    switch (command_name)
    {
        // Owner-only runtime permission management.
        case "permissions":
        case "permission":
        case "perm":
        case "setrole":
        case "removerole":
            return 4;

        // Admin-level map/round/server-impact commands.
        case "killzombies":
        case "nextround":
        case "skiprounds":
        case "setround":
        case "power":
        case "pap":
        case "unlock":
        case "freezepowerups":
        case "music":
        case "musicstatus":
        case "boss":
        case "margwa":
        case "panzer":
        case "eventstatus":
        case "castlepanzer":
        case "thrasher":
        case "gorodpanzer":
        case "genesismargwa":
        case "shadowmargwa":
        case "firemargwa":
        case "genesispanzer":
        case "astro":
        case "astronaut":

        // Moderator gameplay tools.
        case "god":
        case "godmode":
        case "ignore":
        case "noclip":
        case "ammo":
        case "maxammo":
        case "points":
        case "maxpoints":
        case "weapon":
        case "gun":
        case "papweapon":
        case "packweapon":
        case "perk":
        case "allperks":
        case "clearperks":
        case "removeperk":
        case "powerup":
        case "lastzombie":
            return 2;

        // Helper tools and read-only diagnostics.
        case "ping":
        case "help":
        case "commands":
        case "adminhelp":
        case "players":
        case "spawn":
        case "respawn":
        case "save":
        case "load":
        case "tp":
        case "teleport":
        case "weapons":
        case "wonderweapons":
        case "wonderweapon":
        case "wonders":
        case "weaponstatus":
        case "hasweapon":
        case "perks":
        case "hasperk":
        case "powerups":
        case "zombies":
        case "zombiecount":
        case "roundinfo":
        case "rounds":
        case "round":
        case "map":
        case "mapstatus":
        case "maps":
        case "powerstatus":
        case "papstatus":
        case "unlockstatus":
        case "menu":
            return 1;
    }

    // Unknown commands remain visible to authorized staff so the
    // dispatcher can return its normal "Unknown command" response.
    return 1;
}

function chat_has_permission(player, command_name)
{
    return chat_get_player_role(player) >=
           chat_get_required_role(command_name);
}

function chat_resolve_player_name(input_name)
{
    if (!isdefined(input_name) || input_name == "")
        return undefined;

    players = GetPlayers();
    wanted_name = toLower(input_name);

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (!isdefined(player))
            continue;

        if (toLower(player.name) == wanted_name)
            return player.name;
    }

    return undefined;
}

function chat_get_optional_target(sender, tokens, target_index)
{
    if (tokens.size <= target_index)
        return sender.name;

    return chat_resolve_player_name(tokens[target_index]);
}

function chat_require_target(sender, input_name)
{
    resolved_name = chat_resolve_player_name(input_name);

    if (!isdefined(resolved_name))
    {
        sender tell("^1[PinteMod] Player not found: ^7" + input_name);
        return undefined;
    }

    return resolved_name;
}

// ------------------------------------------------------------
// Logging and console routing
// ------------------------------------------------------------

function chat_route(sender, console_command, display_command)
{
    if (!isdefined(sender))
        return;

    println("^2[PinteMod]^7 " + sender.name + " -> " + console_command);

    appendfile(
        "ezz_admin/chat_commands.log",
        sender.name + " -> " + console_command + "\n"
    );

    executecommand(console_command);

    sender tell("^2[PinteMod]^7 Executed: ^3" + display_command);
}

function chat_deny(sender, command_text)
{
    sender tell("^1[PinteMod] Access denied");

    println(
        "^1[PinteMod] Unauthorized command from " +
        sender.name + ": " + command_text
    );

    appendfile(
        "ezz_admin/chat_commands.log",
        "DENIED " + sender.name + " -> " + command_text + "\n"
    );
}

// ------------------------------------------------------------
// Chat parser
// ------------------------------------------------------------


function chat_normalize_command_name(command_name)
{
    // Accept both:
    // !perk ...    -> perk
    // !ezzperk ... -> perk
    if (command_name.size > 3 &&
        GetSubStr(command_name, 0, 3) == "ezz")
    {
        return GetSubStr(command_name, 3, command_name.size);
    }

    return command_name;
}

function chat_handle_message(player, message, source_event)
{
    if (!isdefined(player))
        return;

    if (!isdefined(message))
        return;

    if (message.size <= 1)
        return;

    prefix = GetSubStr(message, 0, 1);

    if (prefix != level.ezz_chat_prefix)
        return;

    command_line = GetSubStr(message, 1, message.size);

    if (command_line == "")
        return;

    tokens = StrTok(command_line, " ");

    if (tokens.size <= 0)
        return;

    command_name = chat_normalize_command_name(toLower(tokens[0]));

    if (!chat_is_admin(player) ||
        !chat_has_permission(player, command_name))
    {
        chat_deny(player, command_line);
        player tell(
            "^3[PinteMod]^7 Required role: " +
            chat_get_role_name(chat_get_required_role(command_name))
        );
        return;
    }

    println(
        "^2[PinteMod]^7 Accepted " + source_event +
        " command from " + player.name + ": " + command_line
    );

    chat_dispatch(player, command_name, tokens);
}

// ------------------------------------------------------------
// Help
// ------------------------------------------------------------

function chat_show_help(player)
{
    player tell("^5=== PinteMod CHAT v1.1.0 ===");
    player tell("^7!ping / !players / !map / !mapstatus");
    player tell("^7!godmode [player] / !ignore [player]");
    player tell("^7!spawn [player] / !noclip [player]");
    player tell("^7!save / !load / !tp [player]");
    player tell("^7!permissions / !perm [player]");
    player tell("^7!ammo [player] / !points [player] <amount>");
    player tell("^7!weapon [player] <alias> / !papweapon [player]");
    player tell("^7!wonderweapons / !weaponstatus <alias>");
    player tell("^7!perk [player] <alias> / !allperks [player]");
    player tell("^7!clearperks [player] / !removeperk [player] <alias>");
    player tell("^7!powerup [player] <alias>");
    player tell("^7!zombiecount / !lastzombie / !killzombies");
    player tell("^7!round / !nextround / !skiprounds <n>");
    player tell("^7!setround <target>");
    player tell("^3Wait for the round transition to finish");
    player tell("^7!power / !pap / !unlock");
    player tell("^7!freezepowerups [on|off|status]");
    player tell("^7!music [1|2|stop|status|states]");
    player tell("^7!boss [target] - map default boss");
    player tell("^7!margwa / !panzer / !castlepanzer [target]");
    player tell("^7!thrasher / !gorodpanzer / !astro [target]");
    player tell("^7!genesismargwa / !shadowmargwa [target]");
    player tell("^7!firemargwa / !genesispanzer [target]");
    player tell("^7!eventstatus");
    player tell("^7!menu - opens or closes the server HUD menu");
    player tell("^7!powerstatus / !papstatus / !unlockstatus");
    player tell("^3Short forms and !ezz-prefixed forms are accepted");
}

function chat_show_players(player)
{
    players = GetPlayers();

    player tell("^3=== CONNECTED PLAYERS: " + players.size + " ===");

    for (i = 0; i < players.size; i++)
    {
        connected_player = players[i];

        if (!isdefined(connected_player))
            continue;

        if (chat_is_admin(connected_player))
            player tell("^2ADMIN: ^7" + connected_player.name);
        else
            player tell("^7PLAYER: " + connected_player.name);
    }
}

function chat_show_weapons(player)
{
    player tell("^3=== PinteMod WEAPON ALIASES ===");
    player tell("^7raygun, kn44, hvk, icr, manowar");
    player tell("^7kuda, vmp, krm, brecci, haymaker");
    player tell("^7argus, brm, dingo, gorgon, dredge");
    player tell("^7drakon, locus, svg");
    player tell("^3Usage: !weapon [player] <alias>");
}

function chat_show_perks(player)
{
    player tell("^3=== PinteMod PERK ALIASES ===");
    player tell("^7jug, quick, speed, doubletap");
    player tell("^7staminup, deadshot, mule");
    player tell("^7cherry, widows");
    player tell("^3!perk [player] <alias>");
    player tell("^3!allperks [player] / !clearperks [player]");
    player tell("^3!removeperk [player] <alias>");
}

function chat_show_powerups(player)
{
    player tell("^3=== PinteMod POWER-UP ALIASES ===");
    player tell("^7maxammo, instakill, doublepoints");
    player tell("^7firesale, carpenter, nuke");
    player tell("^7deathmachine, freeperk, shield");
    player tell("^3Usage: !powerup [player] <alias>");
    player tell("^7The pickup appears where the target is aiming");
}

function chat_count_living_ai()
{
    all_ai = GetAIArray();
    alive_count = 0;

    for (i = 0; i < all_ai.size; i++)
    {
        ai = all_ai[i];

        if (isdefined(ai) && IsAlive(ai))
            alive_count++;
    }

    return alive_count;
}

function chat_show_zombie_count(player)
{
    player tell("^3[PinteMod]^7 Living AI: " + chat_count_living_ai());
}

function chat_show_zombies(player)
{
    player tell("^3=== PinteMod ZOMBIES ===");
    player tell("^7!zombiecount");
    player tell("^7!lastzombie");
    player tell("^7!killzombies");
}

function chat_show_round(player)
{
    if (isdefined(level.round_number))
        player tell("^3[PinteMod]^7 Current round: " + level.round_number);
    else
        player tell("^1[PinteMod] Round number unavailable");

    player tell("^3[PinteMod]^7 Living AI: " + chat_count_living_ai());

    if (isdefined(level.zombie_total))
        player tell("^3[PinteMod]^7 Spawn queue: " + level.zombie_total);
}

function chat_show_rounds(player)
{
    player tell("^3=== PinteMod ROUNDS ===");
    player tell("^7!round");
    player tell("^7!nextround");
    player tell("^7!skiprounds <count>");
    player tell("^7!setround <future round>");
}

function chat_get_map_name()
{
    return toLower(GetDvarString("mapname"));
}

function chat_get_map_display_name(map_name)
{
    switch (map_name)
    {
        case "zm_zod":
            return "Shadows of Evil";

        case "zm_factory":
            return "The Giant";

        case "zm_castle":
            return "Der Eisendrache";

        case "zm_island":
            return "Zetsubou No Shima";

        case "zm_stalingrad":
            return "Gorod Krovi";

        case "zm_genesis":
            return "Revelations";

        case "zm_prototype":
            return "Nacht der Untoten";

        case "zm_asylum":
            return "Verruckt";

        case "zm_sumpf":
            return "Shi No Numa";

        case "zm_theater":
            return "Kino der Toten";

        case "zm_cosmodrome":
            return "Ascension";

        case "zm_temple":
            return "Shangri-La";

        case "zm_moon":
            return "Moon";

        case "zm_tomb":
            return "Origins";
    }

    return "Unknown / Custom Map";
}

function chat_get_power_profile(map_name)
{
    switch (map_name)
    {
        case "zm_prototype":
            return "Not applicable";

        case "zm_zod":
            return "Local Beast-mode switches";

        case "zm_island":
            return "Dual generator system";

        case "zm_genesis":
            return "Corruption engine system";

        case "zm_tomb":
            return "Six generators";

        case "zm_factory":
        case "zm_castle":
        case "zm_stalingrad":
        case "zm_asylum":
        case "zm_sumpf":
        case "zm_theater":
        case "zm_cosmodrome":
        case "zm_temple":
        case "zm_moon":
            return "Standard global power";
    }

    return "Unknown / custom";
}

function chat_get_pap_profile(map_name)
{
    switch (map_name)
    {
        case "zm_prototype":
        case "zm_asylum":
        case "zm_sumpf":
            return "No native Pack-a-Punch";

        case "zm_zod":
            return "Ritual access";

        case "zm_factory":
            return "Three teleporter links";

        case "zm_castle":
            return "Map-specific access";

        case "zm_island":
            return "Machine construction";

        case "zm_stalingrad":
            return "Dragon transport";

        case "zm_genesis":
            return "Apothicon access";

        case "zm_theater":
            return "Teleporter access";

        case "zm_cosmodrome":
            return "Rocket launch";

        case "zm_temple":
            return "Pressure plates";

        case "zm_moon":
            return "Area 51";

        case "zm_tomb":
            return "Six generators";
    }

    return "Unknown / custom";
}

function chat_show_map(player)
{
    map_name = chat_get_map_name();

    player tell(
        "^5[PinteMod]^7 " +
        chat_get_map_display_name(map_name) +
        " ^3(" + map_name + ")"
    );

    if (isdefined(level.round_number))
        player tell("^5[PinteMod]^7 Round: " + level.round_number);

    player tell("^7!mapstatus for the complete profile");
}

function chat_show_map_status(player)
{
    map_name = chat_get_map_name();

    player tell("^5=== PinteMod MAP PROFILE ===");
    player tell("^7Name: " + chat_get_map_display_name(map_name));
    player tell("^7Internal ID: " + map_name);
    player tell("^7Power: " + chat_get_power_profile(map_name));
    player tell("^7Pack-a-Punch: " + chat_get_pap_profile(map_name));
    player tell("^7Unlock: standard doors/debris");
    player tell("^3Quest-specific logic remains protected");
}

function chat_show_official_maps(player)
{
    player tell("^5=== BO3 CORE / DLC ===");
    player tell("^7zm_zod, zm_factory, zm_castle");
    player tell("^7zm_island, zm_stalingrad, zm_genesis");
    player tell("^5=== ZOMBIES CHRONICLES ===");
    player tell("^7zm_prototype, zm_asylum, zm_sumpf");
    player tell("^7zm_theater, zm_cosmodrome, zm_temple");
    player tell("^7zm_moon, zm_tomb");
}

function chat_show_wonderweapons(player)
{
    map_name = chat_get_map_name();

    player tell(
        "^5=== " +
        chat_get_map_display_name(map_name) +
        " SPECIAL WEAPONS ==="
    );

    switch (map_name)
    {
        case "zm_zod":
            player tell("^7apothicon, apothiconup, arnies");
            player tell("^7annihilator, apothiconsword, keepersword");
            return;

        case "zm_factory":
            player tell("^7wunderwaffe, wunderwaffeup, annihilator");
            return;

        case "zm_castle":
            player tell("^7bow, stormbow, firebow, wolfbow, voidbow");
            player tell("^7ragnarok");
            return;

        case "zm_island":
            player tell("^7kt4, masamune, skull");
            return;

        case "zm_stalingrad":
            player tell("^7raygunmk3, raygunmk3up");
            player tell("^7gauntlet, dragonstrike");
            return;

        case "zm_genesis":
            player tell("^7apothicon, thundergun, arnies");
            player tell("^7ragnarok, katana");
            return;

        case "zm_prototype":
            player tell("^7thundergun");
            return;

        case "zm_asylum":
        case "zm_sumpf":
            player tell("^7wunderwaffe");
            return;

        case "zm_theater":
            player tell("^7thundergun");
            return;

        case "zm_cosmodrome":
            player tell("^7thundergun, gersh, dolls");
            return;

        case "zm_temple":
            player tell("^7babygun, babygunup, monkey");
            return;

        case "zm_moon":
            player tell("^7wavegun, wavegunup, qed, gersh");
            return;

        case "zm_tomb":
            player tell("^7windstaff, icestaff, lightningstaff, firestaff");
            player tell("^7windstaffup, icestaffup");
            player tell("^7lightningstaffup, firestaffup");
            player tell("^7gstrike, oneinch, elemental fists");
            return;
    }

    player tell("^3No official special catalog for this map");
}

function chat_show_weapon_status_notice(player, alias)
{
    player tell("^5[PinteMod]^7 Checking alias: " + alias);
    player tell("^3Detailed availability is written to server console");
    player tell("^7Use !weapon " + alias + " to attempt a safe native give");
}

// ------------------------------------------------------------
// Dispatch helpers
// ------------------------------------------------------------


function chat_dispatch_simple_target(player, tokens, console_name)
{
    target_name = chat_get_optional_target(player, tokens, 1);

    if (!isdefined(target_name))
    {
        player tell("^1[PinteMod] Player not found: ^7" + tokens[1]);
        return;
    }

    chat_route(
        player,
        console_name + " " + target_name,
        tokens[0] + " " + target_name
    );
}

function chat_dispatch_item_target(player, tokens, console_name, usage_text)
{
    target_name = undefined;
    item_alias = "";

    if (tokens.size == 2)
    {
        target_name = player.name;
        item_alias = toLower(tokens[1]);
    }
    else if (tokens.size >= 3)
    {
        target_name = chat_require_target(player, tokens[1]);

        if (!isdefined(target_name))
            return;

        item_alias = toLower(tokens[2]);
    }
    else
    {
        player tell("^3[PinteMod]^7 Usage: " + usage_text);
        return;
    }

    chat_route(
        player,
        console_name + " " + target_name + " " + item_alias,
        tokens[0] + " " + target_name + " " + item_alias
    );
}

// ------------------------------------------------------------
// Command allowlist
// ------------------------------------------------------------


function chat_show_permissions(player)
{
    player tell("^5=== PinteMod PERMISSION LEVELS ===");
    player tell("^7owner     - complete access and role management");
    player tell("^7admin     - maps, rounds and destructive commands");
    player tell("^7moderator - gameplay tools, weapons, perks, powerups");
    player tell("^7helper    - diagnostics, spawn, save/load and teleport");
    player tell(
        "^6Your role: ^7" +
        chat_get_role_name(chat_get_player_role(player))
    );
}

function chat_show_player_permission(sender, input_name)
{
    resolved_name = chat_resolve_player_name(input_name);

    if (!isdefined(resolved_name))
    {
        sender tell("^1[PinteMod]^7 Player not found: " + input_name);
        return;
    }

    target = undefined;
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        if (isdefined(players[i]) && players[i].name == resolved_name)
        {
            target = players[i];
            break;
        }
    }

    if (!isdefined(target))
        return;

    sender tell(
        "^5[PinteMod]^7 " + target.name +
        " role: ^6" + chat_get_role_name(chat_get_player_role(target))
    );
}

function chat_set_runtime_role(sender, player_name, role_name)
{
    resolved_name = chat_resolve_player_name(player_name);

    if (!isdefined(resolved_name))
    {
        sender tell("^1[PinteMod]^7 Player not found: " + player_name);
        return;
    }

    target = undefined;
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        if (isdefined(players[i]) && players[i].name == resolved_name)
        {
            target = players[i];
            break;
        }
    }

    if (!isdefined(target))
        return;

    role = chat_role_from_text(role_name);

    if (role < 0)
    {
        sender tell("^1[PinteMod]^7 Unknown role: " + role_name);
        return;
    }

    if (target == sender && role < 4)
    {
        sender tell("^3[PinteMod]^7 Owner cannot demote themselves");
        return;
    }

    target.ezz_runtime_role = role;

    sender tell(
        "^2[PinteMod]^7 " + target.name +
        " is now " + chat_get_role_name(role)
    );

    target tell(
        "^5[PinteMod]^7 Runtime role: ^6" +
        chat_get_role_name(role)
    );

    appendfile(
        "ezz_admin/chat_commands.log",
        "ROLE " + sender.name + " -> " +
        target.name + " = " + chat_get_role_name(role) + "\n"
    );
}

function chat_route_navigation_target(sender, tokens, console_name)
{
    target_name = sender.name;

    if (tokens.size >= 2)
    {
        target_name = chat_resolve_player_name(tokens[1]);

        if (!isdefined(target_name))
        {
            sender tell("^1[PinteMod]^7 Player not found: " + tokens[1]);
            return;
        }

        // Helpers can use navigation on themselves only.
        if (target_name != sender.name &&
            chat_get_player_role(sender) < 2)
        {
            sender tell("^1[PinteMod]^7 Moderator role required for others");
            return;
        }
    }

    chat_route(
        sender,
        console_name + " " + target_name,
        tokens[0] + " " + target_name
    );
}

function chat_route_aim_teleport(sender, tokens)
{
    target_name = sender.name;

    if (tokens.size >= 2)
    {
        target_name = chat_resolve_player_name(tokens[1]);

        if (!isdefined(target_name))
        {
            sender tell("^1[PinteMod]^7 Player not found: " + tokens[1]);
            return;
        }

        if (target_name != sender.name &&
            chat_get_player_role(sender) < 2)
        {
            sender tell("^1[PinteMod]^7 Moderator role required for others");
            return;
        }
    }

    chat_route(
        sender,
        "ezztp " + sender.name + " " + target_name,
        tokens[0] + " " + target_name
    );
}


function chat_dispatch(player, command_name, tokens)
{
    switch (command_name)
    {
        // Diagnostics
        case "ping":
            player tell("^2[PinteMod] Chat parser OK");
            println("^2[PinteMod]^7 Ping from " + player.name);
            return;

        case "help":
        case "commands":
        case "adminhelp":
            chat_show_help(player);
            return;

        case "players":
            chat_show_players(player);
            return;

        // Permissions
        case "permissions":
        case "permission":
            chat_show_permissions(player);
            return;

        case "perm":
            if (tokens.size < 2)
                chat_show_permissions(player);
            else
                chat_show_player_permission(player, tokens[1]);
            return;

        case "setrole":
            if (tokens.size < 3)
            {
                player tell("^3[PinteMod]^7 Usage: !setrole <player> <role>");
                return;
            }

            chat_set_runtime_role(player, tokens[1], tokens[2]);
            return;

        case "removerole":
            if (tokens.size < 2)
            {
                player tell("^3[PinteMod]^7 Usage: !removerole <player>");
                return;
            }

            chat_set_runtime_role(player, tokens[1], "user");
            return;

        // Special song de la map
        case "music":
            mode = "1";

            if (tokens.size >= 2)
                mode = toLower(tokens[1]);

            if (mode == "stop" || mode == "off")
            {
                chat_route(
                    player,
                    "ezzmusicstopall",
                    "!music stop"
                );
                return;
            }

            if (mode == "status")
            {
                chat_route(
                    player,
                    "ezzmusicstatus",
                    "!music status"
                );
                return;
            }

            if (mode == "states")
            {
                chat_route(
                    player,
                    "ezzmusicstates",
                    "!music states"
                );
                return;
            }

            chat_route(
                player,
                "ezzmusicplayall " + mode,
                "!music " + mode
            );
            return;

        case "musicstatus":
            chat_route(
                player,
                "ezzmusicstatus",
                "!musicstatus"
            );
            return;

        // Events
        case "boss":
            target_name = player.name;

            if (tokens.size >= 2)
                target_name = tokens[1];

            chat_route(
                player,
                "ezzspawnboss " + target_name,
                "!boss " + target_name
            );
            return;

        case "margwa":
            target_name = player.name;

            if (tokens.size >= 2)
                target_name = tokens[1];

            chat_route(
                player,
                "ezzspawnmargwa " + target_name,
                "!margwa " + target_name
            );
            return;

        case "panzer":
            target_name = player.name;

            if (tokens.size >= 2)
                target_name = tokens[1];

            chat_route(
                player,
                "ezzspawnpanzer " + target_name,
                "!panzer " + target_name
            );
            return;

        case "castlepanzer":
            target_name = player.name;

            if (tokens.size >= 2)
                target_name = tokens[1];

            chat_route(
                player,
                "ezzspawncastlepanzer " + target_name,
                "!castlepanzer " + target_name
            );
            return;

        case "thrasher":
            target_name = player.name;

            if (tokens.size >= 2)
                target_name = tokens[1];

            chat_route(
                player,
                "ezzspawnthrasher " + target_name,
                "!thrasher " + target_name
            );
            return;

        case "gorodpanzer":
            target_name = player.name;

            if (tokens.size >= 2)
                target_name = tokens[1];

            chat_route(
                player,
                "ezzspawnstalingradpanzer " + target_name,
                "!gorodpanzer " + target_name
            );
            return;

        case "genesismargwa":
            target_name = player.name;

            if (tokens.size >= 2)
                target_name = tokens[1];

            chat_route(
                player,
                "ezzspawngenesismargwa " + target_name,
                "!genesismargwa " + target_name
            );
            return;

        case "shadowmargwa":
            target_name = player.name;

            if (tokens.size >= 2)
                target_name = tokens[1];

            chat_route(
                player,
                "ezzspawngenesisshadow " + target_name,
                "!shadowmargwa " + target_name
            );
            return;

        case "firemargwa":
            target_name = player.name;

            if (tokens.size >= 2)
                target_name = tokens[1];

            chat_route(
                player,
                "ezzspawngenesisfire " + target_name,
                "!firemargwa " + target_name
            );
            return;

        case "genesispanzer":
            target_name = player.name;

            if (tokens.size >= 2)
                target_name = tokens[1];

            chat_route(
                player,
                "ezzspawngenesispanzer " + target_name,
                "!genesispanzer " + target_name
            );
            return;

        case "astro":
        case "astronaut":
            target_name = player.name;

            if (tokens.size >= 2)
                target_name = tokens[1];

            chat_route(
                player,
                "ezzspawnastro " + target_name,
                "!astro " + target_name
            );
            return;

        case "eventstatus":
            chat_route(
                player,
                "ezzeventstatus",
                "!eventstatus"
            );
            return;

        // Navigation
        case "save":
            chat_route_navigation_target(player, tokens, "ezzsave");
            return;

        case "load":
            chat_route_navigation_target(player, tokens, "ezzload");
            return;

        case "tp":
        case "teleport":
            chat_route_aim_teleport(player, tokens);
            return;

        // Core player commands
        case "god":
        case "godmode":
            chat_dispatch_simple_target(player, tokens, "godmode");
            return;

        case "ignore":
            chat_dispatch_simple_target(player, tokens, "ignore");
            return;

        case "spawn":
        case "respawn":
            chat_dispatch_simple_target(player, tokens, "ezzspawn");
            return;

        case "noclip":
            chat_dispatch_simple_target(player, tokens, "ezznoclip");
            return;

        case "ammo":
        case "maxammo":
            chat_dispatch_simple_target(player, tokens, "ammo");
            return;

        case "maxpoints":
            chat_dispatch_simple_target(player, tokens, "maxpoints");
            return;

        case "points":
            if (tokens.size == 2)
            {
                chat_route(
                    player,
                    "points " + player.name + " " + tokens[1],
                    "!points " + player.name + " " + tokens[1]
                );
                return;
            }

            if (tokens.size >= 3)
            {
                target_name = chat_require_target(player, tokens[1]);

                if (!isdefined(target_name))
                    return;

                chat_route(
                    player,
                    "points " + target_name + " " + tokens[2],
                    "!points " + target_name + " " + tokens[2]
                );
                return;
            }

            player tell("^3[PinteMod]^7 Usage: !points [player] <amount>");
            return;

        // Weapons
        case "weapons":
            chat_show_weapons(player);
            return;

        case "wonderweapons":
        case "wonderweapon":
        case "wonders":
            chat_show_wonderweapons(player);
            return;

        case "weaponstatus":
            if (tokens.size < 2)
            {
                player tell("^3[PinteMod]^7 Usage: !weaponstatus <alias>");
                return;
            }

            chat_show_weapon_status_notice(player, toLower(tokens[1]));
            chat_route(
                player,
                "ezzweaponstatus " + toLower(tokens[1]),
                "!weaponstatus " + toLower(tokens[1])
            );
            return;

        case "weapon":
        case "gun":
            chat_dispatch_item_target(
                player,
                tokens,
                "ezzweapon",
                "!weapon [player] <alias>"
            );
            return;

        case "papweapon":
        case "packweapon":
            chat_dispatch_simple_target(player, tokens, "ezzpapweapon");
            return;

        case "hasweapon":
            chat_dispatch_item_target(
                player,
                tokens,
                "ezzhasweapon",
                "!hasweapon [player] <alias>"
            );
            return;

        // Perks
        case "perks":
            chat_show_perks(player);
            return;

        case "perk":
            chat_dispatch_item_target(
                player,
                tokens,
                "ezzperk",
                "!perk [player] <alias>"
            );
            return;

        case "hasperk":
            chat_dispatch_item_target(
                player,
                tokens,
                "ezzhasperk",
                "!hasperk [player] <alias>"
            );
            return;

        case "allperks":
            target_name = chat_get_optional_target(player, tokens, 1);

            if (!isdefined(target_name))
            {
                player tell("^1[PinteMod] Player not found: ^7" + tokens[1]);
                return;
            }

            chat_route(
                player,
                "ezzallperks " + target_name,
                "!allperks " + target_name
            );
            return;

        case "clearperks":
            target_name = chat_get_optional_target(player, tokens, 1);

            if (!isdefined(target_name))
            {
                player tell("^1[PinteMod] Player not found: ^7" + tokens[1]);
                return;
            }

            chat_route(
                player,
                "ezzclearperks " + target_name,
                "!clearperks " + target_name
            );
            return;

        case "removeperk":
            chat_dispatch_item_target(
                player,
                tokens,
                "ezzremoveperk",
                "!removeperk [player] <alias>"
            );
            return;

        // Power-Ups use the target player's aim
        case "powerups":
            chat_show_powerups(player);
            return;

        case "powerup":
            chat_dispatch_item_target(
                player,
                tokens,
                "ezzpowerup",
                "!powerup [player] <alias>"
            );
            return;

        // Zombies
        case "zombies":
            chat_show_zombies(player);
            return;

        case "zombiecount":
            chat_show_zombie_count(player);
            return;

        case "roundinfo":
            chat_show_round(player);
            return;

        case "lastzombie":
            chat_route(player, "ezzlastzombie", "!lastzombie");
            return;

        case "killzombies":
            chat_route(player, "ezzkillzombies", "!killzombies");
            return;

        // Rounds
        case "rounds":
            chat_show_rounds(player);
            return;

        case "round":
            chat_show_round(player);
            return;

        case "nextround":
            chat_route(player, "ezznextround", "!nextround");
            return;

        case "skiprounds":
            if (tokens.size < 2)
            {
                player tell("^3[PinteMod]^7 Usage: !skiprounds <count>");
                return;
            }

            chat_route(
                player,
                "ezzskiprounds " + tokens[1],
                "!skiprounds " + tokens[1]
            );
            return;

        case "setround":
            if (tokens.size < 2)
            {
                player tell("^3[PinteMod]^7 Usage: !setround <target>");
                return;
            }

            chat_route(
                player,
                "ezzsetround " + tokens[1],
                "!setround " + tokens[1]
            );
            return;


        case "freezepowerups":
            mode = "toggle";

            if (tokens.size >= 2)
                mode = toLower(tokens[1]);

            chat_route(
                player,
                "ezzfreezepowerups " + mode,
                "!freezepowerups " + mode
            );
            return;

        // Validated server-side HUD menu
        case "menu":
            chat_route(
                player,
                "ezzmenu " + player.name,
                "!menu"
            );
            return;

        // Maps / Power / Pack-a-Punch / Unlock
        case "map":
            chat_show_map(player);
            return;

        case "mapstatus":
            chat_show_map_status(player);
            return;

        case "maps":
            chat_show_official_maps(player);
            return;

        case "power":
            chat_route(player, "ezzpower", "!power");
            return;

        case "powerstatus":
            player tell(
                "^5[PinteMod]^7 Power profile: " +
                chat_get_power_profile(chat_get_map_name())
            );
            chat_route(player, "ezzpowerstatus", "!powerstatus");
            return;

        case "pap":
            chat_route(player, "ezzpap", "!pap");
            return;

        case "papstatus":
            player tell(
                "^5[PinteMod]^7 PaP profile: " +
                chat_get_pap_profile(chat_get_map_name())
            );
            chat_route(player, "ezzpapstatus", "!papstatus");
            return;

        case "unlock":
            chat_route(player, "ezzunlock", "!unlock");
            return;

        case "unlockstatus":
            player tell("^5[PinteMod]^7 Checking standard doors/debris");
            chat_route(player, "ezzunlockstatus", "!unlockstatus");
            return;

    }

    player tell("^1[PinteMod] Unknown command: ^7!" + command_name);
    player tell("^3Type !help for the command list");
}

// ------------------------------------------------------------
// Dedicated console diagnostic
// ------------------------------------------------------------

function cmd_ezzchatstatus(args)
{
    println("^5========== PinteMod CHAT v0.10.6 ==========");
    println("^7Prefix: " + level.ezz_chat_prefix);

    players = GetPlayers();
    println("^7Connected players: " + players.size);

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (!isdefined(player))
            continue;

        role = chat_get_player_role(player);

        if (role > 0)
        {
            println(
                "^2" + toUpper(chat_get_role_name(role)) +
                ": " + player.name
            );
        }
        else
        {
            println("^7USER: " + player.name);
        }
    }

    println("^3Runtime !setrole changes reset on disconnect/restart");
    println("^5=======================================");
}
