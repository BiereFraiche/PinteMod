// ============================================================
// PinteMod — Role Configuration v1.1.0
// File: ezz_admin_config.gsc
// Created by BiereFraiche and ChatGPT
//
// Roles: Owner 4, Admin 3, Moderator 2, Helper 1, User 0.
// Player-name comparison is case-insensitive.
// Changes made with !setrole remain temporary.
// ============================================================

autoexec function init()
{
    level.ezz_admin_version = "1.1.0";
    level.ezz_admin_debug = true;

    // --------------------------------------------------------
    // Central chat/HUD color theme
    // --------------------------------------------------------
    level.ezz_color_success = "^2";
    level.ezz_color_error = "^1";
    level.ezz_color_warning = "^3";
    level.ezz_color_admin = "^5";
    level.ezz_color_info = "^6";
    level.ezz_color_normal = "^7";

    level.ezz_admin_prefix = "^5[PinteMod]^7";

    // --------------------------------------------------------
    // Persistent role configuration
    // --------------------------------------------------------
    level.ezz_owner_names = [];
    level.ezz_owner_names[0] = "PinteMod";

    level.ezz_admin_names = [];
    // level.ezz_admin_names[0] = "AdminName";

    level.ezz_moderator_names = [];
    // level.ezz_moderator_names[0] = "ModeratorName";

    level.ezz_helper_names = [];
    // level.ezz_helper_names[0] = "HelperName";

    level.ezz_admin_max_points = 999999;

    println("^5[PinteMod]^7 Configuration v1.1.0 Roles + Colors loaded");
}
