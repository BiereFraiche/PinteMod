// ============================================================
// PinteMod — Validated Boss Events v1.1.0
// File: ezz_admin_events.gsc
// Created by BiereFraiche and ChatGPT
//
// Spawns only boss AI types confirmed on the current map.
// No stock-script imports and no ClientField registration.
//
// CONSOLE COMMANDS
// ------------------------------------------------------------
// ezzeventstatus
// ezzspawnboss <PlayerName>
// ezzspawnmargwa <PlayerName>
// ezzspawnpanzer <PlayerName>
// ezzspawncastlepanzer <PlayerName>
// ezzspawnthrasher <PlayerName>
// ezzspawnstalingradpanzer <PlayerName>
// ezzspawngenesismargwa <PlayerName>
// ezzspawngenesisshadow <PlayerName>
// ezzspawngenesisfire <PlayerName>
// ezzspawngenesispanzer <PlayerName>
// ezzspawnastro <PlayerName>
// ============================================================

autoexec function init()
{
    addcommand("ezzeventstatus", ::cmd_ezzeventstatus);
    addcommand("ezzspawnboss", ::cmd_ezzspawnboss);
    addcommand("ezzspawnmargwa", ::cmd_ezzspawnmargwa);
    addcommand("ezzspawnpanzer", ::cmd_ezzspawnpanzer);
    addcommand("ezzspawncastlepanzer", ::cmd_ezzspawncastlepanzer);
    addcommand("ezzspawnthrasher", ::cmd_ezzspawnthrasher);
    addcommand(
        "ezzspawnstalingradpanzer",
        ::cmd_ezzspawnstalingradpanzer
    );
    addcommand(
        "ezzspawngenesismargwa",
        ::cmd_ezzspawngenesismargwa
    );
    addcommand(
        "ezzspawngenesisshadow",
        ::cmd_ezzspawngenesisshadow
    );
    addcommand(
        "ezzspawngenesisfire",
        ::cmd_ezzspawngenesisfire
    );
    addcommand(
        "ezzspawngenesispanzer",
        ::cmd_ezzspawngenesispanzer
    );
    addcommand("ezzspawnastro", ::cmd_ezzspawnastro);

    level.pintemod_events_loaded = true;

    println("^5[PinteMod]^7 Validated Boss Events v1.1.0 loaded");
}

function events_find_player_exact(player_name)
{
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (isdefined(player) && player.name == player_name)
            return player;
    }

    return undefined;
}

function events_get_map_name()
{
    return toLower(GetDvarString("mapname"));
}

function events_get_aim_position(player)
{
    eye = player GetEye();
    angles = player GetPlayerAngles();
    forward = AnglesToForward(angles);

    trace_end = eye + (forward * 8192);
    aim_trace = BulletTrace(eye, trace_end, false, player);

    if (aim_trace["fraction"] >= 1)
        return undefined;

    hit_position = aim_trace["position"];

    floor_start = hit_position + (0, 0, 128);
    floor_end = hit_position + (0, 0, -768);
    floor_trace = BulletTrace(
        floor_start,
        floor_end,
        false,
        player
    );

    if (floor_trace["fraction"] < 1)
        return floor_trace["position"] + (0, 0, 8);

    return hit_position + (0, 0, 8);
}

function events_position_is_safe(player, position)
{
    if (!isdefined(position))
        return false;

    if (Distance(player.origin, position) < 200)
        return false;

    return true;
}

function events_spawn_type_for_player(
    args,
    required_map,
    type_name,
    display_name
)
{
    if (args.size < 1)
    {
        println("^5[PinteMod]^7 Usage: command <PlayerName>");
        return;
    }

    current_map = events_get_map_name();

    if (current_map != required_map)
    {
        println(
            "^3[PinteMod]^7 " + display_name +
            " is unavailable on this map"
        );
        return;
    }

    player = events_find_player_exact(args[0]);

    if (!isdefined(player))
    {
        println("^1[PinteMod] Player not found: " + args[0]);
        return;
    }

    spawn_position = events_get_aim_position(player);

    if (!events_position_is_safe(player, spawn_position))
    {
        println("^1[PinteMod] Invalid or too-close aimed position");

        player tell(
            "^1[PinteMod]^7 Aim at open ground over 200 units away"
        );
        return;
    }

    player_angles = player GetPlayerAngles();
    spawn_angles = (0, player_angles[1], 0);

    actor = SpawnActor(
        type_name,
        spawn_position,
        spawn_angles,
        undefined,
        true,
        true
    );

    if (!isdefined(actor))
    {
        println(
            "^1[PinteMod] SpawnActor returned no " +
            display_name
        );

        player tell(
            "^1[PinteMod]^7 " + display_name +
            " spawn failed"
        );
        return;
    }

    actor.pintemod_spawned_event = true;
    actor.pintemod_event_type = type_name;

    println(
        "^2[PinteMod] " + display_name + " spawned" +
        " | map=" + current_map +
        " | player=" + player.name +
        " | type=" + type_name
    );

    say(
        "^6[PinteMod]^7 " + display_name +
        " was spawned by ^2" + player.name
    );
}

function cmd_ezzeventstatus(args)
{
    map_name = events_get_map_name();

    println("^5========== PINTEMOD BOSS EVENTS ==========");
    println("^7Map: " + map_name);
    println("^7Backend: native SpawnActor");
    println("^7Stock imports: none");
    println("^7Added ClientFields: none");

    switch (map_name)
    {
        case "zm_zod":
            println("^2Available: Margwa");
            break;

        case "zm_tomb":
            println("^2Available: Origins Panzer");
            break;

        case "zm_castle":
            println("^2Available: Der Eisendrache Panzer");
            break;

        case "zm_island":
            println("^2Available: Thrasher");
            break;

        case "zm_stalingrad":
            println("^2Available: Gorod Krovi Mechz");
            break;

        case "zm_genesis":
            println("^2Available: Margwa");
            println("^2Available: Shadow Margwa");
            println("^2Available: Fire Margwa");
            println("^2Available: Revelations Panzer");
            break;

        case "zm_moon":
            println("^2Available: Astronaut");
            break;

        default:
            println("^3No validated boss configured");
            break;
    }

    println("^5===========================================");
}

function cmd_ezzspawnboss(args)
{
    if (args.size < 1)
    {
        println(
            "^5[PinteMod]^7 Usage: " +
            "ezzspawnboss <PlayerName>"
        );
        return;
    }

    map_name = events_get_map_name();
    player_name = args[0];

    switch (map_name)
    {
        case "zm_zod":
            executecommand("ezzspawnmargwa " + player_name);
            return;

        case "zm_tomb":
            executecommand("ezzspawnpanzer " + player_name);
            return;

        case "zm_castle":
            executecommand(
                "ezzspawncastlepanzer " + player_name
            );
            return;

        case "zm_island":
            executecommand("ezzspawnthrasher " + player_name);
            return;

        case "zm_stalingrad":
            executecommand(
                "ezzspawnstalingradpanzer " + player_name
            );
            return;

        case "zm_genesis":
            executecommand(
                "ezzspawngenesismargwa " + player_name
            );
            return;

        case "zm_moon":
            executecommand("ezzspawnastro " + player_name);
            return;
    }

    println(
        "^3[PinteMod]^7 No validated boss is configured " +
        "for this map"
    );
}

function cmd_ezzspawnmargwa(args)
{
    events_spawn_type_for_player(
        args,
        "zm_zod",
        "spawner_zm_zod_margwa",
        "Margwa"
    );
}

function cmd_ezzspawnpanzer(args)
{
    events_spawn_type_for_player(
        args,
        "zm_tomb",
        "spawner_zm_tomb_mechz",
        "Origins Panzer"
    );
}

function cmd_ezzspawncastlepanzer(args)
{
    events_spawn_type_for_player(
        args,
        "zm_castle",
        "spawner_zm_castle_mechz",
        "Der Eisendrache Panzer"
    );
}

function cmd_ezzspawnthrasher(args)
{
    events_spawn_type_for_player(
        args,
        "zm_island",
        "spawner_zm_island_thrasher",
        "Thrasher"
    );
}

function cmd_ezzspawnstalingradpanzer(args)
{
    events_spawn_type_for_player(
        args,
        "zm_stalingrad",
        "spawner_zm_stalingrad_mechz",
        "Gorod Krovi Mechz"
    );
}

function cmd_ezzspawngenesismargwa(args)
{
    events_spawn_type_for_player(
        args,
        "zm_genesis",
        "spawner_zm_genesis_margwa",
        "Revelations Margwa"
    );
}

function cmd_ezzspawngenesisshadow(args)
{
    events_spawn_type_for_player(
        args,
        "zm_genesis",
        "spawner_zm_genesis_margwa_shadow",
        "Shadow Margwa"
    );
}

function cmd_ezzspawngenesisfire(args)
{
    events_spawn_type_for_player(
        args,
        "zm_genesis",
        "spawner_zm_genesis_margwa_fire",
        "Fire Margwa"
    );
}

function cmd_ezzspawngenesispanzer(args)
{
    events_spawn_type_for_player(
        args,
        "zm_genesis",
        "spawner_zm_genesis_mechz",
        "Revelations Panzer"
    );
}

function cmd_ezzspawnastro(args)
{
    events_spawn_type_for_player(
        args,
        "zm_moon",
        "spawner_zm_moon_astro",
        "Astronaut"
    );
}
