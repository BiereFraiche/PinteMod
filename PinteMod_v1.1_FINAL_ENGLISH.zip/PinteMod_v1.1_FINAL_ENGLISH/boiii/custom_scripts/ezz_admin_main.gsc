// ============================================================
// PinteMod Core v1.0.0
// File: ezz_admin_main.gsc
// Created by BiereFraiche and ChatGPT
//
// Standalone entry point for the Zombies framework.
// ============================================================

autoexec function init()
{
    level.ezz_admin_loaded = true;
    level.ezz_admin_release = "1.0.0";

    println("^5[PinteMod]^7 Core v1.0.0 loaded");
    say("^3[PinteMod]^7 ^2Core v1.1.0 ready^7");
    println("^5[PinteMod]^7 Created by BiereFraiche and ChatGPT");
}
