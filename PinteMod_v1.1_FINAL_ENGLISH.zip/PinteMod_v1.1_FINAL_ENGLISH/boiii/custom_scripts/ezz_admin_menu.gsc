// ============================================================
// PinteMod — Administrator Menu v1.1.0
// File: ezz_admin_menu.gsc
// Created by BiereFraiche and ChatGPT
//
// Server HUD menu restricted to authorized roles.
// Navigation : 2 monter, 4 descendre, Use/Reload valider,
// Melee returns or closes the menu.
// ============================================================

#using scripts\shared\hud_util_shared;

autoexec function init()
{
    addcommand("ezzmenu", ::cmd_ezzmenu);
    addcommand("ezzmenuclose", ::cmd_ezzmenuclose);
    addcommand("ezzmenustatus", ::cmd_ezzmenustatus);
    addcommand("ezznoclip", ::cmd_ezznoclip);

    level.pintemod_menu_version = "1.1.0";

    println("^5[PinteMod]^7 Administrator Menu v1.1.0 loaded");
}

// ------------------------------------------------------------
// Player and permission helpers
// ------------------------------------------------------------

function pintemod_menu_find_player_exact(player_name)
{
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (isdefined(player) && player.name == player_name)
            return player;
    }

    return undefined;
}

function pintemod_menu_name_in_list(player_name, values)
{
    if (!isdefined(values))
        return false;

    wanted_name = toLower(player_name);

    for (i = 0; i < values.size; i++)
    {
        if (!isdefined(values[i]))
            continue;

        if (toLower(values[i]) == wanted_name)
            return true;
    }

    return false;
}

function pintemod_menu_get_role(player)
{
    if (!isdefined(player))
        return 0;

    if (isdefined(player.ezz_runtime_role))
        return player.ezz_runtime_role;

    if (pintemod_menu_name_in_list(player.name, level.ezz_owner_names))
        return 4;

    if (pintemod_menu_name_in_list(player.name, level.ezz_admin_names))
        return 3;

    if (pintemod_menu_name_in_list(
        player.name,
        level.ezz_moderator_names
    ))
    {
        return 2;
    }

    if (pintemod_menu_name_in_list(player.name, level.ezz_helper_names))
        return 1;

    // Compatibility with the old single-list configuration.
    if (!isdefined(level.ezz_owner_names) &&
        pintemod_menu_name_in_list(player.name, level.ezz_admin_names))
    {
        return 3;
    }

    return 0;
}

function pintemod_menu_role_name(role)
{
    switch (role)
    {
        case 4:
            return "OWNER";

        case 3:
            return "ADMIN";

        case 2:
            return "MODERATOR";

        case 1:
            return "HELPER";
    }

    return "USER";
}

function pintemod_menu_get_map_name()
{
    return toLower(GetDvarString("mapname"));
}

function pintemod_menu_get_map_display_name(map_name)
{
    switch (map_name)
    {
        case "zm_zod":
            return "Shadows of Evil";

        case "zm_factory":
            return "The Giant";

        case "zm_castle":
            return "Der Eisendrache";

        case "zm_island":
            return "Zetsubou No Shima";

        case "zm_stalingrad":
            return "Gorod Krovi";

        case "zm_genesis":
            return "Revelations";

        case "zm_prototype":
            return "Nacht der Untoten";

        case "zm_asylum":
            return "Verruckt";

        case "zm_sumpf":
            return "Shi No Numa";

        case "zm_theater":
            return "Kino der Toten";

        case "zm_cosmodrome":
            return "Ascension";

        case "zm_temple":
            return "Shangri-La";

        case "zm_moon":
            return "Moon";

        case "zm_tomb":
            return "Origins";
    }

    return "Custom Map";
}

function pintemod_menu_get_target(player)
{
    if (isdefined(player.pintemod_menu_target_name))
    {
        target = pintemod_menu_find_player_exact(
            player.pintemod_menu_target_name
        );

        if (isdefined(target))
            return target;
    }

    player.pintemod_menu_target_name = player.name;

    return player;
}

// ------------------------------------------------------------
// Menu item helpers
// ------------------------------------------------------------

function pintemod_menu_add_item(
    items,
    label,
    action,
    value,
    required_role
)
{
    item = SpawnStruct();

    item.label = label;
    item.action = action;
    item.value = value;
    item.required_role = required_role;

    items[items.size] = item;

    return items;
}

function pintemod_menu_add_command(
    items,
    label,
    command_line,
    required_role
)
{
    return pintemod_menu_add_item(
        items,
        label,
        "command",
        command_line,
        required_role
    );
}

function pintemod_menu_add_open(
    items,
    label,
    category,
    required_role
)
{
    return pintemod_menu_add_item(
        items,
        label,
        "open",
        category,
        required_role
    );
}

function pintemod_menu_add_back(items)
{
    return pintemod_menu_add_item(
        items,
        "< Retour",
        "back",
        "",
        1
    );
}

function pintemod_menu_filter_items(player, items)
{
    role = pintemod_menu_get_role(player);
    filtered = [];

    for (i = 0; i < items.size; i++)
    {
        if (role >= items[i].required_role)
            filtered[filtered.size] = items[i];
    }

    return filtered;
}

// ------------------------------------------------------------
// Main menu
// ------------------------------------------------------------

function pintemod_menu_build_main(player)
{
    items = [];

    items = pintemod_menu_add_open(
        items,
        "Joueurs / Cible",
        "players",
        1
    );

    items = pintemod_menu_add_open(
        items,
        "Administration",
        "administration",
        4
    );

    items = pintemod_menu_add_open(
        items,
        "Perks",
        "perks",
        2
    );

    items = pintemod_menu_add_open(
        items,
        "Weapons",
        "weapons",
        2
    );

    items = pintemod_menu_add_open(
        items,
        "Rounds",
        "rounds",
        3
    );

    items = pintemod_menu_add_open(
        items,
        "Power-Ups",
        "powerups",
        2
    );

    items = pintemod_menu_add_open(
        items,
        "Teleport / Spawn",
        "teleport",
        1
    );

    items = pintemod_menu_add_open(
        items,
        "Map",
        "maps",
        3
    );

    items = pintemod_menu_add_open(
        items,
        "Events",
        "events",
        3
    );

    items = pintemod_menu_add_open(
        items,
        "Special Music",
        "music",
        3
    );

    items = pintemod_menu_add_open(
        items,
        "Fun",
        "fun",
        2
    );

    items = pintemod_menu_add_item(
        items,
        "Fermer PinteMod",
        "close",
        "",
        1
    );

    return pintemod_menu_filter_items(player, items);
}

// ------------------------------------------------------------
// Player target selector
// ------------------------------------------------------------

function pintemod_menu_build_players(player)
{
    items = [];
    players = GetPlayers();
    role = pintemod_menu_get_role(player);
    current_target = pintemod_menu_get_target(player);

    for (i = 0; i < players.size; i++)
    {
        target = players[i];

        if (!isdefined(target))
            continue;

        // Helpers can target themselves only.
        if (role < 2 && target != player)
            continue;

        prefix = "";

        if (target == current_target)
            prefix = "^2> ";

        items = pintemod_menu_add_item(
            items,
            prefix + target.name,
            "target",
            target.name,
            1
        );
    }

    return pintemod_menu_add_back(items);
}

// ------------------------------------------------------------
// Administration
// ------------------------------------------------------------

function pintemod_menu_build_administration(player)
{
    items = [];
    target = pintemod_menu_get_target(player).name;

    items = pintemod_menu_add_command(
        items,
        "Etat du routeur Chat",
        "ezzchatstatus",
        4
    );

    items = pintemod_menu_add_command(
        items,
        "Liste des joueurs",
        "ezzplayers",
        4
    );

    items = pintemod_menu_add_command(
        items,
        "Etat navigation cible",
        "ezznavstatus " + target,
        4
    );

    items = pintemod_menu_add_command(
        items,
        "Etat de la manche",
        "ezzroundinfo",
        4
    );

    items = pintemod_menu_add_command(
        items,
        "Profil de la map",
        "ezzmapstatus",
        4
    );

    items = pintemod_menu_add_command(
        items,
        "Etat du courant",
        "ezzpowerstatus",
        4
    );

    items = pintemod_menu_add_command(
        items,
        "Etat Pack-a-Punch",
        "ezzpapstatus",
        4
    );

    items = pintemod_menu_add_command(
        items,
        "Etat des passages",
        "ezzunlockstatus",
        4
    );

    items = pintemod_menu_add_command(
        items,
        "Etat du menu",
        "ezzmenustatus",
        4
    );

    return pintemod_menu_add_back(items);
}

// ------------------------------------------------------------
// Perks
// ------------------------------------------------------------

function pintemod_menu_build_perks(player)
{
    items = [];
    target = pintemod_menu_get_target(player).name;

    items = pintemod_menu_add_command(
        items,
        "Juggernog",
        "ezzperk " + target + " jug",
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Quick Revive",
        "ezzperk " + target + " quick",
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Speed Cola",
        "ezzperk " + target + " speed",
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Double Tap II",
        "ezzperk " + target + " doubletap",
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Stamin-Up",
        "ezzperk " + target + " staminup",
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Deadshot Daiquiri",
        "ezzperk " + target + " deadshot",
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Mule Kick",
        "ezzperk " + target + " mule",
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Electric Cherry",
        "ezzperk " + target + " cherry",
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Widow's Wine",
        "ezzperk " + target + " widows",
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Everyone les perks",
        "ezzallperks " + target,
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Clear all perks",
        "ezzclearperks " + target,
        2
    );

    return pintemod_menu_add_back(items);
}

// ------------------------------------------------------------
// Weapons root
// ------------------------------------------------------------

function pintemod_menu_build_weapons(player)
{
    items = [];

    items = pintemod_menu_add_open(
        items,
        "Armes speciales de la map",
        "weapons_special",
        2
    );

    items = pintemod_menu_add_open(
        items,
        "Fusils d'assaut",
        "weapons_assault",
        2
    );

    items = pintemod_menu_add_open(
        items,
        "PM",
        "weapons_smg",
        2
    );

    items = pintemod_menu_add_open(
        items,
        "Fusils a pompe",
        "weapons_shotguns",
        2
    );

    items = pintemod_menu_add_open(
        items,
        "Mitrailleuses",
        "weapons_lmg",
        2
    );

    items = pintemod_menu_add_open(
        items,
        "Snipers",
        "weapons_snipers",
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Pack-a-Punch arme tenue",
        "ezzpapweapon " + pintemod_menu_get_target(player).name,
        2
    );

    return pintemod_menu_add_back(items);
}

function pintemod_menu_add_weapon(items, target, label, alias)
{
    return pintemod_menu_add_command(
        items,
        label,
        "ezzweapon " + target + " " + alias,
        2
    );
}

function pintemod_menu_build_weapons_special(player)
{
    items = [];
    target = pintemod_menu_get_target(player).name;
    map_name = pintemod_menu_get_map_name();

    items = pintemod_menu_add_weapon(
        items,
        target,
        "Ray Gun",
        "raygun"
    );

    items = pintemod_menu_add_weapon(
        items,
        target,
        "Ray Gun Mark II",
        "raygunmk2"
    );

    switch (map_name)
    {
        case "zm_zod":
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Apothicon Servant",
                "apothicon"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Li'l Arnies",
                "arnies"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Annihilator",
                "annihilator"
            );
            break;

        case "zm_factory":
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Wunderwaffe DG-2",
                "wunderwaffe"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Annihilator",
                "annihilator"
            );
            break;

        case "zm_castle":
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Wrath of the Ancients",
                "bow"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Storm Bow",
                "stormbow"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Fire Bow",
                "firebow"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Wolf Bow",
                "wolfbow"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Void Bow",
                "voidbow"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Ragnarok DG-4",
                "ragnarok"
            );
            break;

        case "zm_island":
            items = pintemod_menu_add_weapon(
                items,
                target,
                "KT-4",
                "kt4"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Masamune",
                "masamune"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Skull of Nan Sapwe",
                "skull"
            );
            break;

        case "zm_stalingrad":
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Ray Gun Mark III",
                "raygunmk3"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Gauntlet of Siegfried",
                "gauntlet"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Dragon Strike",
                "dragonstrike"
            );
            break;

        case "zm_genesis":
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Apothicon Servant",
                "apothicon"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Thundergun",
                "thundergun"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Li'l Arnies",
                "arnies"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Ragnarok DG-4",
                "ragnarok"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Katana",
                "katana"
            );
            break;

        case "zm_prototype":
        case "zm_theater":
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Thundergun",
                "thundergun"
            );
            break;

        case "zm_asylum":
        case "zm_sumpf":
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Wunderwaffe DG-2",
                "wunderwaffe"
            );
            break;

        case "zm_cosmodrome":
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Thundergun",
                "thundergun"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Gersh Device",
                "gersh"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Matryoshka Dolls",
                "dolls"
            );
            break;

        case "zm_temple":
            items = pintemod_menu_add_weapon(
                items,
                target,
                "31-79 JGb215",
                "babygun"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Monkey Bomb",
                "monkey"
            );
            break;

        case "zm_moon":
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Wave Gun",
                "wavegun"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "QED",
                "qed"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Gersh Device",
                "gersh"
            );
            break;

        case "zm_tomb":
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Wind Staff",
                "windstaff"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Ice Staff",
                "icestaff"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Lightning Staff",
                "lightningstaff"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "Fire Staff",
                "firestaff"
            );
            items = pintemod_menu_add_weapon(
                items,
                target,
                "G-Strike",
                "gstrike"
            );
            break;
    }

    return pintemod_menu_add_back(items);
}

function pintemod_menu_build_weapons_assault(player)
{
    items = [];
    target = pintemod_menu_get_target(player).name;

    items = pintemod_menu_add_weapon(items, target, "KN-44", "kn44");
    items = pintemod_menu_add_weapon(items, target, "HVK-30", "hvk");
    items = pintemod_menu_add_weapon(items, target, "ICR-1", "icr");
    items = pintemod_menu_add_weapon(items, target, "Man-O-War", "manowar");

    return pintemod_menu_add_back(items);
}

function pintemod_menu_build_weapons_smg(player)
{
    items = [];
    target = pintemod_menu_get_target(player).name;

    items = pintemod_menu_add_weapon(items, target, "Kuda", "kuda");
    items = pintemod_menu_add_weapon(items, target, "VMP", "vmp");

    return pintemod_menu_add_back(items);
}

function pintemod_menu_build_weapons_shotguns(player)
{
    items = [];
    target = pintemod_menu_get_target(player).name;

    items = pintemod_menu_add_weapon(items, target, "KRM-262", "krm");
    items = pintemod_menu_add_weapon(items, target, "205 Brecci", "brecci");
    items = pintemod_menu_add_weapon(items, target, "Haymaker 12", "haymaker");
    items = pintemod_menu_add_weapon(items, target, "Argus", "argus");

    return pintemod_menu_add_back(items);
}

function pintemod_menu_build_weapons_lmg(player)
{
    items = [];
    target = pintemod_menu_get_target(player).name;

    items = pintemod_menu_add_weapon(items, target, "BRM", "brm");
    items = pintemod_menu_add_weapon(items, target, "Dingo", "dingo");
    items = pintemod_menu_add_weapon(items, target, "Gorgon", "gorgon");
    items = pintemod_menu_add_weapon(items, target, "48 Dredge", "dredge");

    return pintemod_menu_add_back(items);
}

function pintemod_menu_build_weapons_snipers(player)
{
    items = [];
    target = pintemod_menu_get_target(player).name;

    items = pintemod_menu_add_weapon(items, target, "Drakon", "drakon");
    items = pintemod_menu_add_weapon(items, target, "Locus", "locus");
    items = pintemod_menu_add_weapon(items, target, "SVG-100", "svg");

    return pintemod_menu_add_back(items);
}

// ------------------------------------------------------------
// Rounds
// ------------------------------------------------------------

function pintemod_menu_build_rounds(player)
{
    items = [];

    items = pintemod_menu_add_command(
        items,
        "Next round",
        "ezznextround",
        3
    );

    items = pintemod_menu_add_command(
        items,
        "Sauter 5 manches",
        "ezzskiprounds 5",
        3
    );

    items = pintemod_menu_add_command(
        items,
        "Sauter 10 manches",
        "ezzskiprounds 10",
        3
    );

    items = pintemod_menu_add_command(
        items,
        "Conserver le dernier zombie",
        "ezzlastzombie",
        3
    );

    items = pintemod_menu_add_command(
        items,
        "Eliminer tous les zombies",
        "ezzkillzombies",
        3
    );

    items = pintemod_menu_add_command(
        items,
        "Compter les zombies",
        "ezzombiecount",
        3
    );

    items = pintemod_menu_add_command(
        items,
        "Informations manche",
        "ezzroundinfo",
        3
    );

    return pintemod_menu_add_back(items);
}

// ------------------------------------------------------------
// Power-Ups
// ------------------------------------------------------------

function pintemod_menu_build_powerups(player)
{
    items = [];
    target = pintemod_menu_get_target(player).name;

    items = pintemod_menu_add_command(
        items,
        "Max Ammo",
        "ezzpowerup " + target + " maxammo",
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Insta-Kill",
        "ezzpowerup " + target + " instakill",
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Double Points",
        "ezzpowerup " + target + " doublepoints",
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Fire Sale",
        "ezzpowerup " + target + " firesale",
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Carpenter",
        "ezzpowerup " + target + " carpenter",
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Nuke",
        "ezzpowerup " + target + " nuke",
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Death Machine",
        "ezzpowerup " + target + " deathmachine",
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Free Perk",
        "ezzpowerup " + target + " freeperk",
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Shield Charge",
        "ezzpowerup " + target + " shield",
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Drops PinteMod permanents ON",
        "ezzfreezepowerups on",
        3
    );

    items = pintemod_menu_add_command(
        items,
        "Drops PinteMod permanents OFF",
        "ezzfreezepowerups off",
        3
    );

    return pintemod_menu_add_back(items);
}

// ------------------------------------------------------------
// Teleport and spectator spawn
// ------------------------------------------------------------

function pintemod_menu_build_teleport(player)
{
    items = [];
    target = pintemod_menu_get_target(player).name;

    items = pintemod_menu_add_command(
        items,
        "Sauvegarder ma position",
        "ezzsave " + player.name,
        1
    );

    items = pintemod_menu_add_command(
        items,
        "Charger ma position",
        "ezzload " + player.name,
        1
    );

    items = pintemod_menu_add_command(
        items,
        "Me teleporter au viseur",
        "ezztp " + player.name + " " + player.name,
        1
    );

    items = pintemod_menu_add_command(
        items,
        "Teleporter la cible au viseur",
        "ezztp " + player.name + " " + target,
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Faire apparaitre la cible",
        "ezzspawn " + target,
        1
    );

    items = pintemod_menu_add_command(
        items,
        "Etat navigation cible",
        "ezznavstatus " + target,
        1
    );

    return pintemod_menu_add_back(items);
}

// ------------------------------------------------------------
// Map control
// ------------------------------------------------------------

function pintemod_menu_build_maps(player)
{
    items = [];

    items = pintemod_menu_add_command(
        items,
        "Activer le courant",
        "ezzpower",
        3
    );

    items = pintemod_menu_add_command(
        items,
        "Enable Pack-a-Punch",
        "ezzpap",
        3
    );

    items = pintemod_menu_add_command(
        items,
        "Ouvrir les passages standards",
        "ezzunlock",
        3
    );

    items = pintemod_menu_add_command(
        items,
        "Profil de la map",
        "ezzmapstatus",
        3
    );

    items = pintemod_menu_add_command(
        items,
        "Etat du courant",
        "ezzpowerstatus",
        3
    );

    items = pintemod_menu_add_command(
        items,
        "Etat Pack-a-Punch",
        "ezzpapstatus",
        3
    );

    items = pintemod_menu_add_command(
        items,
        "Etat des passages",
        "ezzunlockstatus",
        3
    );

    return pintemod_menu_add_back(items);
}

// ------------------------------------------------------------
// Events — map-specific validated bosses
// ------------------------------------------------------------

function pintemod_menu_build_events(player)
{
    items = [];
    map_name = toLower(GetDvarString("mapname"));
    target_name = player.pintemod_menu_target_name;

    if (!isdefined(target_name) || target_name == "")
        target_name = player.name;

    switch (map_name)
    {
        case "zm_zod":
            items = pintemod_menu_add_command(
                items,
                "Spawn Margwa",
                "ezzspawnmargwa " + target_name,
                3
            );
            break;

        case "zm_tomb":
            items = pintemod_menu_add_command(
                items,
                "Spawn Origins Panzer",
                "ezzspawnpanzer " + target_name,
                3
            );
            break;

        case "zm_castle":
            items = pintemod_menu_add_command(
                items,
                "Spawn Castle Panzer",
                "ezzspawncastlepanzer " + target_name,
                3
            );
            break;

        case "zm_island":
            items = pintemod_menu_add_command(
                items,
                "Spawn Thrasher",
                "ezzspawnthrasher " + target_name,
                3
            );
            break;

        case "zm_stalingrad":
            items = pintemod_menu_add_command(
                items,
                "Spawn Gorod Mechz",
                "ezzspawnstalingradpanzer " + target_name,
                3
            );
            break;

        case "zm_genesis":
            items = pintemod_menu_add_command(
                items,
                "Spawn Margwa",
                "ezzspawngenesismargwa " + target_name,
                3
            );

            items = pintemod_menu_add_command(
                items,
                "Spawn Shadow Margwa",
                "ezzspawngenesisshadow " + target_name,
                3
            );

            items = pintemod_menu_add_command(
                items,
                "Spawn Fire Margwa",
                "ezzspawngenesisfire " + target_name,
                3
            );

            items = pintemod_menu_add_command(
                items,
                "Spawn Revelations Panzer",
                "ezzspawngenesispanzer " + target_name,
                3
            );
            break;

        case "zm_moon":
            items = pintemod_menu_add_command(
                items,
                "Spawn Astronaut",
                "ezzspawnastro " + target_name,
                3
            );
            break;

        default:
            items = pintemod_menu_add_command(
                items,
                "No validated boss on this map",
                "ezzeventstatus",
                3
            );
            break;
    }

    items = pintemod_menu_add_command(
        items,
        "Boss Event Status",
        "ezzeventstatus",
        3
    );

    return pintemod_menu_add_back(items);
}

// ------------------------------------------------------------
// Music — global playback
// ------------------------------------------------------------

function pintemod_menu_build_music(player)
{
    items = [];
    map_name = toLower(GetDvarString("mapname"));

    switch (map_name)
    {
        case "zm_zod":
            items = pintemod_menu_add_command(
                items,
                "Snakeskin Boots - Everyone",
                "ezzmusicplayall 1",
                3
            );
            items = pintemod_menu_add_command(
                items,
                "Cold Hard Cash - Everyone",
                "ezzmusicplayall 2",
                3
            );
            break;

        case "zm_factory":
            items = pintemod_menu_add_command(
                items,
                "Special Music - Everyone",
                "ezzmusicplayall 1",
                3
            );
            break;

        case "zm_castle":
            items = pintemod_menu_add_command(
                items,
                "Dead Again - Everyone",
                "ezzmusicplayall 1",
                3
            );
            break;

        case "zm_island":
            items = pintemod_menu_add_command(
                items,
                "Dead Flowers - indisponible",
                "ezzmusicstatus",
                3
            );
            break;

        case "zm_stalingrad":
            items = pintemod_menu_add_command(
                items,
                "Ace of Spades - Everyone",
                "ezzmusicplayall 1",
                3
            );
            items = pintemod_menu_add_command(
                items,
                "Dead Ended - Everyone",
                "ezzmusicplayall 2",
                3
            );
            break;

        case "zm_genesis":
            items = pintemod_menu_add_command(
                items,
                "The Gift - Everyone",
                "ezzmusicplayall 1",
                3
            );
            break;

        case "zm_prototype":
            items = pintemod_menu_add_command(
                items,
                "No music configured",
                "ezzmusicstatus",
                3
            );
            break;

        case "zm_asylum":
            items = pintemod_menu_add_command(
                items,
                "Lullaby for a Dead Man - Everyone",
                "ezzmusicplayall 1",
                3
            );
            break;

        case "zm_sumpf":
            items = pintemod_menu_add_command(
                items,
                "The One - Everyone",
                "ezzmusicplayall 1",
                3
            );
            break;

        case "zm_theater":
            items = pintemod_menu_add_command(
                items,
                "115 - Everyone",
                "ezzmusicplayall 1",
                3
            );
            break;

        case "zm_cosmodrome":
            items = pintemod_menu_add_command(
                items,
                "Abracadavre - Everyone",
                "ezzmusicplayall 1",
                3
            );
            break;

        case "zm_temple":
            items = pintemod_menu_add_command(
                items,
                "Pareidolia - Everyone",
                "ezzmusicplayall 1",
                3
            );
            break;

        case "zm_moon":
            items = pintemod_menu_add_command(
                items,
                "Coming Home - Everyone",
                "ezzmusicplayall 1",
                3
            );
            items = pintemod_menu_add_command(
                items,
                "Nightmare - Everyone",
                "ezzmusicplayall 2",
                3
            );
            break;

        case "zm_tomb":
            items = pintemod_menu_add_command(
                items,
                "Archangel - Everyone",
                "ezzmusicplayall 1",
                3
            );
            break;

        default:
            items = pintemod_menu_add_command(
                items,
                "Map not configured",
                "ezzmusicstatus",
                3
            );
            break;
    }

    items = pintemod_menu_add_command(
        items,
        "Stop music - Everyone",
        "ezzmusicstopall",
        3
    );

    items = pintemod_menu_add_command(
        items,
        "Music status",
        "ezzmusicstatus",
        3
    );

    return pintemod_menu_add_back(items);
}

// ------------------------------------------------------------
// Fun and player assistance
// ------------------------------------------------------------

function pintemod_menu_build_fun(player)
{
    items = [];
    target_player = pintemod_menu_get_target(player);
    target = target_player.name;

    noclip_label = "Noclip unavailable on BOIII";

    if (isdefined(target_player.pintemod_noclip_active) &&
        target_player.pintemod_noclip_active)
    {
        noclip_label = "Noclip unavailable on BOIII";
    }

    items = pintemod_menu_add_item(
        items,
        noclip_label,
        "noclip",
        "ezznoclip " + target,
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Target God Mode",
        "godmode " + target,
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Munitions cible",
        "ammo " + target,
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Points maximum cible",
        "maxpoints " + target,
        2
    );

    items = pintemod_menu_add_command(
        items,
        "Ignorer la cible",
        "ignore " + target,
        2
    );

    return pintemod_menu_add_back(items);
}

// ------------------------------------------------------------
// Category dispatcher and parent hierarchy
// ------------------------------------------------------------

function pintemod_menu_get_parent_category(category)
{
    switch (category)
    {
        case "weapons_special":
        case "weapons_assault":
        case "weapons_smg":
        case "weapons_shotguns":
        case "weapons_lmg":
        case "weapons_snipers":
            return "weapons";
    }

    return "main";
}

function pintemod_menu_build_category(player, category)
{
    switch (category)
    {
        case "main":
            return pintemod_menu_build_main(player);

        case "players":
            return pintemod_menu_build_players(player);

        case "administration":
            return pintemod_menu_build_administration(player);

        case "perks":
            return pintemod_menu_build_perks(player);

        case "weapons":
            return pintemod_menu_build_weapons(player);

        case "weapons_special":
            return pintemod_menu_build_weapons_special(player);

        case "weapons_assault":
            return pintemod_menu_build_weapons_assault(player);

        case "weapons_smg":
            return pintemod_menu_build_weapons_smg(player);

        case "weapons_shotguns":
            return pintemod_menu_build_weapons_shotguns(player);

        case "weapons_lmg":
            return pintemod_menu_build_weapons_lmg(player);

        case "weapons_snipers":
            return pintemod_menu_build_weapons_snipers(player);

        case "rounds":
            return pintemod_menu_build_rounds(player);

        case "powerups":
            return pintemod_menu_build_powerups(player);

        case "teleport":
            return pintemod_menu_build_teleport(player);

        case "maps":
            return pintemod_menu_build_maps(player);

        case "events":
            return pintemod_menu_build_events(player);

        case "music":
            return pintemod_menu_build_music(player);

        case "fun":
            return pintemod_menu_build_fun(player);
    }

    return pintemod_menu_build_main(player);
}

function pintemod_menu_category_title(category)
{
    switch (category)
    {
        case "main":
            return "PINTE MOD";

        case "players":
            return "JOUEURS / TARGET";

        case "administration":
            return "ADMINISTRATION";

        case "perks":
            return "PERKS";

        case "weapons":
            return "WEAPONS";

        case "weapons_special":
            return "ARMES SPECIALES";

        case "weapons_assault":
            return "FUSILS D'ASSAUT";

        case "weapons_smg":
            return "PISTOLETS-MITRAILLEURS";

        case "weapons_shotguns":
            return "FUSILS A POMPE";

        case "weapons_lmg":
            return "MITRAILLEUSES";

        case "weapons_snipers":
            return "SNIPERS";

        case "rounds":
            return "ROUNDS";

        case "powerups":
            return "POWER-UPS";

        case "teleport":
            return "TELEPORT / SPAWN";

        case "maps":
            return "MAP";

        case "events":
            return "EVENTS";

        case "music":
            return "SPECIAL MUSIC";

        case "fun":
            return "FUN";
    }

    return "PINTE MOD";
}

// ------------------------------------------------------------
// HUD creation
// ------------------------------------------------------------

function pintemod_menu_create_hud(player)
{
    player.pintemod_menu_elements = [];
    player.pintemod_menu_lines = [];

    shadow = NewClientHudElem(player);
    shadow.horzAlign = "left";
    shadow.vertAlign = "top";
    shadow.alignX = "left";
    shadow.alignY = "top";
    shadow.x = 363;
    shadow.y = 63;
    shadow.sort = 998;
    shadow.alpha = 0.35;
    shadow.color = (0, 0, 0);
    shadow SetShader("white", 255, 330);

    player.pintemod_menu_elements[
        player.pintemod_menu_elements.size
    ] = shadow;

    background = NewClientHudElem(player);
    background.horzAlign = "left";
    background.vertAlign = "top";
    background.alignX = "left";
    background.alignY = "top";
    background.x = 357;
    background.y = 57;
    background.sort = 1000;
    background.alpha = 0.95;
    background.color = (0.018, 0.022, 0.029);
    background SetShader("white", 255, 330);

    player.pintemod_menu_elements[
        player.pintemod_menu_elements.size
    ] = background;

    border_top = NewClientHudElem(player);
    border_top.horzAlign = "left";
    border_top.vertAlign = "top";
    border_top.alignX = "left";
    border_top.alignY = "top";
    border_top.x = 357;
    border_top.y = 57;
    border_top.sort = 1001;
    border_top.alpha = 1;
    border_top.color = (0.93, 0.49, 0.12);
    border_top SetShader("white", 255, 3);

    player.pintemod_menu_elements[
        player.pintemod_menu_elements.size
    ] = border_top;

    border_left = NewClientHudElem(player);
    border_left.horzAlign = "left";
    border_left.vertAlign = "top";
    border_left.alignX = "left";
    border_left.alignY = "top";
    border_left.x = 357;
    border_left.y = 57;
    border_left.sort = 1001;
    border_left.alpha = 1;
    border_left.color = (0.93, 0.49, 0.12);
    border_left SetShader("white", 3, 330);

    player.pintemod_menu_elements[
        player.pintemod_menu_elements.size
    ] = border_left;

    border_right = NewClientHudElem(player);
    border_right.horzAlign = "left";
    border_right.vertAlign = "top";
    border_right.alignX = "left";
    border_right.alignY = "top";
    border_right.x = 609;
    border_right.y = 57;
    border_right.sort = 1001;
    border_right.alpha = 0.78;
    border_right.color = (0.93, 0.49, 0.12);
    border_right SetShader("white", 3, 330);

    player.pintemod_menu_elements[
        player.pintemod_menu_elements.size
    ] = border_right;

    border_bottom = NewClientHudElem(player);
    border_bottom.horzAlign = "left";
    border_bottom.vertAlign = "top";
    border_bottom.alignX = "left";
    border_bottom.alignY = "top";
    border_bottom.x = 357;
    border_bottom.y = 384;
    border_bottom.sort = 1001;
    border_bottom.alpha = 0.78;
    border_bottom.color = (0.93, 0.49, 0.12);
    border_bottom SetShader("white", 255, 3);

    player.pintemod_menu_elements[
        player.pintemod_menu_elements.size
    ] = border_bottom;

    header_tint = NewClientHudElem(player);
    header_tint.horzAlign = "left";
    header_tint.vertAlign = "top";
    header_tint.alignX = "left";
    header_tint.alignY = "top";
    header_tint.x = 360;
    header_tint.y = 60;
    header_tint.sort = 1001;
    header_tint.alpha = 0.23;
    header_tint.color = (0.30, 0.12, 0.025);
    header_tint SetShader("white", 249, 84);

    player.pintemod_menu_elements[
        player.pintemod_menu_elements.size
    ] = header_tint;

    footer_tint = NewClientHudElem(player);
    footer_tint.horzAlign = "left";
    footer_tint.vertAlign = "top";
    footer_tint.alignX = "left";
    footer_tint.alignY = "top";
    footer_tint.x = 360;
    footer_tint.y = 324;
    footer_tint.sort = 1001;
    footer_tint.alpha = 0.34;
    footer_tint.color = (0.055, 0.060, 0.072);
    footer_tint SetShader("white", 249, 58);

    player.pintemod_menu_elements[
        player.pintemod_menu_elements.size
    ] = footer_tint;

    // The diagnostic established that 1.0 is the smallest reliable
    // scale on this BOIII installation.
    title = player hud::createFontString("default", 1.0);
    title.horzAlign = "left";
    title.vertAlign = "top";
    title.alignX = "left";
    title.alignY = "top";
    title.x = 373;
    title.y = 70;
    title.sort = 1004;
    title.alpha = 1;
    title.color = (1, 0.76, 0.36);
    title SetText("PINTE MOD");

    player.pintemod_menu_title = title;
    player.pintemod_menu_elements[
        player.pintemod_menu_elements.size
    ] = title;

    role_label = player hud::createFontString("default", 1.0);
    role_label.horzAlign = "left";
    role_label.vertAlign = "top";
    role_label.alignX = "left";
    role_label.alignY = "top";
    role_label.x = 373;
    role_label.y = 100;
    role_label.sort = 1004;
    role_label.alpha = 0.9;
    role_label.color = (0.70, 0.42, 0.95);
    role_label SetText("ROLE");

    player.pintemod_menu_elements[
        player.pintemod_menu_elements.size
    ] = role_label;

    role_value = player hud::createFontString("default", 1.0);
    role_value.horzAlign = "left";
    role_value.vertAlign = "top";
    role_value.alignX = "left";
    role_value.alignY = "top";
    role_value.x = 425;
    role_value.y = 100;
    role_value.sort = 1004;
    role_value.alpha = 1;
    role_value.color = (0.86, 0.89, 0.95);
    role_value SetText("");

    player.pintemod_menu_role_value = role_value;
    player.pintemod_menu_elements[
        player.pintemod_menu_elements.size
    ] = role_value;

    target_label = player hud::createFontString("default", 1.0);
    target_label.horzAlign = "left";
    target_label.vertAlign = "top";
    target_label.alignX = "left";
    target_label.alignY = "top";
    target_label.x = 373;
    target_label.y = 120;
    target_label.sort = 1004;
    target_label.alpha = 0.9;
    target_label.color = (0.70, 0.42, 0.95);
    target_label SetText("TARGET");

    player.pintemod_menu_elements[
        player.pintemod_menu_elements.size
    ] = target_label;

    target_value = player hud::createFontString("default", 1.0);
    target_value.horzAlign = "left";
    target_value.vertAlign = "top";
    target_value.alignX = "left";
    target_value.alignY = "top";
    target_value.x = 425;
    target_value.y = 120;
    target_value.sort = 1004;
    target_value.alpha = 1;
    target_value.color = (0.60, 0.86, 0.10);
    target_value SetText("");

    player.pintemod_menu_target_value = target_value;
    player.pintemod_menu_elements[
        player.pintemod_menu_elements.size
    ] = target_value;

    separator = NewClientHudElem(player);
    separator.horzAlign = "left";
    separator.vertAlign = "top";
    separator.alignX = "left";
    separator.alignY = "top";
    separator.x = 371;
    separator.y = 145;
    separator.sort = 1002;
    separator.alpha = 0.55;
    separator.color = (0.32, 0.34, 0.39);
    separator SetShader("white", 225, 1);

    player.pintemod_menu_elements[
        player.pintemod_menu_elements.size
    ] = separator;

    selector = NewClientHudElem(player);
    selector.horzAlign = "left";
    selector.vertAlign = "top";
    selector.alignX = "left";
    selector.alignY = "top";
    selector.x = 369;
    selector.y = 154;
    selector.sort = 1002;
    selector.alpha = 0.88;
    selector.color = (0.48, 0.22, 0.04);
    selector SetShader("white", 229, 22);

    player.pintemod_menu_selector = selector;
    player.pintemod_menu_elements[
        player.pintemod_menu_elements.size
    ] = selector;

    selector_accent = NewClientHudElem(player);
    selector_accent.horzAlign = "left";
    selector_accent.vertAlign = "top";
    selector_accent.alignX = "left";
    selector_accent.alignY = "top";
    selector_accent.x = 369;
    selector_accent.y = 154;
    selector_accent.sort = 1003;
    selector_accent.alpha = 1;
    selector_accent.color = (1, 0.55, 0.13);
    selector_accent SetShader("white", 3, 22);

    player.pintemod_menu_selector_accent = selector_accent;
    player.pintemod_menu_elements[
        player.pintemod_menu_elements.size
    ] = selector_accent;

    for (i = 0; i < 6; i++)
    {
        line = player hud::createFontString("default", 1.0);
        line.horzAlign = "left";
        line.vertAlign = "top";
        line.alignX = "left";
        line.alignY = "top";
        line.x = 380;
        line.y = 157 + (i * 27);
        line.sort = 1004;
        line.alpha = 1;
        line.color = (0.78, 0.82, 0.88);
        line SetText("");

        player.pintemod_menu_lines[i] = line;
        player.pintemod_menu_elements[
            player.pintemod_menu_elements.size
        ] = line;
    }

    footer_separator = NewClientHudElem(player);
    footer_separator.horzAlign = "left";
    footer_separator.vertAlign = "top";
    footer_separator.alignX = "left";
    footer_separator.alignY = "top";
    footer_separator.x = 371;
    footer_separator.y = 323;
    footer_separator.sort = 1003;
    footer_separator.alpha = 0.55;
    footer_separator.color = (0.32, 0.34, 0.39);
    footer_separator SetShader("white", 225, 1);

    player.pintemod_menu_elements[
        player.pintemod_menu_elements.size
    ] = footer_separator;

    footer = player hud::createFontString("default", 1.0);
    footer.horzAlign = "left";
    footer.vertAlign = "top";
    footer.alignX = "left";
    footer.alignY = "top";
    footer.x = 373;
    footer.y = 335;
    footer.sort = 1004;
    footer.alpha = 0.9;
    footer.color = (0.72, 0.76, 0.82);
    footer SetText("^32 ^7Up  ^34 ^7Down  ^3Use ^7Select");

    player.pintemod_menu_elements[
        player.pintemod_menu_elements.size
    ] = footer;

    footer_back = player hud::createFontString("default", 1.0);
    footer_back.horzAlign = "left";
    footer_back.vertAlign = "top";
    footer_back.alignX = "left";
    footer_back.alignY = "top";
    footer_back.x = 373;
    footer_back.y = 356;
    footer_back.sort = 1004;
    footer_back.alpha = 0.9;
    footer_back.color = (0.72, 0.76, 0.82);
    footer_back SetText("^3Melee ^7Retour / Fermer");

    player.pintemod_menu_elements[
        player.pintemod_menu_elements.size
    ] = footer_back;
}

function pintemod_menu_destroy(player)
{
    if (isdefined(player.pintemod_menu_elements))
    {
        for (i = 0; i < player.pintemod_menu_elements.size; i++)
        {
            element = player.pintemod_menu_elements[i];

            if (isdefined(element))
                element Destroy();
        }
    }

    player.pintemod_menu_elements = undefined;
    player.pintemod_menu_lines = undefined;
    player.pintemod_menu_title = undefined;
    player.pintemod_menu_role_value = undefined;
    player.pintemod_menu_target_value = undefined;
    player.pintemod_menu_selector = undefined;
    player.pintemod_menu_selector_accent = undefined;
    player.pintemod_menu_items = undefined;
    player.pintemod_menu_category = undefined;
    player.pintemod_menu_open = false;
    player.pintemod_menu_selected = 0;

    player EnableOffhandWeapons();
    player SetBlur(0, 0.15);
}

// ------------------------------------------------------------
// Rendering
// ------------------------------------------------------------

function pintemod_menu_render(player)
{
    items = player.pintemod_menu_items;

    if (!isdefined(items) || items.size <= 0)
        return;

    selected = player.pintemod_menu_selected;

    if (selected < 0)
        selected = items.size - 1;

    if (selected >= items.size)
        selected = 0;

    player.pintemod_menu_selected = selected;

    first_visible = 0;

    if (selected >= 6)
        first_visible = selected - 5;

    target = pintemod_menu_get_target(player);
    role_name = pintemod_menu_role_name(
        pintemod_menu_get_role(player)
    );
    map_display = pintemod_menu_get_map_display_name(
        pintemod_menu_get_map_name()
    );

    player.pintemod_menu_title SetText(
        pintemod_menu_category_title(
            player.pintemod_menu_category
        )
    );

    player.pintemod_menu_role_value SetText(role_name);

    player.pintemod_menu_target_value SetText(target.name);

    visible_selected = selected - first_visible;

    player.pintemod_menu_selector.y =
        154 + (visible_selected * 27);

    player.pintemod_menu_selector_accent.y =
        154 + (visible_selected * 27);

    for (i = 0; i < 6; i++)
    {
        item_index = first_visible + i;
        line = player.pintemod_menu_lines[i];

        if (item_index >= items.size)
        {
            line SetText("");
            continue;
        }

        item = items[item_index];

        if (item_index == selected)
        {
            line.color = (1, 1, 1);
            line SetText("^7> " + item.label);
        }
        else
        {
            line.color = (0.70, 0.75, 0.82);
            line SetText("^7  " + item.label);
        }
    }
}

function pintemod_menu_open_category(player, category)
{
    player.pintemod_menu_category = category;
    player.pintemod_menu_selected = 0;
    player.pintemod_menu_items = pintemod_menu_build_category(
        player,
        category
    );

    pintemod_menu_render(player);
}

// ------------------------------------------------------------
// Item execution
// ------------------------------------------------------------

function pintemod_menu_execute_selected(player)
{
    items = player.pintemod_menu_items;

    if (!isdefined(items) || items.size <= 0)
        return;

    item = items[player.pintemod_menu_selected];

    switch (item.action)
    {
        case "open":
            pintemod_menu_open_category(player, item.value);
            return;

        case "back":
            parent = pintemod_menu_get_parent_category(
                player.pintemod_menu_category
            );

            pintemod_menu_open_category(player, parent);
            return;

        case "close":
            player notify("pintemod_menu_close");
            return;

        case "target":
            player.pintemod_menu_target_name = item.value;

            player tell(
                "^2[PinteMod]^7 Cible selectionnee : " +
                item.value
            );

            pintemod_menu_open_category(player, "main");
            return;

        case "command":
            executecommand(item.value);

            player tell(
                "^6[PinteMod]^7 Commande executee : ^3" +
                item.label
            );
            return;

        case "noclip":
            player thread pintemod_menu_delayed_command(item.value);
            player notify("pintemod_menu_close");
            return;
    }
}

function pintemod_menu_delayed_command(command_line)
{
    self endon("disconnect");

    // Allow the HUD cleanup to restore menu-specific controls first.
    wait 0.2;

    executecommand(command_line);
}

// ------------------------------------------------------------
// Input loop
// ------------------------------------------------------------

function pintemod_menu_move_selection(player, direction)
{
    player.pintemod_menu_selected += direction;

    if (player.pintemod_menu_selected < 0)
    {
        player.pintemod_menu_selected =
            player.pintemod_menu_items.size - 1;
    }

    if (player.pintemod_menu_selected >=
        player.pintemod_menu_items.size)
    {
        player.pintemod_menu_selected = 0;
    }

    pintemod_menu_render(player);
}

function pintemod_menu_input_loop()
{
    self endon("disconnect");
    self endon("pintemod_menu_close");

    up_was_down = false;
    down_was_down = false;
    use_was_down = false;
    reload_was_down = false;
    melee_was_down = false;

    up_hold_ticks = 0;
    down_hold_ticks = 0;

    for (;;)
    {
        if (isdefined(self.sessionstate) &&
            self.sessionstate == "spectator")
        {
            self notify("pintemod_menu_close");
            return;
        }

        up_is_down = self ActionSlotTwoButtonPressed();
        down_is_down = self ActionSlotThreeButtonPressed();
        use_is_down = self UseButtonPressed();
        reload_is_down = self ReloadButtonPressed();
        melee_is_down = self MeleeButtonPressed();

        if (up_is_down)
        {
            if (!up_was_down || up_hold_ticks >= 5)
            {
                pintemod_menu_move_selection(self, -1);

                if (up_hold_ticks >= 5)
                    up_hold_ticks = 3;
            }

            up_hold_ticks++;
        }
        else
        {
            up_hold_ticks = 0;
        }

        if (down_is_down)
        {
            if (!down_was_down || down_hold_ticks >= 5)
            {
                pintemod_menu_move_selection(self, 1);

                if (down_hold_ticks >= 5)
                    down_hold_ticks = 3;
            }

            down_hold_ticks++;
        }
        else
        {
            down_hold_ticks = 0;
        }

        if ((use_is_down && !use_was_down) ||
            (reload_is_down && !reload_was_down))
        {
            pintemod_menu_execute_selected(self);
        }

        if (melee_is_down && !melee_was_down)
        {
            if (self.pintemod_menu_category == "main")
            {
                self notify("pintemod_menu_close");
                return;
            }

            parent = pintemod_menu_get_parent_category(
                self.pintemod_menu_category
            );

            pintemod_menu_open_category(self, parent);
        }

        up_was_down = up_is_down;
        down_was_down = down_is_down;
        use_was_down = use_is_down;
        reload_was_down = reload_is_down;
        melee_was_down = melee_is_down;

        wait 0.05;
    }
}

// ------------------------------------------------------------
// Lifecycle
// ------------------------------------------------------------

function pintemod_menu_run()
{
    self endon("disconnect");

    self notify("pintemod_menu_close");
    wait 0.05;

    self.pintemod_menu_open = true;
    self.pintemod_menu_target_name = self.name;

    // Keys 2 and 4 use Action Slot 2 and Action Slot 3.
    // Offhand equipment remains suppressed while the menu is open.
    self DisableOffhandWeapons();

    pintemod_menu_create_hud(self);
    self SetBlur(1.6, 0.15);

    pintemod_menu_open_category(self, "main");

    self thread pintemod_menu_input_loop();

    self waittill("pintemod_menu_close");

    pintemod_menu_destroy(self);
}

function cmd_ezzmenu(args)
{
    if (args.size <= 0)
    {
        println("^5[PinteMod]^7 Usage: ezzmenu <PlayerName>");
        return;
    }

    player = pintemod_menu_find_player_exact(args[0]);

    if (!isdefined(player))
    {
        println("^1[PinteMod] Player not found: " + args[0]);
        return;
    }

    role = pintemod_menu_get_role(player);

    if (role <= 0)
    {
        println("^1[PinteMod] Player has no menu permission");
        player tell("^1[PinteMod]^7 Permission menu refusee");
        return;
    }

    if (isdefined(player.pintemod_menu_open) &&
        player.pintemod_menu_open)
    {
        player notify("pintemod_menu_close");
        return;
    }

    println(
        "^5[PinteMod]^7 Opening full HUD menu for " +
        player.name
    );

    player thread pintemod_menu_run();
}

function cmd_ezzmenuclose(args)
{
    if (args.size <= 0)
    {
        println("^5[PinteMod]^7 Usage: ezzmenuclose <PlayerName>");
        return;
    }

    player = pintemod_menu_find_player_exact(args[0]);

    if (!isdefined(player))
    {
        println("^1[PinteMod] Player not found: " + args[0]);
        return;
    }

    player notify("pintemod_menu_close");

    println("^5[PinteMod]^7 Menu close requested for " + player.name);
}

// ------------------------------------------------------------
// Server-side scripted noclip
// ------------------------------------------------------------

function pintemod_noclip_get_target(args)
{
    if (args.size > 0)
        return pintemod_menu_find_player_exact(args[0]);

    players = GetPlayers();

    if (players.size == 1)
        return players[0];

    return undefined;
}

function cmd_ezznoclip(args)
{
    player = undefined;

    if (args.size >= 1)
        player = pintemod_menu_find_player_exact(args[0]);

    println(
        "^3[PinteMod]^7 Noclip disabled: " +
        "server-only movement kills the player on this BOIII build"
    );

    if (isdefined(player))
    {
        player tell(
            "^3[PinteMod]^7 Noclip unavailable on this server"
        );
    }
}

function cmd_ezzmenustatus(args)
{
    players = GetPlayers();

    println("^5========== PINTE MOD MENU ==========");
    println("^7Version: " + level.pintemod_menu_version);

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (!isdefined(player))
            continue;

        state = "CLOSED";

        if (isdefined(player.pintemod_menu_open) &&
            player.pintemod_menu_open)
        {
            state = "OPEN";
        }

        println(
            "^7" + player.name +
            " | " +
            pintemod_menu_role_name(
                pintemod_menu_get_role(player)
            ) +
            " | " + state
        );
    }

    println("^5====================================");
}
