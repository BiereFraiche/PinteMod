// ============================================================
// PinteMod — All-Map Special Music v0.5.0
// File: ezz_admin_music.gsc
// Created by BiereFraiche and ChatGPT
//
// Reuses only the musicCmd registry already initialized
// by the map. Music is sent to all players
// currently connected.
//
// Zetsubou No Shima remains disabled because the map does not expose
// the expected native music registry on this BOIII server.
// The Giant is intentionally excluded.
//
// COMMANDES CONSOLE
// ------------------------------------------------------------
// ezzmusicstatus
// ezzmusicstates
// ezzmusicplayall [1|2|StateName]
// ezzmusicstopall
// ============================================================

autoexec function init()
{
    addcommand("ezzmusicstatus", ::cmd_ezzmusicstatus);
    addcommand("ezzmusicstates", ::cmd_ezzmusicstates);
    addcommand("ezzmusicplayall", ::cmd_ezzmusicplayall);
    addcommand("ezzmusicstopall", ::cmd_ezzmusicstopall);

    level.pintemod_music_loaded = true;

    println(
        "^5[PinteMod]^7 All-Map Special Music v1.1.0 loaded"
    );
}

function music_find_player_exact(player_name)
{
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (isdefined(player) && player.name == player_name)
            return player;
    }

    return undefined;
}

function music_get_map_name()
{
    return toLower(GetDvarString("mapname"));
}

function music_has_registry()
{
    if (!isdefined(level.musicSystem))
        return false;

    if (!isdefined(level.musicSystem.states))
        return false;

    return true;
}

function music_find_state_case_insensitive(wanted_state)
{
    if (!music_has_registry())
        return undefined;

    keys = GetArrayKeys(level.musicSystem.states);
    wanted_lower = toLower(wanted_state);

    for (i = 0; i < keys.size; i++)
    {
        if (toLower(keys[i]) == wanted_lower)
            return keys[i];
    }

    return undefined;
}

function music_create_song(label, state_name)
{
    song = spawnstruct();
    song.label = label;
    song.state = state_name;

    return song;
}

function music_get_map_display_name()
{
    map_name = music_get_map_name();

    switch (map_name)
    {
        case "zm_zod":
            return "Shadows of Evil";

        case "zm_factory":
            return "Der Riese / The Giant";

        case "zm_castle":
            return "Der Eisendrache";

        case "zm_island":
            return "Zetsubou No Shima";

        case "zm_stalingrad":
            return "Gorod Krovi";

        case "zm_genesis":
            return "Revelations";

        case "zm_prototype":
            return "The Giant";

        case "zm_asylum":
            return "Verruckt";

        case "zm_sumpf":
            return "Shi No Numa";

        case "zm_theater":
            return "Kino der Toten";

        case "zm_cosmodrome":
            return "Ascension";

        case "zm_temple":
            return "Shangri-La";

        case "zm_moon":
            return "Moon";

        case "zm_tomb":
            return "Origins";
    }

    return map_name;
}

function music_get_special_songs()
{
    songs = [];
    map_name = music_get_map_name();

    switch (map_name)
    {
        case "zm_zod":
            songs[songs.size] = music_create_song(
                "Snakeskin Boots",
                "zod_egg_snakeskin"
            );
            songs[songs.size] = music_create_song(
                "Cold Hard Cash",
                "zod_egg_coldhardcash"
            );
            break;

        case "zm_factory":
            songs[songs.size] = music_create_song(
                "Special song",
                "egg"
            );
            break;

        case "zm_castle":
            songs[songs.size] = music_create_song(
                "Dead Again",
                "dead_again"
            );
            break;

        case "zm_island":
            // Dead Flowers : registre musicCmd indisponible.
            break;

        case "zm_stalingrad":
            songs[songs.size] = music_create_song(
                "Ace of Spades",
                "ace_of_spades"
            );
            songs[songs.size] = music_create_song(
                "Dead Ended",
                "dead_ended"
            );
            break;

        case "zm_genesis":
            songs[songs.size] = music_create_song(
                "The Gift",
                "the_gift"
            );
            break;

        case "zm_prototype":
            // No music requested.
            break;

        case "zm_asylum":
            songs[songs.size] = music_create_song(
                "Lullaby for a Dead Man",
                "lullaby_for_a_dead_man"
            );
            break;

        case "zm_sumpf":
            songs[songs.size] = music_create_song(
                "The One",
                "the_one"
            );
            break;

        case "zm_theater":
            songs[songs.size] = music_create_song(
                "115",
                "115"
            );
            break;

        case "zm_cosmodrome":
            songs[songs.size] = music_create_song(
                "Abracadavre",
                "abracadavre"
            );
            break;

        case "zm_temple":
            songs[songs.size] = music_create_song(
                "Pareidolia",
                "pareidolia"
            );
            break;

        case "zm_moon":
            songs[songs.size] = music_create_song(
                "Coming Home",
                "cominghome"
            );
            songs[songs.size] = music_create_song(
                "Nightmare",
                "nightmare"
            );
            break;

        case "zm_tomb":
            songs[songs.size] = music_create_song(
                "Archangel",
                "archangel"
            );
            break;
    }

    return songs;
}

function music_get_song_by_argument(argument)
{
    songs = music_get_special_songs();

    if (songs.size <= 0)
        return undefined;

    argument_lower = toLower(argument);

    if (argument_lower == "1")
        return songs[0];

    if (argument_lower == "2" && songs.size >= 2)
        return songs[1];

    for (i = 0; i < songs.size; i++)
    {
        if (toLower(songs[i].state) == argument_lower)
            return songs[i];
    }

    return undefined;
}

function music_send_existing_state(player, state_name)
{
    scripts\shared\util_shared::setClientSysState(
        "musicCmd",
        state_name,
        player
    );

    player.pintemod_music_state = state_name;

    return true;
}

function music_send_state_to_all(state_name)
{
    players = GetPlayers();
    sent = 0;

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (!isdefined(player))
            continue;

        music_send_existing_state(player, state_name);
        sent++;
    }

    return sent;
}

function music_stop_for_all()
{
    players = GetPlayers();
    stopped = 0;

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (!isdefined(player))
            continue;

        scripts\shared\util_shared::setClientSysState(
            "musicCmd",
            "none",
            player
        );

        player.pintemod_music_state = "none";
        stopped++;
    }

    return stopped;
}

function music_print_state(state_name)
{
    state = level.musicSystem.states[state_name];

    if (!isdefined(state.musArray) || state.musArray.size <= 0)
    {
        println("^3" + state_name + " -> structure alternative");
        return;
    }

    music_sets = "";

    for (i = 0; i < state.musArray.size; i++)
    {
        if (i > 0)
            music_sets = music_sets + ", ";

        music_sets = music_sets + state.musArray[i];
    }

    println("^7" + state_name + " -> " + music_sets);
}

function cmd_ezzmusicstatus(args)
{
    songs = music_get_special_songs();
    map_name = music_get_map_name();

    println("^5========== PINTEMOD MUSIC ==========");
    println("^7Map: " + music_get_map_display_name());
    println("^7Backend: existing musicCmd");
    println(
        "^7Registry: " +
        music_has_registry()
    );

    if (map_name == "zm_island")
    {
        println("^3Dead Flowers: native registry unavailable");
        println("^3Playback disabled for safety");
        println("^5====================================");
        return;
    }

    if (map_name == "zm_prototype")
    {
        println("^3No music configured");
        println("^5====================================");
        return;
    }

    if (songs.size <= 0)
    {
        println("^3No special music configured");
        println("^5====================================");
        return;
    }

    for (i = 0; i < songs.size; i++)
    {
        resolved = music_find_state_case_insensitive(
            songs[i].state
        );

        status = "^1ABSENT";

        if (isdefined(resolved))
            status = "^2OK";

        println(
            "^7" + (i + 1) + ". " +
            songs[i].label +
            " | " + songs[i].state +
            " | " + status
        );
    }

    println("^5====================================");
}

function cmd_ezzmusicstates(args)
{
    if (!music_has_registry())
    {
        println("^1[PinteMod] Native music registry unavailable");
        return;
    }

    keys = GetArrayKeys(level.musicSystem.states);

    println("^5========== REGISTERED MUSIC STATES ==========");
    println("^7Count: " + keys.size);

    for (i = 0; i < keys.size; i++)
        music_print_state(keys[i]);

    println("^5=============================================");
}

function cmd_ezzmusicplayall(args)
{
    map_name = music_get_map_name();

    if (map_name == "zm_island")
    {
        println(
            "^3[PinteMod]^7 Dead Flowers indisponible : " +
            "registre musical absent"
        );
        return;
    }

    if (!music_has_registry())
    {
        println("^1[PinteMod] Native music registry unavailable");
        return;
    }

    songs = music_get_special_songs();

    if (songs.size <= 0)
    {
        println(
            "^3[PinteMod]^7 No music configured pour " +
            music_get_map_display_name()
        );
        return;
    }

    song = songs[0];

    if (args.size >= 1)
    {
        song = music_get_song_by_argument(args[0]);

        if (!isdefined(song))
        {
            println("^1[PinteMod] Musique inconnue pour cette map");
            println("^3[PinteMod]^7 Use 1, 2, or the state name");
            return;
        }
    }

    state_name = music_find_state_case_insensitive(song.state);

    if (!isdefined(state_name))
    {
        println(
            "^1[PinteMod] Music state unavailable : " +
            song.state
        );
        return;
    }

    sent = music_send_state_to_all(state_name);

    say(
        "^6[PinteMod]^7 " +
        song.label +
        " started for everyone (" +
        sent + " joueur(s))"
    );
}

function cmd_ezzmusicstopall(args)
{
    if (!music_has_registry())
    {
        println("^1[PinteMod] Native music registry unavailable");
        return;
    }

    stopped = music_stop_for_all();

    say(
        "^3[PinteMod]^7 Music stopped for everyone (" +
        stopped + " joueur(s))"
    );
}
