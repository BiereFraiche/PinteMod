# Changelog — PinteMod v1.2 FINAL

## Community

- Added a public role-aware `.menu`.
- Added a large welcome HUD with `.menu` and `.spawn` instructions.
- Added safe late join through `.spawn` or Player Menu > Join Game.
- Added next-map, restart and protected vote-kick systems.
- Added `.yes`, `.no` and vote status shortcuts.
- Added solo support for next-map and restart votes.
- Added automatic scheduled map change after the current match.

## Administration and menu

- Changed the primary command prefix from `!` to `.` while retaining legacy compatibility.
- Reserved `.spawn` for late join and moved administrative respawn to `.respawn`.
- Translated menu navigation controls to English.
- Added menu action logging.
- Improved menu key polling and responsiveness.
- Added perk toggles from the menu.
- Fixed the ignore command so Zombie Blood no longer cancels the administrator state.

## Display and logging

- Removed `UnknownSoldier` from normal PinteMod notifications by using HUD messages.
- Added the optional PinteMod Live Console.
- Added connection, leave, chat, menu, community, vote and vote-kick logs.

## Stability

- Music and Events modules validated on the real server.
- Noclip remains intentionally disabled.
- Round-transition locking remains excluded; native BO3 transitions are used.
- Ranks and Records are excluded from this stable release.
