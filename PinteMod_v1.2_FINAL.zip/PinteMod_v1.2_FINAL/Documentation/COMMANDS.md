# Command overview — PinteMod v1.2 FINAL

The primary prefix is `.`. The legacy `!` prefix remains accepted.

## Public and community

- `.menu` — open the Player/Admin menu according to permissions
- `.spawn` — join an active match when eligible as a late joiner
- `.yes` / `.no` — answer the active vote
- `.votestatus` — show the current vote
- `.votemap <map>` — propose the next map
- `.voterestart` — propose restarting the current map
- `.votekick <player> [reason]` — start a protected vote kick (minimum three players)
- `.players` — show connected players
- `.map` — show current map information
- `.round` — show the current round

## Administration examples

- `.godmode [player]`
- `.ignore [player]`
- `.points <amount> [player]`
- `.ammo [player]`
- `.weapon <name> [player]`
- `.pap [player]`
- `.perk <name> [player]`
- `.perks [player]`
- `.respawn [player]`
- `.kill [player]`
- `.save [player]`
- `.load [player]`
- `.teleport <player>`
- `.round <number>`

The HUD menu is the recommended interface because it filters options according to role and current map.
