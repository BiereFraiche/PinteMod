# Installation — PinteMod v1.2 FINAL

1. Fully stop the BOIII dedicated server.
2. Back up the existing `boiii/custom_scripts/` folder.
3. Remove outdated PinteMod `.gsc` files to avoid duplicate versions.
4. Copy every `.gsc` file from the package root into `boiii/custom_scripts/`.
5. Open `ezz_admin_config.gsc` and configure Owner/Admin/Moderator/Helper names.
6. Fully restart the server.
7. Run `ezzchatstatus`, `ezzmenustatus` and `ezzcommunitystatus` in the server console.
8. Join and test `.menu`.

Optional Live Console:

- Copy the contents of `Tools/` inside the server directory.
- Run `Launch_PinteMod_LiveConsole.bat`.
- The tool automatically detects the server root and tails PinteMod logs in real time.
