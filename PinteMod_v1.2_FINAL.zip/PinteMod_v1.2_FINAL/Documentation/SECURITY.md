# Security notice

PinteMod v1.2 FINAL uses case-insensitive display-name matching for permissions.

This is suitable only for private servers where players are trusted and access is protected, for example with `g_password`.

It is not sufficient for an open public server. A player can impersonate a configured display name and receive that role.

Use XUID, SteamID or another reliable permanent identifier before public deployment.
