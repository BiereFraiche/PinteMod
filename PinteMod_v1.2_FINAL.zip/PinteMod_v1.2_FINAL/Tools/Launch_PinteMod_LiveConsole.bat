@echo off
title PinteMod Live Console
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0PinteMod_LiveConsole.ps1"
pause
