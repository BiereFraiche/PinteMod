﻿param(
    [string]$ServerRoot = "E:\Games\BO3\Server\UnrankedServer",
    [int]$InitialLines = 8
)

$ErrorActionPreference = "Stop"
$Host.UI.RawUI.WindowTitle = "PinteMod Live Console"

$LogRoot = Join-Path $ServerRoot "boiii\scriptdata\pintemod\logs"

$Sources = @(
    @{ Tag = "JOIN";      Path = Join-Path $LogRoot "connections.log";       Color = "Cyan" },
    @{ Tag = "CHAT";      Path = Join-Path $LogRoot "chat\session.log";       Color = "White" },
    @{ Tag = "COMMUNITY"; Path = Join-Path $LogRoot "community.log";          Color = "Green" },
    @{ Tag = "VOTE";      Path = Join-Path $LogRoot "vote_summary.log";       Color = "Yellow" },
    @{ Tag = "KICK";      Path = Join-Path $LogRoot "votekick_summary.log";   Color = "Magenta" }
)

function Ensure-LogFile {
    param([Parameter(Mandatory)][string]$Path)

    $directory = Split-Path -Parent $Path

    if (-not (Test-Path -LiteralPath $directory)) {
        New-Item -ItemType Directory -Path $directory -Force | Out-Null
    }

    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType File -Path $Path -Force | Out-Null
    }
}

function Write-TaggedLine {
    param(
        [Parameter(Mandatory)][string]$Tag,
        [AllowEmptyString()][string]$Text,
        [Parameter(Mandatory)][string]$Color
    )

    $timestamp = Get-Date -Format "HH:mm:ss"
    Write-Host "[$timestamp][$Tag] " -NoNewline -ForegroundColor $Color
    Write-Host $Text
}

Clear-Host
Write-Host "============================================================" -ForegroundColor DarkCyan
Write-Host " PinteMod Live Console — v1.2 FINAL" -ForegroundColor Cyan
Write-Host " Server: $ServerRoot" -ForegroundColor Gray
Write-Host " CTRL+C pour fermer." -ForegroundColor DarkGray
Write-Host "============================================================" -ForegroundColor DarkCyan
Write-Host ""

foreach ($source in $Sources) {
    Ensure-LogFile -Path $source.Path

    $existing = Get-Content -LiteralPath $source.Path -Tail $InitialLines -ErrorAction SilentlyContinue

    foreach ($line in $existing) {
        Write-TaggedLine -Tag $source.Tag -Text $line -Color $source.Color
    }
}

Write-Host ""
Write-Host "----- LIVE OUTPUT -----" -ForegroundColor DarkGray

$jobs = @()

try {
    foreach ($source in $Sources) {
        $job = Start-Job -ArgumentList $source.Tag, $source.Path, $source.Color -ScriptBlock {
            param($Tag, $Path, $Color)

            Get-Content -LiteralPath $Path -Wait -Tail 0 | ForEach-Object {
                [PSCustomObject]@{
                    Tag = $Tag
                    Text = $_
                    Color = $Color
                }
            }
        }

        $jobs += $job
    }

    while ($true) {
        foreach ($job in $jobs) {
            $items = Receive-Job -Job $job -ErrorAction SilentlyContinue

            foreach ($item in $items) {
                Write-TaggedLine -Tag $item.Tag -Text $item.Text -Color $item.Color
            }
        }

        Start-Sleep -Milliseconds 200
    }
}
finally {
    foreach ($job in $jobs) {
        Stop-Job -Job $job -ErrorAction SilentlyContinue
        Remove-Job -Job $job -Force -ErrorAction SilentlyContinue
    }
}
