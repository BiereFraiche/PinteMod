// ============================================================
// PinteMod — Community Features v1.2 FINAL
// Fichier : ezz_admin_community.gsc
// Créé par BiereFraiche et ChatGPT
//
// Accueil, menu public, late-join protégé, moteur de vote unique,
// rapports de votekick et journaux de connexion.
// Les fichiers sont écrits relativement à boiii/scriptdata/.
// ============================================================

#using scripts\zm\_zm;


// ------------------------------------------------------------
// Global PinteMod message without BO3's [All]UnknownSoldier prefix
// ------------------------------------------------------------

function community_broadcast(message)
{
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (isdefined(player))
            player iprintln(message);
    }
}

// Reliable server chat path. BOIII's console say/tell commands use the
// dedicated server sender and honour sv_sayname. This avoids the custom
// GSC tell() path which was not visible on the tested dedicated server.
function community_private_chat(player, message)
{
    if (!isdefined(player) || !isdefined(message) || message == "")
        return;

    client_number = player GetEntityNumber();
    ExecuteCommand("tell " + client_number + " " + message);
}

function community_broadcast_chat(message)
{
    if (!isdefined(message) || message == "")
        return;

    ExecuteCommand("say " + message);
}

autoexec function init()
{
    addcommand("ezzcommunitystatus", ::cmd_ezzcommunitystatus);
    addcommand("ezzjoin", ::cmd_ezzjoin);
    addcommand("ezzvotemap", ::cmd_ezzvotemap);
    addcommand("ezzvoterestart", ::cmd_ezzvoterestart);
    addcommand("ezzyes", ::cmd_ezzyes);
    addcommand("ezzno", ::cmd_ezzno);
    addcommand("ezzvotestatus", ::cmd_ezzvotestatus);
    addcommand("ezzvotekick", ::cmd_ezzvotekick);
    addcommand("ezzcancelvote", ::cmd_ezzcancelvote);
    addcommand("ezzclearnextmap", ::cmd_ezzclearnextmap);
    addcommand("ezzpublicinfo", ::cmd_ezzpublicinfo);
    addcommand("ezzpublicplayers", ::cmd_ezzpublicplayers);
    addcommand("ezzpublichelp", ::cmd_ezzpublichelp);

    // Name displayed for messages sent through the native server chat.
    SetDvar("sv_sayname", "PinteMod");

    level.pintemod_community_loaded = true;
    level.pintemod_vote_id = 0;
    level.pintemod_vote_cooldown_until = 0;
    level.pintemod_last_vote_summary = "No vote completed yet";
    level.pintemod_next_map_code = "";
    level.pintemod_next_map_display = "";
    level.pintemod_next_map_set_by = "";
    level.pintemod_next_map_loading = false;

    level.pintemod_vote = SpawnStruct();
    level.pintemod_vote.active = false;

    mkdir("pintemod");
    mkdir("pintemod/logs");
    mkdir("pintemod/logs/chat");
    mkdir("pintemod/logs/votekick");

    appendfile(
        "pintemod/logs/community.log",
        "=== PinteMod Community v1.2 FINAL loaded ===\n"
    );

    appendfile(
        "pintemod/logs/connections.log",
        "=== PinteMod connection session started ===\n"
    );

    level thread community_bootstrap();
    level thread community_next_map_game_ended_monitor();
    level thread community_next_map_end_game_monitor();

    println("^5[PinteMod]^7 Community v1.2 FINAL loaded");
}

// ------------------------------------------------------------
// Configuration fallbacks
// ------------------------------------------------------------

function community_apply_defaults()
{
    if (!isdefined(level.pintemod_welcome_enabled))
        level.pintemod_welcome_enabled = true;

    if (!isdefined(level.pintemod_welcome_delay))
        level.pintemod_welcome_delay = 6;

    if (!isdefined(level.pintemod_message_duration))
        level.pintemod_message_duration = 15;

    if (!isdefined(level.pintemod_welcome_message_duration))
        level.pintemod_welcome_message_duration = 25;

    if (!isdefined(level.pintemod_message_line_count))
        level.pintemod_message_line_count = 8;

    if (!isdefined(level.pintemod_public_menu_enabled))
        level.pintemod_public_menu_enabled = true;

    if (!isdefined(level.pintemod_late_join_enabled))
        level.pintemod_late_join_enabled = true;

    if (!isdefined(level.pintemod_map_vote_enabled))
        level.pintemod_map_vote_enabled = true;

    if (!isdefined(level.pintemod_next_map_vote_enabled))
        level.pintemod_next_map_vote_enabled = true;

    if (!isdefined(level.pintemod_restart_vote_enabled))
        level.pintemod_restart_vote_enabled = true;

    if (!isdefined(level.pintemod_votekick_enabled))
        level.pintemod_votekick_enabled = true;

    if (!isdefined(level.pintemod_vote_logs_enabled))
        level.pintemod_vote_logs_enabled = true;

    if (!isdefined(level.pintemod_vote_duration))
        level.pintemod_vote_duration = 45;

    if (!isdefined(level.pintemod_vote_cooldown))
        level.pintemod_vote_cooldown = 180;

    if (!isdefined(level.pintemod_map_vote_min_players))
        level.pintemod_map_vote_min_players = 1;

    if (!isdefined(level.pintemod_map_change_delay))
        level.pintemod_map_change_delay = 5;

    if (!isdefined(level.pintemod_votekick_min_players))
        level.pintemod_votekick_min_players = 3;

    if (!isdefined(level.pintemod_votekick_player_cooldown))
        level.pintemod_votekick_player_cooldown = 180;

    if (!isdefined(level.pintemod_votekick_target_cooldown))
        level.pintemod_votekick_target_cooldown = 300;

    if (!isdefined(level.pintemod_votekick_protect_moderators))
        level.pintemod_votekick_protect_moderators = false;

    if (!isdefined(level.pintemod_kick_delay))
        level.pintemod_kick_delay = 3;

    if (!isdefined(level.pintemod_map_command))
        level.pintemod_map_command = "map";

    if (!isdefined(level.pintemod_kick_command))
        level.pintemod_kick_command = "clientkick";
}

// ------------------------------------------------------------
// Shared player and role helpers
// ------------------------------------------------------------

function community_find_player(player_name)
{
    if (!isdefined(player_name) || player_name == "")
        return undefined;

    wanted_name = toLower(player_name);
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (!isdefined(player))
            continue;

        if (toLower(player.name) == wanted_name)
            return player;
    }

    return undefined;
}

function community_name_in_list(player_name, values)
{
    if (!isdefined(values))
        return false;

    wanted_name = toLower(player_name);

    for (i = 0; i < values.size; i++)
    {
        if (!isdefined(values[i]))
            continue;

        if (toLower(values[i]) == wanted_name)
            return true;
    }

    return false;
}

function community_get_role(player)
{
    if (!isdefined(player))
        return 0;

    if (isdefined(player.ezz_runtime_role))
        return player.ezz_runtime_role;

    if (community_name_in_list(player.name, level.ezz_owner_names))
        return 4;

    if (community_name_in_list(player.name, level.ezz_admin_names))
        return 3;

    if (community_name_in_list(player.name, level.ezz_moderator_names))
        return 2;

    if (community_name_in_list(player.name, level.ezz_helper_names))
        return 1;

    return 0;
}

function community_get_role_name(role)
{
    switch (role)
    {
        case 4:
            return "owner";

        case 3:
            return "admin";

        case 2:
            return "moderator";

        case 1:
            return "helper";
    }

    return "user";
}

function community_get_round()
{
    if (isdefined(level.round_number))
        return level.round_number;

    return 0;
}

function community_get_map_name()
{
    return toLower(GetDvarString("mapname"));
}

function community_get_map_display(map_name)
{
    switch (map_name)
    {
        case "zm_zod":
            return "Shadows of Evil";

        case "zm_factory":
            return "The Giant";

        case "zm_castle":
            return "Der Eisendrache";

        case "zm_island":
            return "Zetsubou No Shima";

        case "zm_stalingrad":
            return "Gorod Krovi";

        case "zm_genesis":
            return "Revelations";

        case "zm_prototype":
            return "Nacht der Untoten";

        case "zm_asylum":
            return "Verruckt";

        case "zm_sumpf":
            return "Shi No Numa";

        case "zm_theater":
            return "Kino der Toten";

        case "zm_cosmodrome":
            return "Ascension";

        case "zm_temple":
            return "Shangri-La";

        case "zm_moon":
            return "Moon";

        case "zm_tomb":
            return "Origins";
    }

    return map_name;
}

function community_resolve_map_alias(alias)
{
    alias = toLower(alias);

    switch (alias)
    {
        case "soe":
        case "shadows":
        case "zod":
        case "zm_zod":
            return "zm_zod";

        case "giant":
        case "factory":
        case "zm_factory":
            return "zm_factory";

        case "de":
        case "castle":
        case "dereisendrache":
        case "zm_castle":
            return "zm_castle";

        case "zns":
        case "zetsubou":
        case "island":
        case "zm_island":
            return "zm_island";

        case "gk":
        case "gorod":
        case "stalingrad":
        case "zm_stalingrad":
            return "zm_stalingrad";

        case "rev":
        case "revelations":
        case "genesis":
        case "zm_genesis":
            return "zm_genesis";

        case "nacht":
        case "prototype":
        case "zm_prototype":
            return "zm_prototype";

        case "verruckt":
        case "asylum":
        case "zm_asylum":
            return "zm_asylum";

        case "shino":
        case "shinonuma":
        case "sumpf":
        case "zm_sumpf":
            return "zm_sumpf";

        case "kino":
        case "theater":
        case "zm_theater":
            return "zm_theater";

        case "ascension":
        case "cosmodrome":
        case "zm_cosmodrome":
            return "zm_cosmodrome";

        case "shang":
        case "shangrila":
        case "temple":
        case "zm_temple":
            return "zm_temple";

        case "moon":
        case "zm_moon":
            return "zm_moon";

        case "origins":
        case "tomb":
        case "zm_tomb":
            return "zm_tomb";
    }

    return undefined;
}

// ------------------------------------------------------------
// Array and text helpers
// ------------------------------------------------------------

function community_array_contains(values, wanted_value)
{
    if (!isdefined(values) || !isdefined(wanted_value))
        return false;

    wanted_lower = toLower(wanted_value);

    for (i = 0; i < values.size; i++)
    {
        if (toLower(values[i]) == wanted_lower)
            return true;
    }

    return false;
}

function community_array_add_unique(values, value)
{
    if (!isdefined(values))
        values = [];

    if (!community_array_contains(values, value))
        values[values.size] = value;

    return values;
}

function community_array_remove(values, value)
{
    result = [];

    if (!isdefined(values))
        return result;

    wanted_lower = toLower(value);

    for (i = 0; i < values.size; i++)
    {
        if (toLower(values[i]) != wanted_lower)
            result[result.size] = values[i];
    }

    return result;
}

function community_copy_array(values)
{
    result = [];

    if (!isdefined(values))
        return result;

    for (i = 0; i < values.size; i++)
        result[result.size] = values[i];

    return result;
}

function community_join_args(args, start_index)
{
    result = "";

    for (i = start_index; i < args.size; i++)
    {
        if (result != "")
            result = result + " ";

        result = result + args[i];
    }

    return result;
}

function community_get_remaining_seconds(end_time)
{
    remaining = end_time - GetTime();

    if (remaining <= 0)
        return 0;

    return int((remaining + 999) / 1000);
}

function community_vote_add_event(text)
{
    if (!isdefined(level.pintemod_vote) ||
        !level.pintemod_vote.active)
    {
        return;
    }

    entry = "[" + GetTime() + " ms] " + text;
    level.pintemod_vote.events[
        level.pintemod_vote.events.size
    ] = entry;
}

// ------------------------------------------------------------
// Player connection, welcome and late-join state
// ------------------------------------------------------------

function community_bootstrap()
{
    wait 1;
    community_apply_defaults();

    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (isdefined(player))
            community_attach_player(player, true);
    }

    for (;;)
    {
        level waittill("connected", player);

        if (isdefined(player))
            community_attach_player(player, false);
    }
}

function community_attach_player(player, initial_player)
{
    if (!isdefined(player))
        return;

    if (isdefined(player.pintemod_community_monitor_started) &&
        player.pintemod_community_monitor_started)
    {
        return;
    }

    player.pintemod_community_monitor_started = true;
    player.pintemod_late_join_eligible = false;
    player.pintemod_late_join_consumed = false;
    player.pintemod_late_join_normal_death = false;
    player.pintemod_late_join_spawned = false;
    player.pintemod_join_in_progress = false;
    player.pintemod_spectator_wait_logged = false;
    player.pintemod_connection_name = player.name;
    player.pintemod_connection_client_number =
        player GetEntityNumber();

    player.pintemod_connected_during_active_game =
        !initial_player &&
        community_get_round() >= 1 &&
        community_count_active_players(player) > 0;

    community_apply_message_settings(player);

    if (initial_player)
        community_log_player_event(player, "ACTIVE", false);
    else
        community_log_player_event(player, "JOIN", false);

    player thread community_disconnect_monitor();
    player thread community_welcome_monitor(initial_player);
    player thread community_late_join_state_monitor();

    if (!initial_player &&
        isdefined(level.pintemod_vote) &&
        level.pintemod_vote.active)
    {
        community_vote_add_event(
            player.name + " joined after vote start; not eligible"
        );
    }
}

function community_apply_message_settings(player)
{
    if (!isdefined(player))
        return;

    community_apply_defaults();

    // BOIII method form accepts one complete "dvar value" string.
    // iPrintLn uses game message window 0 at the bottom-left.
    player SetClientDvar(
        "con_gameMsgWindow0MsgTime " +
        level.pintemod_message_duration
    );
    player SetClientDvar(
        "con_gameMsgWindow0LineCount " +
        level.pintemod_message_line_count
    );
    player SetClientDvar("con_gameMsgWindow0FadeInTime 0.15");
    player SetClientDvar("con_gameMsgWindow0FadeOutTime 1.0");
    player SetClientDvar("con_gameMsgWindow0ScrollTime 0.15");
}

function community_restore_message_duration_after_welcome()
{
    self endon("disconnect");

    wait level.pintemod_welcome_message_duration;

    self SetClientDvar(
        "con_gameMsgWindow0MsgTime " +
        level.pintemod_message_duration
    );
}

function community_clear_welcome_hud()
{
    if (isdefined(self.pintemod_welcome_hud_title))
    {
        self.pintemod_welcome_hud_title destroy();
        self.pintemod_welcome_hud_title = undefined;
    }

    if (isdefined(self.pintemod_welcome_hud_menu))
    {
        self.pintemod_welcome_hud_menu destroy();
        self.pintemod_welcome_hud_menu = undefined;
    }

    if (isdefined(self.pintemod_welcome_hud_spawn))
    {
        self.pintemod_welcome_hud_spawn destroy();
        self.pintemod_welcome_hud_spawn = undefined;
    }
}

function community_welcome_hud_timeout()
{
    self notify("pintemod_welcome_hud_refresh");
    self endon("pintemod_welcome_hud_refresh");
    self endon("disconnect");

    wait level.pintemod_welcome_message_duration;

    if (isdefined(self.pintemod_welcome_hud_title))
    {
        self.pintemod_welcome_hud_title fadeovertime(1);
        self.pintemod_welcome_hud_title.alpha = 0;
    }

    if (isdefined(self.pintemod_welcome_hud_menu))
    {
        self.pintemod_welcome_hud_menu fadeovertime(1);
        self.pintemod_welcome_hud_menu.alpha = 0;
    }

    if (isdefined(self.pintemod_welcome_hud_spawn))
    {
        self.pintemod_welcome_hud_spawn fadeovertime(1);
        self.pintemod_welcome_hud_spawn.alpha = 0;
    }

    wait 1;
    self community_clear_welcome_hud();
}

function community_show_welcome_hud()
{
    if (!isdefined(self))
        return;

    self community_clear_welcome_hud();

    // Dedicated bottom-left HUD: independent from iPrintLn window timing.
    self.pintemod_welcome_hud_title = newclienthudelem(self);
    self.pintemod_welcome_hud_title.horzalign = "left";
    self.pintemod_welcome_hud_title.vertalign = "bottom";
    self.pintemod_welcome_hud_title.alignx = "left";
    self.pintemod_welcome_hud_title.aligny = "bottom";
    self.pintemod_welcome_hud_title.x = 20;
    self.pintemod_welcome_hud_title.y = -205;
    self.pintemod_welcome_hud_title.fontscale = 1.35;
    self.pintemod_welcome_hud_title.alpha = 1;
    self.pintemod_welcome_hud_title.sort = 1000;
    self.pintemod_welcome_hud_title setText(
        "^5[PinteMod]^7 Welcome to the server!"
    );

    self.pintemod_welcome_hud_menu = newclienthudelem(self);
    self.pintemod_welcome_hud_menu.horzalign = "left";
    self.pintemod_welcome_hud_menu.vertalign = "bottom";
    self.pintemod_welcome_hud_menu.alignx = "left";
    self.pintemod_welcome_hud_menu.aligny = "bottom";
    self.pintemod_welcome_hud_menu.x = 20;
    self.pintemod_welcome_hud_menu.y = -180;
    self.pintemod_welcome_hud_menu.fontscale = 1.15;
    self.pintemod_welcome_hud_menu.alpha = 1;
    self.pintemod_welcome_hud_menu.sort = 1000;
    self.pintemod_welcome_hud_menu setText(
        "^7Open the Player Menu with ^2.menu^7."
    );

    self.pintemod_welcome_hud_spawn = newclienthudelem(self);
    self.pintemod_welcome_hud_spawn.horzalign = "left";
    self.pintemod_welcome_hud_spawn.vertalign = "bottom";
    self.pintemod_welcome_hud_spawn.alignx = "left";
    self.pintemod_welcome_hud_spawn.aligny = "bottom";
    self.pintemod_welcome_hud_spawn.x = 20;
    self.pintemod_welcome_hud_spawn.y = -155;
    self.pintemod_welcome_hud_spawn.fontscale = 1.15;
    self.pintemod_welcome_hud_spawn.alpha = 1;
    self.pintemod_welcome_hud_spawn.sort = 1000;

    if (level.pintemod_late_join_enabled)
    {
        self.pintemod_welcome_hud_spawn setText(
            "^7Late join: use ^2.spawn ^7or Player Menu > Join Game."
        );
    }
    else
    {
        self.pintemod_welcome_hud_spawn setText(
            "^7Community commands are available in ^2.menu^7."
        );
    }

    self thread community_welcome_hud_timeout();
}

function community_disconnect_monitor()
{
    player_name = "Unknown";
    client_number = -1;

    if (isdefined(self.pintemod_connection_name))
        player_name = self.pintemod_connection_name;
    else if (isdefined(self.name))
        player_name = self.name;

    if (isdefined(self.pintemod_connection_client_number))
        client_number = self.pintemod_connection_client_number;
    else
        client_number = self GetEntityNumber();

    self waittill("disconnect");
    community_handle_disconnect_snapshot(player_name, client_number);
}

function community_welcome_monitor(initial_player)
{
    self endon("disconnect");

    community_apply_defaults();
    wait level.pintemod_welcome_delay;

    // The connected event can fire while the client is still loading.
    // Wait for a usable player state, then send the welcome several times.
    for (ready_check = 0; ready_check < 60; ready_check++)
    {
        if (isdefined(self.name) && self.name != "" &&
            isdefined(self.sessionstate))
        {
            break;
        }

        wait 0.25;
    }

    if (level.pintemod_welcome_enabled)
    {
        // Keep the normal bottom-left window configured for other messages.
        community_apply_message_settings(self);
        wait 0.5;

        // Main delivery: dedicated HUD for 25 seconds with native iPrintLn fallback.
        self community_show_welcome_hud();
        self iprintln(
            "^5[PinteMod]^7 Welcome! ^2.menu ^7| Late join: ^2.spawn"
        );
        appendfile(
            "pintemod/logs/community.log",
            "[" + GetTime() + "] WELCOME_SENT_HUD | " +
            self.name + " | hud=custom+iprintln | chat=disabled\n"
        );

        println(
            "^5[PinteMod][COMMUNITY]^7 Welcome HUD sent to " +
            self.name
        );
    }

    if (initial_player || !level.pintemod_late_join_enabled)
        return;

    if (!self.pintemod_connected_during_active_game)
        return;

    for (check = 0; check < 40; check++)
    {
        if (isdefined(self.sessionstate) &&
            self.sessionstate == "spectator" &&
            community_get_round() >= 1 &&
            community_count_active_players(self) > 0)
        {
            community_mark_late_join_eligible(self, "welcome");
            self iprintln("^3[PinteMod]^7 You joined an active game.");

            if (level.pintemod_public_menu_enabled)
                self iprintln("^7Use ^2.spawn ^7or Player Menu > Join Game.");
            else
                self iprintln("^7Use ^2.spawn ^7to enter the active game.");

            community_private_chat(
                self,
                "^3[PinteMod]^7 Active game detected: use ^2.spawn ^7or ^2.menu^7."
            );

            return;
        }

        if (isdefined(self.sessionstate) &&
            self.sessionstate != "spectator")
        {
            return;
        }

        wait 0.5;
    }
}

function community_late_join_state_monitor()
{
    self endon("disconnect");

    was_active_after_join = false;

    for (;;)
    {
        is_active = false;

        if (isdefined(self.sessionstate) &&
            self.sessionstate != "spectator")
        {
            is_active = true;
        }

        if (self.pintemod_connected_during_active_game &&
            !self.pintemod_late_join_consumed &&
            !self.pintemod_late_join_normal_death &&
            !is_active &&
            community_get_round() >= 1 &&
            community_count_active_players(self) > 0)
        {
            community_mark_late_join_eligible(self, "state-monitor");
        }

        if (is_active && self.pintemod_late_join_spawned)
            was_active_after_join = true;

        if (was_active_after_join && !is_active &&
            !self.pintemod_join_in_progress)
        {
            self.pintemod_late_join_normal_death = true;
            self.pintemod_late_join_spawned = false;
            was_active_after_join = false;

            appendfile(
                "pintemod/logs/community.log",
                "[" + GetTime() + "] NORMAL_DEATH_AFTER_LATE_JOIN | " +
                self.name + "\n"
            );
        }

        wait 0.25;
    }
}

function community_log_action(event_name, player_name, details)
{
    line = event_name + " | " + player_name;

    if (isdefined(details) && details != "")
        line = line + " | " + details;

    appendfile(
        "pintemod/logs/community.log",
        "[" + GetTime() + "] " + line + "\n"
    );

    println("^5[PinteMod][COMMUNITY]^7 " + line);
}

function community_mark_late_join_eligible(player, source)
{
    if (!isdefined(player))
        return;

    player.pintemod_late_join_eligible = true;

    if (isdefined(player.pintemod_spectator_wait_logged) &&
        player.pintemod_spectator_wait_logged)
    {
        return;
    }

    player.pintemod_spectator_wait_logged = true;

    community_log_action(
        "SPECTATOR_WAITING",
        player.name,
        "round=" + community_get_round() +
        " | join=available | source=" + source
    );
}

function community_count_connected_players_excluding_identity(
    excluded_name,
    excluded_client_number
)
{
    count = 0;
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        connected_player = players[i];

        if (!isdefined(connected_player))
            continue;

        connected_name = "";
        connected_client = -1;

        if (isdefined(connected_player.name))
            connected_name = connected_player.name;

        connected_client = connected_player GetEntityNumber();

        if (toLower(connected_name) == toLower(excluded_name) &&
            connected_client == excluded_client_number)
        {
            continue;
        }

        count++;
    }

    return count;
}

function community_count_connected_players(excluded_player)
{
    count = 0;
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        connected_player = players[i];

        if (!isdefined(connected_player))
            continue;

        if (isdefined(excluded_player) &&
            connected_player == excluded_player)
        {
            continue;
        }

        count++;
    }

    return count;
}

function community_count_active_players(excluded_player)
{
    count = 0;
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (!isdefined(player) || player == excluded_player)
            continue;

        if (isdefined(player.sessionstate) &&
            player.sessionstate != "spectator")
        {
            count++;
        }
    }

    return count;
}

function community_log_player_event_values(
    player_name,
    client_number,
    event_name,
    player_count
)
{
    round_number = community_get_round();
    time_ms = GetTime();

    plain_line =
        "[" + time_ms + " ms]" +
        "[round " + round_number + "]" +
        "[" + event_name + "] " +
        player_name +
        " | client=" + client_number +
        " | players=" + player_count;

    appendfile(
        "pintemod/logs/connections.log",
        plain_line + "\n"
    );

    if (isdefined(level.pintemod_vote) &&
        level.pintemod_vote.active)
    {
        community_vote_add_event(
            event_name + " | " + player_name +
            " | client=" + client_number +
            " | players=" + player_count
        );
    }

    if (event_name == "JOIN")
    {
        println(
            "^2[PinteMod][JOIN]^7 " + player_name +
            " ^7| client=" + client_number +
            " | players=" + player_count
        );
        return;
    }

    if (event_name == "LEAVE")
    {
        println(
            "^1[PinteMod][LEAVE]^7 " + player_name +
            " ^7| client=" + client_number +
            " | players=" + player_count
        );
        return;
    }

    println(
        "^5[PinteMod][ACTIVE]^7 " + player_name +
        " ^7| client=" + client_number +
        " | players=" + player_count
    );
}

function community_log_player_event(
    player,
    event_name,
    exclude_player_from_count
)
{
    if (!isdefined(player))
        return;

    player_name = "Unknown";
    client_number = -1;

    if (isdefined(player.pintemod_connection_name))
        player_name = player.pintemod_connection_name;
    else if (isdefined(player.name))
        player_name = player.name;

    if (isdefined(player.pintemod_connection_client_number))
        client_number = player.pintemod_connection_client_number;
    else
        client_number = player GetEntityNumber();

    excluded_player = undefined;

    if (exclude_player_from_count)
        excluded_player = player;

    player_count = community_count_connected_players(excluded_player);

    community_log_player_event_values(
        player_name,
        client_number,
        event_name,
        player_count
    );
}

function community_handle_disconnect_snapshot(player_name, client_number)
{
    player_count = community_count_connected_players_excluding_identity(
        player_name,
        client_number
    );

    community_log_player_event_values(
        player_name,
        client_number,
        "LEAVE",
        player_count
    );

    if (!isdefined(level.pintemod_vote) ||
        !level.pintemod_vote.active)
    {
        return;
    }

    if (toLower(level.pintemod_vote.initiator_name) ==
        toLower(player_name))
    {
        community_finish_vote(false, "Initiator disconnected");
        return;
    }

    if (level.pintemod_vote.type == "kick" &&
        toLower(level.pintemod_vote.target_name) ==
        toLower(player_name))
    {
        community_finish_vote(
            false,
            "Target disconnected before the result"
        );
        return;
    }

    if (community_array_contains(
        level.pintemod_vote.required_players,
        player_name
    ))
    {
        level.pintemod_vote.required_players =
            community_array_remove(
                level.pintemod_vote.required_players,
                player_name
            );

        level.pintemod_vote.yes_players = community_array_remove(
            level.pintemod_vote.yes_players,
            player_name
        );

        level.pintemod_vote.no_players = community_array_remove(
            level.pintemod_vote.no_players,
            player_name
        );

        community_broadcast(
            "^5[PinteMod]^7 Required voter left. Vote: ^2" +
            level.pintemod_vote.yes_players.size + "/" +
            level.pintemod_vote.required_players.size
        );

        community_check_unanimity();
    }
}

// ------------------------------------------------------------
// Late-join spawn
// ------------------------------------------------------------

function cmd_ezzjoin(args)
{
    community_apply_defaults();

    if (!level.pintemod_late_join_enabled)
    {
        println("^3[PinteMod]^7 Late-join spawn is disabled");
        return;
    }

    if (args.size < 1)
    {
        println("^5[PinteMod]^7 Usage: ezzjoin <PlayerName>");
        return;
    }

    player = community_find_player(args[0]);

    if (!isdefined(player))
    {
        println("^1[PinteMod] Player not found: " + args[0]);
        return;
    }

    community_log_action(
        "LATE_JOIN_ATTEMPT",
        player.name,
        "round=" + community_get_round()
    );

    if (player.pintemod_late_join_normal_death)
    {
        player iprintln(
            "^1[PinteMod]^7 Late-join state rejected: " +
            "normal death detected."
        );
        community_log_action(
            "LATE_JOIN_REJECTED",
            player.name,
            "reason=normal-death"
        );
        return;
    }

    if (!player.pintemod_late_join_eligible ||
        player.pintemod_late_join_consumed)
    {
        player iprintln(
            "^3[PinteMod]^7 Join Game is available only after " +
            "joining an active match as a spectator."
        );
        community_log_action(
            "LATE_JOIN_REJECTED",
            player.name,
            "reason=not-eligible"
        );
        return;
    }

    if (!isdefined(player.sessionstate) ||
        player.sessionstate != "spectator")
    {
        player.pintemod_late_join_eligible = false;
        player.pintemod_late_join_consumed = true;
        player iprintln("^3[PinteMod]^7 You are already active.");
        community_log_action(
            "LATE_JOIN_REJECTED",
            player.name,
            "reason=already-active"
        );
        return;
    }

    if (!isdefined(player.spectator_respawn))
    {
        player iprintln("^1[PinteMod]^7 Respawn is not ready yet.");
        community_log_action(
            "LATE_JOIN_REJECTED",
            player.name,
            "reason=respawn-not-ready"
        );
        return;
    }

    player.pintemod_join_in_progress = true;
    player zm::spectator_respawn_player();

    wait 0.25;

    if (isdefined(player.sessionstate) &&
        player.sessionstate != "spectator")
    {
        player.pintemod_late_join_eligible = false;
        player.pintemod_late_join_consumed = true;
        player.pintemod_late_join_spawned = true;
        player.pintemod_join_in_progress = false;

        player iprintln("^2[PinteMod]^7 You joined the active game.");
        community_broadcast("^2[PinteMod]^7 " + player.name + " joined the game.");

        community_log_action(
            "LATE_JOIN_SUCCESS",
            player.name,
            "map=" + community_get_map_name() +
            " | round=" + community_get_round()
        );
    }
    else
    {
        player.pintemod_join_in_progress = false;
        player iprintln(
            "^1[PinteMod]^7 Respawn failed. Try again while a " +
            "survivor is active."
        );

        community_log_action(
            "LATE_JOIN_FAILED",
            player.name,
            "reason=respawn-verification"
        );
    }
}

// ------------------------------------------------------------
// Vote lifecycle
// ------------------------------------------------------------

function community_vote_is_available(requester)
{
    community_apply_defaults();

    if (isdefined(level.pintemod_vote) &&
        level.pintemod_vote.active)
    {
        requester iprintln("^3[PinteMod]^7 A vote is already active.");
        return false;
    }

    if (GetTime() < level.pintemod_vote_cooldown_until)
    {
        remaining = community_get_remaining_seconds(
            level.pintemod_vote_cooldown_until
        );

        requester iprintln(
            "^3[PinteMod]^7 Vote cooldown: " + remaining + "s"
        );
        return false;
    }

    return true;
}

function community_create_vote(vote_type, initiator)
{
    level.pintemod_vote_id++;

    vote = SpawnStruct();
    vote.active = true;
    vote.id = level.pintemod_vote_id;
    vote.type = vote_type;
    vote.initiator_name = initiator.name;
    vote.initiator_role = community_get_role_name(
        community_get_role(initiator)
    );
    vote.target_name = "";
    vote.target_role = "unavailable";
    vote.reason = "Not provided";
    vote.map_code = "";
    vote.map_display = "";
    vote.required_players = [];
    vote.yes_players = [];
    vote.no_players = [];
    vote.events = [];
    vote.start_time = GetTime();
    vote.end_time = GetTime() +
        (level.pintemod_vote_duration * 1000);
    vote.last_notice = -1;
    vote.initiator_chat_start = community_capture_chat(initiator);
    vote.target_chat_start = [];

    level.pintemod_vote = vote;

    community_vote_add_event(
        vote_type + " vote started by " + initiator.name
    );
}

function community_capture_chat(player)
{
    if (!isdefined(player) ||
        !isdefined(player.pintemod_chat_history))
    {
        empty_history = [];
        return empty_history;
    }

    return community_copy_array(player.pintemod_chat_history);
}

function community_add_all_players_to_required(excluded_player)
{
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (!isdefined(player) || player == excluded_player)
            continue;

        level.pintemod_vote.required_players =
            community_array_add_unique(
                level.pintemod_vote.required_players,
                player.name
            );
    }
}

function community_start_vote_timer()
{
    vote_id = level.pintemod_vote.id;
    level thread community_vote_timer(vote_id);
}

function community_vote_timer(vote_id)
{
    for (;;)
    {
        wait 1;

        if (!isdefined(level.pintemod_vote) ||
            !level.pintemod_vote.active ||
            level.pintemod_vote.id != vote_id)
        {
            return;
        }

        remaining = community_get_remaining_seconds(
            level.pintemod_vote.end_time
        );

        if (remaining <= 0)
        {
            community_finish_vote(false, "Vote timed out");
            return;
        }

        if ((remaining == 15 || remaining == 5) &&
            level.pintemod_vote.last_notice != remaining)
        {
            level.pintemod_vote.last_notice = remaining;

            community_broadcast(
                "^5[PinteMod]^7 Vote: ^2" +
                level.pintemod_vote.yes_players.size + "/" +
                level.pintemod_vote.required_players.size +
                " YES ^7| " + remaining + "s remaining"
            );

            if (remaining == 15 &&
                (level.pintemod_vote.type == "nextmap" ||
                 level.pintemod_vote.type == "restart"))
            {
                community_broadcast_chat(
                    "Vote still open: use .yes or .no, or open .menu."
                );
            }
        }
    }
}

function community_check_unanimity()
{
    if (!isdefined(level.pintemod_vote) ||
        !level.pintemod_vote.active)
    {
        return;
    }

    required = level.pintemod_vote.required_players.size;
    yes_count = level.pintemod_vote.yes_players.size;

    if (required > 0 && yes_count >= required)
        community_finish_vote(true, "Unanimous approval");
}

function community_cast_vote(player, vote_yes)
{
    if (!isdefined(level.pintemod_vote) ||
        !level.pintemod_vote.active)
    {
        player iprintln("^3[PinteMod]^7 No vote is active.");
        return;
    }

    if (!community_array_contains(
        level.pintemod_vote.required_players,
        player.name
    ))
    {
        player iprintln(
            "^3[PinteMod]^7 You are not an eligible voter for " +
            "this vote."
        );
        return;
    }

    if (community_array_contains(
        level.pintemod_vote.yes_players,
        player.name
    ) || community_array_contains(
        level.pintemod_vote.no_players,
        player.name
    ))
    {
        player iprintln("^3[PinteMod]^7 You already voted.");
        return;
    }

    if (!vote_yes)
    {
        level.pintemod_vote.no_players =
            community_array_add_unique(
                level.pintemod_vote.no_players,
                player.name
            );

        community_vote_add_event(player.name + " voted NO");

        community_broadcast(
            "^1[PinteMod]^7 " + player.name +
            " voted NO. Unanimity was not reached."
        );

        community_finish_vote(false, player.name + " voted NO");
        return;
    }

    level.pintemod_vote.yes_players = community_array_add_unique(
        level.pintemod_vote.yes_players,
        player.name
    );

    community_vote_add_event(player.name + " voted YES");

    community_broadcast(
        "^2[PinteMod]^7 " + player.name + " voted YES. ^2" +
        level.pintemod_vote.yes_players.size + "/" +
        level.pintemod_vote.required_players.size
    );

    community_check_unanimity();
}

function community_get_pending_vote_count(vote)
{
    pending = vote.required_players.size -
        vote.yes_players.size - vote.no_players.size;

    if (pending < 0)
        pending = 0;

    return pending;
}

function community_build_vote_chat_summary(vote, passed)
{
    if (passed)
    {
        return "^2[PinteMod]^7 Vote passed: ^2" +
            vote.yes_players.size + "/" +
            vote.required_players.size + " YES";
    }

    summary = "^1[PinteMod]^7 Vote failed: ^2" +
        vote.yes_players.size + " YES^7, ^1" +
        vote.no_players.size + " NO";

    pending = community_get_pending_vote_count(vote);

    if (pending > 0)
        summary = summary + "^7, ^3" + pending + " missing";

    return summary;
}

function community_finish_vote(passed, result_reason)
{
    if (!isdefined(level.pintemod_vote) ||
        !level.pintemod_vote.active)
    {
        return;
    }

    community_vote_add_event(
        "Result: " + result_reason +
        " | passed=" + passed
    );

    vote = level.pintemod_vote;
    vote.active = false;

    level.pintemod_vote_cooldown_until = GetTime() +
        (level.pintemod_vote_cooldown * 1000);

    result_text = "FAILED";

    if (passed)
        result_text = "PASSED";

    summary = result_text + " | type=" + vote.type +
        " | initiator=" + vote.initiator_name +
        " | yes=" + vote.yes_players.size + "/" +
        vote.required_players.size +
        " | reason=" + result_reason;

    level.pintemod_last_vote_summary = summary;

    if (level.pintemod_vote_logs_enabled)
    {
        appendfile(
            "pintemod/logs/vote_summary.log",
            "[" + GetTime() + "] " + summary + "\n"
        );
    }

    report_path = "";

    if (vote.type == "kick" && level.pintemod_vote_logs_enabled)
    {
        report_path = community_write_kick_report(
            vote,
            passed,
            result_reason
        );
    }

    community_broadcast(community_build_vote_chat_summary(vote, passed));

    if (!passed)
        community_broadcast("^7Reason: " + result_reason);

    map_code = vote.map_code;
    map_display = vote.map_display;
    target_name = vote.target_name;
    initiator_name = vote.initiator_name;

    level.pintemod_vote = SpawnStruct();
    level.pintemod_vote.active = false;

    if (passed && vote.type == "nextmap")
    {
        community_schedule_next_map(
            map_code,
            map_display,
            initiator_name
        );
    }

    if (passed && vote.type == "restart")
        level thread community_apply_map(map_code, map_display);

    if (passed && vote.type == "kick")
        level thread community_apply_kick(target_name, report_path);
}

function community_schedule_next_map(
    map_code,
    map_display,
    initiator_name
)
{
    level.pintemod_next_map_code = map_code;
    level.pintemod_next_map_display = map_display;
    level.pintemod_next_map_set_by = initiator_name;

    community_broadcast(
        "^2[PinteMod]^7 Next map scheduled: ^2" +
        map_display + "^7. Current game continues."
    );
    community_broadcast("^7It will load automatically when the game ends.");

    appendfile(
        "pintemod/logs/community.log",
        "[" + GetTime() + "] NEXT_MAP_SCHEDULED | " +
        map_code + " | by=" + initiator_name + "\n"
    );
}

function community_clear_scheduled_next_map(cleared_by)
{
    if (!isdefined(level.pintemod_next_map_code) ||
        level.pintemod_next_map_code == "")
    {
        return false;
    }

    old_code = level.pintemod_next_map_code;
    old_display = level.pintemod_next_map_display;

    level.pintemod_next_map_code = "";
    level.pintemod_next_map_display = "";
    level.pintemod_next_map_set_by = "";

    appendfile(
        "pintemod/logs/community.log",
        "[" + GetTime() + "] NEXT_MAP_CLEARED | " +
        old_code + " | by=" + cleared_by + "\n"
    );

    community_broadcast(
        "^3[PinteMod]^7 Scheduled next map cleared: " +
        old_display
    );

    return true;
}

function community_next_map_game_ended_monitor()
{
    level waittill("game_ended");
    community_apply_scheduled_next_map("game_ended");
}

function community_next_map_end_game_monitor()
{
    level waittill("end_game");
    community_apply_scheduled_next_map("end_game");
}

function community_apply_scheduled_next_map(trigger_name)
{
    if (!isdefined(level.pintemod_next_map_code) ||
        level.pintemod_next_map_code == "" ||
        level.pintemod_next_map_loading)
    {
        return;
    }

    level.pintemod_next_map_loading = true;

    map_code = level.pintemod_next_map_code;
    map_display = level.pintemod_next_map_display;

    appendfile(
        "pintemod/logs/community.log",
        "[" + GetTime() + "] NEXT_MAP_TRIGGER | " +
        trigger_name + " | map=" + map_code + "\n"
    );

    level.pintemod_next_map_code = "";
    level.pintemod_next_map_display = "";
    level.pintemod_next_map_set_by = "";

    level thread community_apply_map(map_code, map_display);
}

function community_apply_map(map_code, map_display)
{
    delay = level.pintemod_map_change_delay;
    previous_map = community_get_map_name();

    community_broadcast(
        "^5[PinteMod]^7 Loading ^2" + map_display +
        " ^7in " + delay + " seconds..."
    );

    wait delay;

    command_line = level.pintemod_map_command + " " + map_code;

    appendfile(
        "pintemod/logs/community.log",
        "[" + GetTime() + "] MAP_COMMAND | " +
        command_line + "\n"
    );

    println("^5[PinteMod]^7 Executing: " + command_line);
    executecommand(command_line);

    // A valid map command unloads this script. Reaching this check
    // with the old map still active means the command was rejected.
    wait 3;

    if (community_get_map_name() == previous_map)
    {
        println("^1[PinteMod] Vote passed but map command failed");
        community_broadcast("^1[PinteMod]^7 Vote passed but map command failed.");
        appendfile(
            "pintemod/logs/community.log",
            "[" + GetTime() + "] MAP_COMMAND_FAILED | " +
            command_line + "\n"
        );
    }
}


function community_append_kick_summary(text)
{
    if (!level.pintemod_vote_logs_enabled)
        return;

    appendfile(
        "pintemod/logs/votekick_summary.log",
        text + "\n"
    );
}

function community_apply_kick(target_name, report_path)
{
    community_broadcast(
        "^5[PinteMod]^7 Kick approved. Verification in " +
        level.pintemod_kick_delay + " seconds."
    );

    wait level.pintemod_kick_delay;

    target = community_find_player(target_name);

    if (!isdefined(target))
    {
        if (report_path != "")
        {
            appendfile(
                report_path,
                "\nKick action: target already disconnected.\n"
            );
        }

        community_append_kick_summary(
            "[" + GetTime() + "] ACTION_SKIPPED | " +
            target_name + " already disconnected"
        );
        return;
    }

    // Current BOIII compatibility strategy: BOIII clientkick is called with
    // the player's exact pseudonym. This will be replaced by a stable
    // SteamID/XUID-based identity layer in a later public-server release.
    command_line = level.pintemod_kick_command +
        " \"" + target.name + "\"";

    if (report_path != "")
    {
        appendfile(
            report_path,
            "\nKick command issued: " + command_line + "\n"
        );
    }

    appendfile(
        "pintemod/logs/community.log",
        "[" + GetTime() + "] KICK_COMMAND | target=" +
        target_name + " | " + command_line + "\n"
    );

    println("^5[PinteMod]^7 Executing: " + command_line);
    executecommand(command_line);

    wait 1.5;

    target_after = community_find_player(target_name);

    if (isdefined(target_after))
    {
        println(
            "^1[PinteMod] Kick vote passed but target could not " +
            "be removed"
        );
        community_broadcast(
            "^1[PinteMod]^7 Kick vote passed but target could " +
            "not be removed."
        );

        if (report_path != "")
        {
            appendfile(
                report_path,
                "Kick verification: target is still connected. " +
                "The configured command may be unsupported.\n"
            );
        }

        community_append_kick_summary(
            "[" + GetTime() + "] ACTION_FAILED | " +
            target_name + " still connected"
        );
        return;
    }

    community_broadcast("^2[PinteMod]^7 " + target_name + " was removed.");

    if (report_path != "")
    {
        appendfile(
            report_path,
            "Kick verification: target disconnected.\n"
        );
    }

    community_append_kick_summary(
        "[" + GetTime() + "] ACTION_SUCCESS | " +
        target_name + " disconnected"
    );
}

// ------------------------------------------------------------
// Vote reports
// ------------------------------------------------------------

function community_get_vote_state_for_player(vote, player_name)
{
    if (community_array_contains(vote.yes_players, player_name))
        return "YES";

    if (community_array_contains(vote.no_players, player_name))
        return "NO";

    return "PENDING";
}

function community_append_history(report, title, history)
{
    report = report +
        "\n------------------------------------------------------------\n";
    report = report + title + "\n";
    report = report +
        "------------------------------------------------------------\n";

    if (!isdefined(history) || history.size <= 0)
    {
        report = report + "No captured chat messages.\n";
        return report;
    }

    for (i = 0; i < history.size; i++)
        report = report + history[i] + "\n";

    return report;
}

function community_write_kick_report(vote, passed, result_reason)
{
    map_name = community_get_map_name();
    round_number = community_get_round();

    report_path = "pintemod/logs/votekick/votekick_" +
        map_name + "_r" + round_number + "_" +
        vote.start_time + "_" + vote.id + ".txt";

    initiator = community_find_player(vote.initiator_name);
    target = community_find_player(vote.target_name);

    initiator_history = vote.initiator_chat_start;
    target_history = vote.target_chat_start;

    if (isdefined(initiator))
        initiator_history = community_capture_chat(initiator);

    if (isdefined(target))
        target_history = community_capture_chat(target);

    result_text = "FAILED";

    if (passed)
        result_text = "PASSED";

    report = "============================================================\n";
    report = report + "PinteMod Vote Kick Report — v1.2 FINAL\n";
    report = report + "============================================================\n\n";
    report = report + "Server: " + GetDvarString("sv_hostname") + "\n";
    report = report + "Date/time: use the Windows file timestamp\n";
    report = report + "Game time at start: " + vote.start_time + " ms\n";
    report = report + "Game time at result: " + GetTime() + " ms\n";
    report = report + "Map: " + community_get_map_display(map_name) +
        " (" + map_name + ")\n";
    report = report + "Round: " + round_number + "\n";
    report = report + "Player count at result: " +
        GetPlayers().size + "\n\n";

    report = report + "Initiator: " + vote.initiator_name + "\n";
    report = report + "Initiator role: " +
        vote.initiator_role + "\n";
    report = report + "Target: " + vote.target_name + "\n";
    report = report + "Target role: " + vote.target_role + "\n";
    report = report + "Reason: " + vote.reason + "\n\n";

    report = report + "Result: " + result_text + "\n";
    report = report + "Result reason: " + result_reason + "\n";
    report = report + "YES votes: " + vote.yes_players.size + "\n";
    report = report + "NO votes: " + vote.no_players.size + "\n";
    report = report + "Required voters: " +
        vote.required_players.size + "\n";

    report = report +
        "\n------------------------------------------------------------\n";
    report = report + "Individual votes\n";
    report = report +
        "------------------------------------------------------------\n";

    for (i = 0; i < vote.required_players.size; i++)
    {
        voter_name = vote.required_players[i];
        report = report + voter_name + ": " +
            community_get_vote_state_for_player(
                vote,
                voter_name
            ) + "\n";
    }

    report = report +
        "\n------------------------------------------------------------\n";
    report = report + "Vote and connection events\n";
    report = report +
        "------------------------------------------------------------\n";

    for (i = 0; i < vote.events.size; i++)
        report = report + vote.events[i] + "\n";

    report = community_append_history(
        report,
        "Recent chat — Initiator: " + vote.initiator_name,
        initiator_history
    );

    report = community_append_history(
        report,
        "Recent chat — Target: " + vote.target_name,
        target_history
    );

    if (passed)
    {
        report = report +
            "\nAction result is appended after command verification.\n";
    }
    else
    {
        report = report + "\nAction: not executed because vote failed.\n";
    }

    report = report + "============================================================\n";
    report = report + "End of initial report\n";
    report = report + "============================================================\n";

    writefile(report_path, report);

    appendfile(
        "pintemod/logs/votekick_summary.log",
        "[" + GetTime() + "] " + result_text +
        " | " + vote.initiator_name + " -> " +
        vote.target_name + " | reason=" + vote.reason +
        " | report=" + report_path + "\n"
    );

    println("^5[PinteMod]^7 Vote kick report: " + report_path);

    return report_path;
}

// ------------------------------------------------------------
// Vote commands
// ------------------------------------------------------------

function cmd_ezzvotemap(args)
{
    community_apply_defaults();

    if (!level.pintemod_map_vote_enabled ||
        !level.pintemod_next_map_vote_enabled)
    {
        println("^3[PinteMod]^7 Next-map voting is disabled");
        return;
    }

    if (args.size < 2)
    {
        println(
            "^5[PinteMod]^7 Usage: " +
            "ezzvotemap <PlayerName> <MapAlias>"
        );
        return;
    }

    initiator = community_find_player(args[0]);

    if (!isdefined(initiator))
    {
        println("^1[PinteMod] Player not found: " + args[0]);
        return;
    }

    if (!community_vote_is_available(initiator))
        return;

    if (GetPlayers().size < level.pintemod_map_vote_min_players)
    {
        initiator iprintln(
            "^3[PinteMod]^7 At least " +
            level.pintemod_map_vote_min_players +
            " players are required."
        );
        return;
    }

    map_code = community_resolve_map_alias(args[1]);

    if (!isdefined(map_code))
    {
        initiator iprintln("^1[PinteMod]^7 Unknown map alias: " + args[1]);
        initiator iprintln(
            "^3Aliases: shadows, giant, de, zns, gk, rev, " +
            "nacht, verruckt, shino, kino, ascension, shang, " +
            "moon, origins"
        );
        return;
    }

    community_create_vote("nextmap", initiator);
    level.pintemod_vote.map_code = map_code;
    level.pintemod_vote.map_display =
        community_get_map_display(map_code);

    community_add_all_players_to_required(undefined);

    level.pintemod_vote.yes_players = community_array_add_unique(
        level.pintemod_vote.yes_players,
        initiator.name
    );

    community_vote_add_event(
        initiator.name + " automatically voted YES"
    );

    community_broadcast(
        "^5[PinteMod]^7 " + initiator.name +
        " started a NEXT MAP vote for ^2" +
        level.pintemod_vote.map_display + "^7."
    );

    community_broadcast(
        "^7Current game will continue. Open ^2.menu ^7or vote " +
        "with ^2.yes ^7/ ^1.no^7."
    );

    community_broadcast_chat(
        "NEXT MAP vote for " + level.pintemod_vote.map_display +
        ". Vote with .yes or .no, or open .menu."
    );

    appendfile(
        "pintemod/logs/community.log",
        "[" + GetTime() + "] NEXT_MAP_VOTE_START | " +
        initiator.name + " | map=" + map_code + "\n"
    );

    community_start_vote_timer();
    community_check_unanimity();
}

function cmd_ezzvoterestart(args)
{
    community_apply_defaults();

    if (!level.pintemod_restart_vote_enabled)
    {
        println("^3[PinteMod]^7 Restart voting is disabled");
        return;
    }

    if (args.size < 1)
    {
        println(
            "^5[PinteMod]^7 Usage: " +
            "ezzvoterestart <PlayerName>"
        );
        return;
    }

    initiator = community_find_player(args[0]);

    if (!isdefined(initiator))
    {
        println("^1[PinteMod] Player not found: " + args[0]);
        return;
    }

    if (!community_vote_is_available(initiator))
        return;

    if (GetPlayers().size < level.pintemod_map_vote_min_players)
    {
        initiator iprintln(
            "^3[PinteMod]^7 At least " +
            level.pintemod_map_vote_min_players +
            " players are required."
        );
        return;
    }

    map_code = community_get_map_name();
    map_display = community_get_map_display(map_code);

    community_create_vote("restart", initiator);
    level.pintemod_vote.map_code = map_code;
    level.pintemod_vote.map_display = map_display;

    community_add_all_players_to_required(undefined);

    level.pintemod_vote.yes_players = community_array_add_unique(
        level.pintemod_vote.yes_players,
        initiator.name
    );

    community_vote_add_event(
        initiator.name + " automatically voted YES"
    );

    community_broadcast(
        "^5[PinteMod]^7 " + initiator.name +
        " started a RESTART vote for ^2" + map_display + "^7."
    );
    community_broadcast(
        "^7Open ^2.menu ^7or vote with ^2.yes ^7/ ^1.no^7."
    );
    community_broadcast_chat(
        "RESTART vote. Vote with .yes or .no, or open .menu."
    );

    appendfile(
        "pintemod/logs/community.log",
        "[" + GetTime() + "] RESTART_VOTE_START | " +
        initiator.name + " | map=" + map_code + "\n"
    );

    community_start_vote_timer();
    community_check_unanimity();
}

function cmd_ezzvotekick(args)
{
    community_apply_defaults();

    if (!level.pintemod_votekick_enabled)
    {
        println("^3[PinteMod]^7 Vote kick is disabled");
        return;
    }

    if (args.size < 2)
    {
        println(
            "^5[PinteMod]^7 Usage: " +
            "ezzvotekick <InitiatorName> <TargetName> [Reason]"
        );
        return;
    }

    initiator = community_find_player(args[0]);
    target = community_find_player(args[1]);

    if (!isdefined(initiator))
    {
        println("^1[PinteMod] Player not found: " + args[0]);
        return;
    }

    if (!isdefined(target))
    {
        initiator iprintln("^1[PinteMod]^7 Player not found: " + args[1]);
        return;
    }

    if (initiator == target)
    {
        initiator iprintln("^1[PinteMod]^7 You cannot target yourself.");
        return;
    }

    if (GetPlayers().size < level.pintemod_votekick_min_players)
    {
        initiator iprintln(
            "^3[PinteMod]^7 At least " +
            level.pintemod_votekick_min_players +
            " players are required."
        );
        return;
    }

    target_role = community_get_role(target);

    if (target_role >= 3)
    {
        initiator iprintln("^1[PinteMod]^7 Owner and Admin are protected.");
        return;
    }

    if (target_role == 2 &&
        level.pintemod_votekick_protect_moderators)
    {
        initiator iprintln("^1[PinteMod]^7 Moderators are protected.");
        return;
    }

    if (isdefined(initiator.pintemod_votekick_cooldown_until) &&
        GetTime() < initiator.pintemod_votekick_cooldown_until)
    {
        remaining = community_get_remaining_seconds(
            initiator.pintemod_votekick_cooldown_until
        );
        initiator iprintln(
            "^3[PinteMod]^7 Personal vote-kick cooldown: " +
            remaining + "s"
        );
        return;
    }

    if (isdefined(target.pintemod_votekick_target_cooldown_until) &&
        GetTime() < target.pintemod_votekick_target_cooldown_until)
    {
        remaining = community_get_remaining_seconds(
            target.pintemod_votekick_target_cooldown_until
        );
        initiator iprintln(
            "^3[PinteMod]^7 This player was recently targeted. " +
            "Protection: " + remaining + "s"
        );
        return;
    }

    if (!community_vote_is_available(initiator))
        return;

    reason = "Not provided";

    if (args.size >= 3)
        reason = community_join_args(args, 2);

    initiator.pintemod_votekick_cooldown_until = GetTime() +
        (level.pintemod_votekick_player_cooldown * 1000);

    target.pintemod_votekick_target_cooldown_until = GetTime() +
        (level.pintemod_votekick_target_cooldown * 1000);

    community_create_vote("kick", initiator);
    level.pintemod_vote.target_name = target.name;
    level.pintemod_vote.target_role =
        community_get_role_name(target_role);
    level.pintemod_vote.reason = reason;
    level.pintemod_vote.target_chat_start =
        community_capture_chat(target);

    community_add_all_players_to_required(target);

    level.pintemod_vote.yes_players = community_array_add_unique(
        level.pintemod_vote.yes_players,
        initiator.name
    );

    community_vote_add_event(
        initiator.name + " automatically voted YES"
    );

    community_broadcast(
        "^5[PinteMod]^7 " + initiator.name +
        " started a vote kick against ^1" +
        target.name + "^7."
    );

    community_broadcast("^7Reason: ^3" + reason);
    community_broadcast(
        "^7Target cannot vote. Type ^2.yes ^7or ^1.no^7. " +
        "Vote: ^2" + level.pintemod_vote.yes_players.size +
        "/" + level.pintemod_vote.required_players.size
    );

    target iprintln("^1[PinteMod]^7 A vote kick was started against you.");
    target iprintln("^7Reason: ^3" + reason);

    appendfile(
        "pintemod/logs/community.log",
        "[" + GetTime() + "] KICK_VOTE_START | " +
        initiator.name + " -> " + target.name +
        " | reason=" + reason + "\n"
    );

    community_start_vote_timer();
    community_check_unanimity();
}

function cmd_ezzyes(args)
{
    if (args.size < 1)
    {
        println("^5[PinteMod]^7 Usage: ezzyes <PlayerName>");
        return;
    }

    player = community_find_player(args[0]);

    if (isdefined(player))
        community_cast_vote(player, true);
}

function cmd_ezzno(args)
{
    if (args.size < 1)
    {
        println("^5[PinteMod]^7 Usage: ezzno <PlayerName>");
        return;
    }

    player = community_find_player(args[0]);

    if (isdefined(player))
        community_cast_vote(player, false);
}

function community_show_vote_status(player)
{
    if (!isdefined(level.pintemod_vote) ||
        !level.pintemod_vote.active)
    {
        player iprintln("^3[PinteMod]^7 No vote is active.");

        if (isdefined(level.pintemod_next_map_code) &&
            level.pintemod_next_map_code != "")
        {
            player iprintln(
                "^5[PinteMod]^7 Scheduled next map: ^2" +
                level.pintemod_next_map_display
            );
        }

        player iprintln("^7Last result: " + level.pintemod_last_vote_summary);
        return;
    }

    vote = level.pintemod_vote;
    remaining = community_get_remaining_seconds(vote.end_time);

    if (vote.type == "nextmap")
    {
        player iprintln(
            "^5[PinteMod]^7 NEXT MAP VOTE: ^2" + vote.map_display
        );
    }
    else if (vote.type == "restart")
    {
        player iprintln(
            "^5[PinteMod]^7 RESTART VOTE: ^2" + vote.map_display
        );
    }
    else
    {
        player iprintln(
            "^5[PinteMod]^7 KICK VOTE: ^1" + vote.target_name
        );
        player iprintln("^7Reason: ^3" + vote.reason);
    }

    player iprintln(
        "^7YES: ^2" + vote.yes_players.size + "/" +
        vote.required_players.size + " ^7| NO: ^1" +
        vote.no_players.size + " ^7| Time: " + remaining + "s"
    );
}

function cmd_ezzvotestatus(args)
{
    if (args.size >= 1)
    {
        player = community_find_player(args[0]);

        if (isdefined(player))
            community_show_vote_status(player);

        return;
    }

    println("^5========== PINTEMOD VOTE STATUS ==========");

    if (!isdefined(level.pintemod_vote) ||
        !level.pintemod_vote.active)
    {
        println("^7No active vote");

        if (isdefined(level.pintemod_next_map_code) &&
            level.pintemod_next_map_code != "")
        {
            println(
                "^7Scheduled next map: " +
                level.pintemod_next_map_display + " (" +
                level.pintemod_next_map_code + ")"
            );
        }

        println("^7Last: " + level.pintemod_last_vote_summary);
    }
    else
    {
        println("^7Type: " + level.pintemod_vote.type);
        println("^7Initiator: " + level.pintemod_vote.initiator_name);
        println(
            "^7YES: " + level.pintemod_vote.yes_players.size +
            "/" + level.pintemod_vote.required_players.size
        );
    }

    println("^5===========================================");
}

function cmd_ezzcancelvote(args)
{
    if (!isdefined(level.pintemod_vote) ||
        !level.pintemod_vote.active)
    {
        println("^3[PinteMod]^7 No vote is active");
        return;
    }

    if (args.size <= 0)
    {
        community_finish_vote(false, "Cancelled by server console");
        return;
    }

    player = community_find_player(args[0]);

    if (!isdefined(player))
        return;

    if (community_get_role(player) < 3)
    {
        player iprintln("^1[PinteMod]^7 Admin role required.");
        return;
    }

    community_finish_vote(
        false,
        "Cancelled by administrator " + player.name
    );
}

function cmd_ezzclearnextmap(args)
{
    if (args.size <= 0)
    {
        if (!community_clear_scheduled_next_map("server console"))
            println("^3[PinteMod]^7 No next map is scheduled");

        return;
    }

    player = community_find_player(args[0]);

    if (!isdefined(player))
        return;

    if (community_get_role(player) < 3)
    {
        player iprintln("^1[PinteMod]^7 Admin role required.");
        return;
    }

    if (!community_clear_scheduled_next_map(player.name))
        player iprintln("^3[PinteMod]^7 No next map is scheduled.");
}

// ------------------------------------------------------------
// Public information commands
// ------------------------------------------------------------

function cmd_ezzpublicinfo(args)
{
    if (args.size < 1)
        return;

    player = community_find_player(args[0]);

    if (!isdefined(player))
        return;

    player iprintln(
        "^5[PinteMod]^7 Map: ^2" +
        community_get_map_display(community_get_map_name())
    );
    player iprintln("^5[PinteMod]^7 Round: ^2" + community_get_round());
    player iprintln("^5[PinteMod]^7 Players: ^2" + GetPlayers().size);

    if (isdefined(level.pintemod_next_map_code) &&
        level.pintemod_next_map_code != "")
    {
        player iprintln(
            "^5[PinteMod]^7 Next map: ^2" +
            level.pintemod_next_map_display
        );
    }
    else
    {
        player iprintln("^5[PinteMod]^7 Next map: ^3not scheduled");
    }

    if (player.pintemod_late_join_eligible &&
        !player.pintemod_late_join_consumed)
    {
        player iprintln("^5[PinteMod]^7 Join Game: ^2available");
    }
    else
    {
        player iprintln("^5[PinteMod]^7 Join Game: ^3unavailable");
    }
}

function cmd_ezzpublicplayers(args)
{
    if (args.size < 1)
        return;

    requester = community_find_player(args[0]);

    if (!isdefined(requester))
        return;

    players = GetPlayers();
    requester iprintln("^5=== PLAYERS ONLINE: " + players.size + " ===");

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (!isdefined(player))
            continue;

        requester iprintln(
            "^7" + player.name + " ^3[" +
            community_get_role_name(community_get_role(player)) +
            "]"
        );
    }
}

function cmd_ezzpublichelp(args)
{
    if (args.size < 1)
        return;

    player = community_find_player(args[0]);

    if (!isdefined(player))
        return;

    player iprintln("^5=== PinteMod PLAYER HELP ===");
    player iprintln("^2Use .menu for all Community actions.");
    player iprintln("^7Votes: next map, restart, kick, YES / NO, status.");
    player iprintln("^7Shortcuts: .spawn / .yes / .no / .votestatus");
    player iprintln("^7Optional: .votemap <map> / .voterestart");
    player iprintln("^7Optional: .votekick <player> [reason]");
    player iprintln(
        "^3Map aliases: shadows, giant, de, zns, gk, rev, " +
        "nacht, verruckt, shino, kino, ascension, shang, " +
        "moon, origins"
    );
}

function cmd_ezzcommunitystatus(args)
{
    community_apply_defaults();

    println("^5======= PINTEMOD COMMUNITY v1.2 FINAL =======");
    println("^7Welcome: " + level.pintemod_welcome_enabled);
    println("^7Public menu: " + level.pintemod_public_menu_enabled);
    println("^7Late join: " + level.pintemod_late_join_enabled);
    println("^7Next-map vote: " + level.pintemod_next_map_vote_enabled);
    println("^7Restart vote: " + level.pintemod_restart_vote_enabled);
    println("^7Vote kick: " + level.pintemod_votekick_enabled);
    println("^7Vote logs: " + level.pintemod_vote_logs_enabled);
    println("^7Vote duration: " + level.pintemod_vote_duration + "s");
    println("^7Global cooldown: " + level.pintemod_vote_cooldown + "s");
    println(
        "^7Map/restart minimum players: " +
        level.pintemod_map_vote_min_players
    );
    println("^7Map command: " + level.pintemod_map_command);
    println("^7Kick command: " + level.pintemod_kick_command);

    if (isdefined(level.pintemod_next_map_code) &&
        level.pintemod_next_map_code != "")
    {
        println(
            "^7Scheduled next map: " +
            level.pintemod_next_map_display + " (" +
            level.pintemod_next_map_code + ")"
        );
    }
    else
    {
        println("^7Scheduled next map: none");
    }

    println("^7Logs: boiii/scriptdata/pintemod/logs/");
    println("^5=============================================");
}
