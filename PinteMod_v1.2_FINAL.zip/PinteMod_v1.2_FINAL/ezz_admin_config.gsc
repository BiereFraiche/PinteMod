// ============================================================
// PinteMod — Configuration centralisée v1.2 FINAL
// Fichier : ezz_admin_config.gsc
// Créé par BiereFraiche et ChatGPT
//
// Rôles : Owner 4, Admin 3, Moderator 2, Helper 1, User 0.
// La comparaison des pseudonymes est insensible à la casse.
// Les changements effectués avec .setrole restent temporaires.
// ============================================================

autoexec function init()
{
    level.ezz_admin_version = "1.2-FINAL";
    level.ezz_admin_debug = false;

    // --------------------------------------------------------
    // Central chat/HUD color theme
    // --------------------------------------------------------
    level.ezz_color_success = "^2";
    level.ezz_color_error = "^1";
    level.ezz_color_warning = "^3";
    level.ezz_color_admin = "^5";
    level.ezz_color_info = "^6";
    level.ezz_color_normal = "^7";
    level.ezz_admin_prefix = "^5[PinteMod]^7";

    // --------------------------------------------------------
    // Persistent role configuration
    // --------------------------------------------------------
    level.ezz_owner_names = [];
    level.ezz_owner_names[0] = "BiereFraiche";

    level.ezz_admin_names = [];
    // level.ezz_admin_names[0] = "AdminName";

    level.ezz_moderator_names = [];
    // level.ezz_moderator_names[0] = "ModeratorName";

    level.ezz_helper_names = [];
    // level.ezz_helper_names[0] = "HelperName";

    level.ezz_admin_max_points = 999999;

    // --------------------------------------------------------
    // Community features
    // --------------------------------------------------------
    level.pintemod_welcome_enabled = true;
    level.pintemod_welcome_delay = 6;

    level.pintemod_public_menu_enabled = true;
    level.pintemod_late_join_enabled = true;

    // .votemap now schedules the next map without interrupting
    // the current Zombies game. The current map may be selected
    // again to allow a community retry.
    level.pintemod_map_vote_enabled = true;
    level.pintemod_next_map_vote_enabled = true;
    level.pintemod_restart_vote_enabled = true;
    level.pintemod_votekick_enabled = true;
    level.pintemod_vote_logs_enabled = true;

    level.pintemod_vote_duration = 45;
    level.pintemod_vote_cooldown = 180;
    // Solo players may schedule the next map or restart at 1/1.
    // Vote kick keeps its separate minimum of three players.
    level.pintemod_map_vote_min_players = 1;
    level.pintemod_map_change_delay = 5;

    level.pintemod_votekick_min_players = 3;
    level.pintemod_votekick_player_cooldown = 180;
    level.pintemod_votekick_target_cooldown = 300;
    level.pintemod_votekick_protect_moderators = false;
    level.pintemod_kick_delay = 3;

    // Commands exposed by the BOIII dedicated server.
    // Map votes only resolve to the 14 official BO3 Zombies map codes.
    // clientkick currently receives the exact player pseudonym; stable
    // SteamID/XUID identification is planned before public deployment.
    level.pintemod_map_command = "map";
    level.pintemod_kick_command = "clientkick";

    // --------------------------------------------------------
    // Existing validated modules
    // --------------------------------------------------------
    level.pintemod_enable_music = true;
    level.pintemod_enable_events = true;
    level.pintemod_max_spawned_bosses = 2;

    // Chat capture used by reports and the Live Console.
    level.pintemod_chat_history_size = 25;
    level.pintemod_chat_dedup_window_ms = 250;

    println("^5[PinteMod]^7 Configuration v1.2 FINAL loaded");
}
