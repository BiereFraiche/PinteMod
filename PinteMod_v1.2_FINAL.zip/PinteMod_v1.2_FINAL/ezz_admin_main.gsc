// ============================================================
// PinteMod Core v1.2 FINAL
// Fichier : ezz_admin_main.gsc
// Créé par BiereFraiche et ChatGPT
//
// Point d'entrée autonome du framework dédié Zombies.
// ============================================================

autoexec function init()
{
    level.ezz_admin_loaded = true;
    level.ezz_admin_release = "1.2-FINAL";

    println("^5[PinteMod]^7 Core v1.2 FINAL loaded");
    println("^5[PinteMod]^7 Créé par BiereFraiche et ChatGPT");
}
