// ============================================================
// PinteMod Core v1.3 FINAL
// Fichier : ezz_admin_main.gsc
// Créé par BiereFraiche et ChatGPT
//
// Point d'entrée autonome du framework dédié Zombies.
// ============================================================

autoexec function init()
{
    level.ezz_admin_loaded = true;
    level.ezz_admin_release = "1.3-FINAL";

    println("^5[PinteMod]^7 Core v1.3 FINAL loaded");
    say("^3[PinteMod]^7 ^2v1.3 FINAL chargée^7");
}
