// ============================================================
// PinteMod — Commandes principales v0.4.3
// Fichier : ezz_admin_commands.gsc
// Créé par BiereFraiche et ChatGPT
//
// Points, munitions, God Mode, ignore, joueurs, zombies et
// réapparition native des joueurs en spectateur.
// ============================================================

#using scripts\zm\_zm;
#using scripts\zm\_zm_utility;


// ------------------------------------------------------------
// Global PinteMod message without BO3's [All]UnknownSoldier prefix
// ------------------------------------------------------------

function commands_broadcast(message)
{
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (isdefined(player))
            player iprintln(message);
    }
}

function commands_mark_gameplay_command(command_name, target_name)
{
    level.pintemod_gameplay_command_pending = true;
    level.pintemod_gameplay_command_name = command_name;
    level.pintemod_gameplay_command_target = target_name;

    level notify(
        "pintemod_gameplay_command_used",
        command_name,
        target_name
    );
}

autoexec function init()
{
    addcommand("ezztest", ::cmd_ezztest);
    addcommand("ezzplayers", ::cmd_ezzplayers);
    addcommand("help", ::cmd_help);

    addcommand("points", ::cmd_points);
    addcommand("maxpoints", ::cmd_maxpoints);

    addcommand("ammo", ::cmd_ammo);
    addcommand("godmode", ::cmd_godmode);
    addcommand("ignore", ::cmd_ignore);

    addcommand("killzombies", ::cmd_killzombies);
    addcommand("ezzspawn", ::cmd_ezzspawn);

    println("^3[PinteMod]^7 Stable command module v0.4.3 Spawn loaded");
}

// ------------------------------------------------------------
// Shared helpers
// ------------------------------------------------------------

function get_first_player()
{
    players = GetPlayers();

    if (players.size > 0)
        return players[0];

    return undefined;
}

function find_player_exact(player_name)
{
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (isdefined(player) && player.name == player_name)
            return player;
    }

    return undefined;
}

function get_target_from_optional_name(args)
{
    if (args.size > 0)
        return find_player_exact(args[0]);

    return get_first_player();
}

function get_safe_godmode_target(args)
{
    players = GetPlayers();

    if (args.size > 0)
        return find_player_exact(args[0]);

    if (players.size == 1)
        return players[0];

    if (players.size > 1)
    {
        println("^1[PinteMod] Several players are connected");
        println("^3[PinteMod]^7 Usage: godmode <PlayerName>");
    }

    return undefined;
}

function print_no_players()
{
    println("^1[PinteMod] No connected player");
}

function print_player_not_found(player_name)
{
    println("^1[PinteMod] Player not found: " + player_name);
}

function print_target_error(args)
{
    if (args.size > 0)
        print_player_not_found(args[0]);
    else
        print_no_players();
}

// ------------------------------------------------------------
// Diagnostics and help
// ------------------------------------------------------------

function cmd_ezztest(args)
{
    println("^3[PinteMod]^7 Dedicated v0.4.3 test OK");

    if (isdefined(level.ezz_admin_version))
        println("^3[PinteMod]^7 Config version: " + level.ezz_admin_version);

    if (isdefined(level.ezz_admin_loaded) && level.ezz_admin_loaded)
        println("^3[PinteMod]^7 Main module state: ready");
}

function cmd_ezzplayers(args)
{
    players = GetPlayers();

    if (players.size <= 0)
    {
        print_no_players();
        return;
    }

    println("^3[PinteMod]^7 Connected players: " + players.size);

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (isdefined(player))
            println("^3[PinteMod]^7 [" + i + "] " + player.name);
    }
}

function cmd_help(args)
{
    println("^3========== PinteMod ADMIN ==========");
    println("^7ezzplayers");
    println("^7points <amount>");
    println("^7points <PlayerName> <amount>");
    println("^7maxpoints [PlayerName]");
    println("^7ammo [PlayerName]");
    println("^7godmode <PlayerName>  ^3(required in multiplayer)");
    println("^7ignore [PlayerName]");
    println("^7killzombies");
    println("^7ezzspawn <PlayerName>");
    println("^5Weapons commands are in ezz_admin_weapons.gsc");
    println("^3================================");
}

// ------------------------------------------------------------
// Points
// ------------------------------------------------------------

function cmd_points(args)
{
    player = undefined;
    amount = 0;

    if (args.size == 1)
    {
        player = get_first_player();
        amount = int(args[0]);
    }
    else if (args.size >= 2)
    {
        player = find_player_exact(args[0]);

        if (!isdefined(player))
        {
            print_player_not_found(args[0]);
            return;
        }

        amount = int(args[1]);
    }
    else
    {
        println("^3[PinteMod]^7 Usage: points <amount>");
        println("^3[PinteMod]^7 Usage: points <PlayerName> <amount>");
        return;
    }

    if (!isdefined(player))
    {
        print_no_players();
        return;
    }

    if (amount == 0)
    {
        println("^1[PinteMod] Amount must be a non-zero number");
        return;
    }

    if (amount > 999999)
        amount = 999999;

    if (amount < -999999)
        amount = -999999;

    commands_mark_gameplay_command(
        "points",
        player.name
    );
    player.score += amount;
    player iprintln("^2Points changed: " + amount);
    println("^3[PinteMod]^7 Points changed for " + player.name + ": " + amount);
}

function cmd_maxpoints(args)
{
    player = get_target_from_optional_name(args);

    if (!isdefined(player))
    {
        print_target_error(args);
        return;
    }

    commands_mark_gameplay_command(
        "maxpoints",
        player.name
    );

    if (isdefined(level.ezz_admin_max_points))
        player.score = level.ezz_admin_max_points;
    else
        player.score = 999999;

    player iprintln("^2Points maxed");
    println("^3[PinteMod]^7 Points maxed for " + player.name);
}

// ------------------------------------------------------------
// Ammunition
// ------------------------------------------------------------

function cmd_ammo(args)
{
    player = get_target_from_optional_name(args);

    if (!isdefined(player))
    {
        print_target_error(args);
        return;
    }

    commands_mark_gameplay_command(
        "ammo",
        player.name
    );
    player GiveMaxAmmo(player GetCurrentWeapon());

    player iprintln("^2Ammo refilled");
    println("^3[PinteMod]^7 Ammo refilled for " + player.name);
}

// ------------------------------------------------------------
// Native God Mode
// ------------------------------------------------------------

function cmd_godmode(args)
{
    player = get_safe_godmode_target(args);

    if (!isdefined(player))
    {
        players = GetPlayers();

        if (args.size > 0)
            print_player_not_found(args[0]);
        else if (players.size <= 0)
            print_no_players();

        return;
    }

    commands_mark_gameplay_command(
        "godmode",
        player.name
    );

    if (!isdefined(player.admin_god))
        player.admin_god = false;

    player.admin_god = !player.admin_god;

    if (player.admin_god)
    {
        player.admin_old_health = player.health;
        player.admin_old_maxhealth = player.maxhealth;

        // Native engine protection.
        player EnableInvulnerability();

        // Additional fallback for Zombies scripts which inspect health values.
        player.maxhealth = 99999;
        player.health = 99999;

        player iprintln("^2God Mode ON");
        commands_broadcast("^2" + player.name + " -> God Mode ON");
        println("^2[PinteMod] Native God Mode ON for " + player.name);
    }
    else
    {
        // Remove native protection first.
        player DisableInvulnerability();

        if (isdefined(player.admin_old_maxhealth))
            player.maxhealth = player.admin_old_maxhealth;
        else
            player.maxhealth = 100;

        if (isdefined(player.admin_old_health))
            player.health = player.admin_old_health;
        else
            player.health = player.maxhealth;

        if (player.health <= 0)
            player.health = player.maxhealth;

        player iprintln("^1God Mode OFF");
        commands_broadcast("^1" + player.name + " -> God Mode OFF");
        println("^1[PinteMod] Native God Mode OFF for " + player.name);
    }
}

// ------------------------------------------------------------
// Zombie ignore flag
// ------------------------------------------------------------

function cmd_ignore(args)
{
    player = get_target_from_optional_name(args);

    if (!isdefined(player))
    {
        print_target_error(args);
        return;
    }

    commands_mark_gameplay_command(
        "ignore",
        player.name
    );

    if (!isdefined(player.admin_ignore))
        player.admin_ignore = false;

    player.admin_ignore = !player.admin_ignore;

    // BO3 stacks temporary ignore effects through ignorme_count.
    // Using the native helpers keeps the admin state independent from
    // Zombie Blood, In Plain Sight and other temporary effects.
    if (player.admin_ignore)
    {
        player zm_utility::increment_ignoreme();
        player iprintln("^2Zombie Ignore ON");
        println("^2[PinteMod] Zombie Ignore ON for " + player.name);
    }
    else
    {
        player zm_utility::decrement_ignoreme();
        player iprintln("^1Zombie Ignore OFF");
        println("^1[PinteMod] Zombie Ignore OFF for " + player.name);
    }
}

// ------------------------------------------------------------
// Zombies
// ------------------------------------------------------------

function cmd_killzombies(args)
{
    zombies = GetAIArray();
    count = 0;

    for (i = 0; i < zombies.size; i++)
    {
        zombie = zombies[i];

        if (isdefined(zombie) && IsAlive(zombie))
        {
            zombie DoDamage(zombie.health + 9999, zombie.origin);
            count++;
        }
    }

    if (count > 0)
    {
        commands_mark_gameplay_command(
        "killzombies",
        "all"
    );
    }

    commands_broadcast("^1" + count + " zombies killed");
    println("^3[PinteMod]^7 Zombies killed: " + count);
}

// ------------------------------------------------------------
// Native spectator respawn
// ------------------------------------------------------------

function get_safe_spawn_target(args)
{
    players = GetPlayers();

    if (args.size > 0)
        return find_player_exact(args[0]);

    if (players.size == 1)
        return players[0];

    if (players.size > 1)
    {
        println("^1[PinteMod] Several players are connected");
        println("^3[PinteMod]^7 Usage: ezzspawn <PlayerName>");
    }

    return undefined;
}

function cmd_ezzspawn(args)
{
    player = get_safe_spawn_target(args);

    if (!isdefined(player))
    {
        if (args.size > 0)
            print_player_not_found(args[0]);
        else if (GetPlayers().size <= 0)
            print_no_players();

        return;
    }

    if (!isdefined(player.sessionstate) ||
        player.sessionstate != "spectator")
    {
        println("^3[PinteMod]^7 " + player.name + " is not a spectator");
        player iprintln("^3You are already active");
        return;
    }

    if (!isdefined(player.spectator_respawn))
    {
        println(
            "^1[PinteMod] Native spectator respawn data unavailable for " +
            player.name
        );
        player iprintln("^1Respawn is not ready yet");
        return;
    }

    player zm::spectator_respawn_player();

    wait 0.1;

    if (isdefined(player.sessionstate) &&
        player.sessionstate != "spectator")
    {
        commands_mark_gameplay_command(
        "admin respawn",
        player.name
    );

        println("^2[PinteMod] Spectator respawned: " + player.name);
        player iprintln("^2You have been spawned");
        commands_broadcast("^2" + player.name + " rejoined the game");
    }
    else
    {
        println("^1[PinteMod] Native spectator respawn did not complete");
        player iprintln("^1Respawn failed; try again when a survivor is active");
    }
}
