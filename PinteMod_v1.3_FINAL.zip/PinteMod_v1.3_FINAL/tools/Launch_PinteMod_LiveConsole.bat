@echo off
setlocal
title PinteMod Live Console

if "%~1"=="" (
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0PinteMod_LiveConsole.ps1"
) else (
    powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0PinteMod_LiveConsole.ps1" -ServerRoot "%~1"
)

if errorlevel 1 pause
endlocal
