﻿param(
    [string]$ServerRoot = "",
    [int]$InitialLines = 8,
    [int]$PollMilliseconds = 250
)

$ErrorActionPreference = "Stop"
$Host.UI.RawUI.WindowTitle = "PinteMod Live Console"

function Get-RootCandidates {
    param([string]$ExplicitRoot)

    $candidates = New-Object System.Collections.Generic.List[string]

    if (-not [string]::IsNullOrWhiteSpace($ExplicitRoot)) {
        $candidates.Add($ExplicitRoot)
    }

    if (-not [string]::IsNullOrWhiteSpace($env:PINTEMOD_SERVER_ROOT)) {
        $candidates.Add($env:PINTEMOD_SERVER_ROOT)
    }

    $current = $PSScriptRoot

    for ($i = 0; $i -lt 8 -and -not [string]::IsNullOrWhiteSpace($current); $i++) {
        $candidates.Add($current)
        $parent = Split-Path -Parent $current

        if ($parent -eq $current) {
            break
        }

        $current = $parent
    }

    return $candidates | Select-Object -Unique
}

function Resolve-ServerRoot {
    param([string]$ExplicitRoot)

    foreach ($candidate in Get-RootCandidates -ExplicitRoot $ExplicitRoot) {
        if ([string]::IsNullOrWhiteSpace($candidate)) {
            continue
        }

        try {
            $fullCandidate = [System.IO.Path]::GetFullPath($candidate)
        }
        catch {
            continue
        }

        $boiiiPath = Join-Path $fullCandidate "boiii"

        if (Test-Path -LiteralPath $boiiiPath -PathType Container) {
            return $fullCandidate
        }

        if ((Split-Path -Leaf $fullCandidate) -ieq "boiii") {
            return (Split-Path -Parent $fullCandidate)
        }
    }

    return $null
}

function Get-TagColor {
    param([string]$Tag)

    switch ($Tag.ToUpperInvariant()) {
        "JOIN"      { return "Cyan" }
        "LEAVE"     { return "DarkCyan" }
        "ACTIVE"    { return "Cyan" }
        "CHAT"      { return "White" }
        "COMMUNITY" { return "Green" }
        "MENU"      { return "Blue" }
        "VOTE"      { return "Yellow" }
        "KICK"      { return "Magenta" }
        default      { return "Gray" }
    }
}

function New-LiveEvent {
    param(
        [string]$Tag,
        [AllowEmptyString()][string]$Text
    )

    if ([string]::IsNullOrWhiteSpace($Tag) -or [string]::IsNullOrWhiteSpace($Text)) {
        return $null
    }

    $cleanTag = $Tag.ToUpperInvariant()
    $cleanText = ($Text -replace '\^[0-9]', '').Trim()

    if ([string]::IsNullOrWhiteSpace($cleanText)) {
        return $null
    }

    return [PSCustomObject]@{
        Tag = $cleanTag
        Text = $cleanText
        Color = Get-TagColor -Tag $cleanTag
    }
}

function Convert-ServerLogLine {
    param([AllowEmptyString()][string]$Line)

    if ([string]::IsNullOrWhiteSpace($Line)) {
        return $null
    }

    $cleanLine = $Line -replace '\^[0-9]', ''
    $match = [regex]::Match(
        $cleanLine,
        '\[PinteMod\]\[(JOIN|LEAVE|ACTIVE|CHAT|COMMUNITY|MENU|VOTE|KICK)\]\s*(.*)$',
        [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
    )

    if (-not $match.Success) {
        return $null
    }

    return New-LiveEvent -Tag $match.Groups[1].Value -Text $match.Groups[2].Value
}

function Convert-DirectLogLine {
    param(
        [string]$Kind,
        [AllowEmptyString()][string]$Line
    )

    if ([string]::IsNullOrWhiteSpace($Line)) {
        return $null
    }

    $cleanLine = ($Line.TrimStart([char]0xFEFF) -replace '\^[0-9]', '').Trim()

    if ([string]::IsNullOrWhiteSpace($cleanLine)) {
        return $null
    }

    switch ($Kind) {
        "connections" {
            $match = [regex]::Match(
                $cleanLine,
                '\[(JOIN|LEAVE|ACTIVE)\]\s*(.*)$',
                [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
            )

            if ($match.Success) {
                return New-LiveEvent -Tag $match.Groups[1].Value -Text $match.Groups[2].Value
            }

            return $null
        }

        "chat" {
            # Stored form: [1234 ms][say] Player: message
            $match = [regex]::Match($cleanLine, '^\[[^\]]+\]\[[^\]]+\]\s*(.*)$')

            if ($match.Success) {
                return New-LiveEvent -Tag "CHAT" -Text $match.Groups[1].Value
            }

            return New-LiveEvent -Tag "CHAT" -Text $cleanLine
        }

        "menu" {
            $match = [regex]::Match(
                $cleanLine,
                '^\[[^\]]+\]\[MENU\]\s*(.*)$',
                [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
            )

            if ($match.Success) {
                return New-LiveEvent -Tag "MENU" -Text $match.Groups[1].Value
            }

            return New-LiveEvent -Tag "MENU" -Text $cleanLine
        }

        "community" {
            $text = $cleanLine -replace '^\[[^\]]+\]\s*', ''
            return New-LiveEvent -Tag "COMMUNITY" -Text $text
        }

        "vote" {
            $text = $cleanLine -replace '^\[[^\]]+\]\s*', ''
            return New-LiveEvent -Tag "VOTE" -Text $text
        }

        "kick" {
            $text = $cleanLine -replace '^\[[^\]]+\]\s*', ''
            return New-LiveEvent -Tag "KICK" -Text $text
        }
    }

    return $null
}

function Write-TaggedLine {
    param(
        [Parameter(Mandatory)][string]$Tag,
        [AllowEmptyString()][string]$Text,
        [Parameter(Mandatory)][string]$Color
    )

    $timestamp = Get-Date -Format "HH:mm:ss"
    Write-Host "[$timestamp][$Tag] " -NoNewline -ForegroundColor $Color
    Write-Host $Text
}

function Test-AndRememberEvent {
    param(
        [Parameter(Mandatory)]$Event,
        [Parameter(Mandatory)][hashtable]$RecentEvents
    )

    $now = [DateTime]::UtcNow
    $key = $Event.Tag + "|" + $Event.Text.ToLowerInvariant()

    foreach ($oldKey in @($RecentEvents.Keys)) {
        if (($now - $RecentEvents[$oldKey]).TotalSeconds -gt 3) {
            $RecentEvents.Remove($oldKey)
        }
    }

    if ($RecentEvents.ContainsKey($key)) {
        return $false
    }

    $RecentEvents[$key] = $now
    return $true
}

function Read-AppendedLines {
    param([Parameter(Mandatory)][hashtable]$State)

    $lines = New-Object System.Collections.Generic.List[string]

    if (-not (Test-Path -LiteralPath $State.Path -PathType Leaf)) {
        $State.Available = $false
        return $lines
    }

    $State.Available = $true

    $stream = $null

    try {
        $shareMode = [System.IO.FileShare]::ReadWrite -bor [System.IO.FileShare]::Delete
        $stream = [System.IO.File]::Open(
            $State.Path,
            [System.IO.FileMode]::Open,
            [System.IO.FileAccess]::Read,
            $shareMode
        )

        if ($stream.Length -lt $State.Position) {
            $State.Position = 0L
            $State.Pending = ""
        }

        if ($stream.Length -eq $State.Position) {
            return $lines
        }

        [void]$stream.Seek($State.Position, [System.IO.SeekOrigin]::Begin)
        $remaining = $stream.Length - $State.Position
        $buffer = New-Object byte[] ([int]$remaining)
        $read = $stream.Read($buffer, 0, $buffer.Length)

        if ($read -le 0) {
            return $lines
        }

        $State.Position += $read
        $text = $State.Pending + [System.Text.Encoding]::UTF8.GetString($buffer, 0, $read)
        $parts = [regex]::Split($text, "\r?\n")

        if ($text.EndsWith("`n")) {
            $State.Pending = ""
            $completeCount = $parts.Count
        }
        else {
            $State.Pending = $parts[$parts.Count - 1]
            $completeCount = $parts.Count - 1
        }

        for ($i = 0; $i -lt $completeCount; $i++) {
            if (-not [string]::IsNullOrWhiteSpace($parts[$i])) {
                $lines.Add($parts[$i])
            }
        }
    }
    catch {
        $message = $_.Exception.Message

        if (-not $State.ContainsKey("LastReadError") -or $State.LastReadError -ne $message) {
            Write-Host "[READ ERROR] $($State.Name): $message" -ForegroundColor Red
            $State.LastReadError = $message
        }

        return $lines
    }
    finally {
        if ($null -ne $stream) {
            $stream.Dispose()
        }
    }

    return $lines
}

function Initialize-State {
    param(
        [Parameter(Mandatory)][hashtable]$State,
        [int]$TailLines
    )

    if (-not (Test-Path -LiteralPath $State.Path -PathType Leaf)) {
        return @()
    }

    $item = Get-Item -LiteralPath $State.Path -ErrorAction SilentlyContinue

    if ($null -eq $item) {
        return @()
    }

    $State.Position = [int64]$item.Length
    $State.Pending = ""
    $State.Available = $true
    $State.Initialized = $true

    return @(Get-Content -LiteralPath $State.Path -Tail $TailLines -ErrorAction SilentlyContinue)
}

Clear-Host
Write-Host "============================================================" -ForegroundColor DarkCyan
Write-Host " PinteMod Live Console - v1.3 FINAL (live file polling v5)" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor DarkCyan

$resolvedRoot = Resolve-ServerRoot -ExplicitRoot $ServerRoot

while ($null -eq $resolvedRoot) {
    Write-Host ""
    Write-Host "Serveur BOIII introuvable automatiquement." -ForegroundColor Yellow
    Write-Host "Indique le dossier contenant le sous-dossier boiii." -ForegroundColor Gray
    $enteredRoot = Read-Host "ServerRoot"

    if ([string]::IsNullOrWhiteSpace($enteredRoot)) {
        Write-Host "Chemin vide. Fermeture." -ForegroundColor Red
        exit 1
    }

    $resolvedRoot = Resolve-ServerRoot -ExplicitRoot $enteredRoot
}

$logRoot = Join-Path $resolvedRoot "boiii\scriptdata\pintemod\logs"
$serverLog = Join-Path $resolvedRoot "boiii\server.log"

$states = @(
    @{
        Name = "Connections"
        Kind = "connections"
        Path = Join-Path $logRoot "connections.log"
        Position = 0L
        Pending = ""
        Available = $false
        Initialized = $false
        LastReadError = ""
        IsServerLog = $false
    },
    @{
        Name = "Chat"
        Kind = "chat"
        Path = Join-Path $logRoot "chat\session.log"
        Position = 0L
        Pending = ""
        Available = $false
        Initialized = $false
        LastReadError = ""
        IsServerLog = $false
    },
    @{
        Name = "Menu"
        Kind = "menu"
        Path = Join-Path $logRoot "menu.log"
        Position = 0L
        Pending = ""
        Available = $false
        Initialized = $false
        LastReadError = ""
        IsServerLog = $false
    },
    @{
        Name = "Community"
        Kind = "community"
        Path = Join-Path $logRoot "community.log"
        Position = 0L
        Pending = ""
        Available = $false
        Initialized = $false
        LastReadError = ""
        IsServerLog = $false
    },
    @{
        Name = "Votes"
        Kind = "vote"
        Path = Join-Path $logRoot "vote_summary.log"
        Position = 0L
        Pending = ""
        Available = $false
        Initialized = $false
        LastReadError = ""
        IsServerLog = $false
    },
    @{
        Name = "VoteKick"
        Kind = "kick"
        Path = Join-Path $logRoot "votekick_summary.log"
        Position = 0L
        Pending = ""
        Available = $false
        Initialized = $false
        LastReadError = ""
        IsServerLog = $false
    },
    @{
        Name = "Server fallback"
        Kind = "server"
        Path = $serverLog
        Position = 0L
        Pending = ""
        Available = $false
        Initialized = $false
        LastReadError = ""
        IsServerLog = $true
    }
)

Write-Host " Server: $resolvedRoot" -ForegroundColor Gray
Write-Host " Logs:   $logRoot" -ForegroundColor Gray
Write-Host " Fallback: $serverLog" -ForegroundColor DarkGray
Write-Host " Filtre: JOIN, LEAVE, ACTIVE, CHAT, MENU, COMMUNITY, VOTE, KICK" -ForegroundColor DarkGray
Write-Host " CTRL+C pour fermer." -ForegroundColor DarkGray
Write-Host "============================================================" -ForegroundColor DarkCyan
Write-Host ""

$recentEvents = @{}

foreach ($state in $states) {
    $initialContent = Initialize-State -State $state -TailLines $InitialLines

    if ($state.Initialized) {
        Write-Host "[READY] $($state.Name): $($state.Path)" -ForegroundColor DarkGreen

        foreach ($line in $initialContent) {
            if ($state.IsServerLog) {
                $event = Convert-ServerLogLine -Line $line
            }
            else {
                $event = Convert-DirectLogLine -Kind $state.Kind -Line $line
            }

            if ($null -ne $event -and (Test-AndRememberEvent -Event $event -RecentEvents $recentEvents)) {
                Write-TaggedLine -Tag $event.Tag -Text $event.Text -Color $event.Color
            }
        }
    }
    else {
        Write-Host "[WAIT]  $($state.Name): $($state.Path)" -ForegroundColor DarkYellow
    }
}

Write-Host ""
Write-Host "----- LIVE OUTPUT -----" -ForegroundColor DarkGray

while ($true) {
    foreach ($state in $states) {
        if (-not $state.Initialized) {
            if (Test-Path -LiteralPath $state.Path -PathType Leaf) {
                $initialContent = Initialize-State -State $state -TailLines $InitialLines
                Write-Host "[READY] $($state.Name): $($state.Path)" -ForegroundColor DarkGreen

                foreach ($line in $initialContent) {
                    if ($state.IsServerLog) {
                        $event = Convert-ServerLogLine -Line $line
                    }
                    else {
                        $event = Convert-DirectLogLine -Kind $state.Kind -Line $line
                    }

                    if ($null -ne $event -and (Test-AndRememberEvent -Event $event -RecentEvents $recentEvents)) {
                        Write-TaggedLine -Tag $event.Tag -Text $event.Text -Color $event.Color
                    }
                }
            }

            continue
        }

        $newLines = Read-AppendedLines -State $state

        foreach ($line in $newLines) {
            if ($state.IsServerLog) {
                $event = Convert-ServerLogLine -Line $line
            }
            else {
                $event = Convert-DirectLogLine -Kind $state.Kind -Line $line
            }

            if ($null -ne $event -and (Test-AndRememberEvent -Event $event -RecentEvents $recentEvents)) {
                Write-TaggedLine -Tag $event.Tag -Text $event.Text -Color $event.Color
            }
        }
    }

    Start-Sleep -Milliseconds $PollMilliseconds
}
