# PinteMod v2.0.0


PinteMod est un framework côté serveur pour l’administration, la communauté et les records des serveurs dédiés **Call of Duty: Black Ops III Zombies** utilisant **BOIII/Ezz**.

Projet créé et maintenu par **BiereFraiche**, avec l’assistance de ChatGPT pour le développement.

Aucun mod client n’est requis : les joueurs rejoignent normalement le serveur. PinteMod est chargé depuis `boiii/custom_scripts/`.

## Principales nouveautés de la v2.0.0

- permissions et données persistantes liées au `BOIII_XUID` ;
- transport interne Chat/menu par XUID ou numéro client ;
- refus des pseudos en double au lieu de sélectionner silencieusement le premier ;
- rejet des séparateurs dangereux avant `executecommand()` ;
- écritures JSON vérifiées avec fichier temporaire, sauvegarde `.bak` et quarantaine ;
- journaux séparés par session, rotation par taille et options de confidentialité ;
- Live Console en lecture seule avec filtres, recherche, export et mise en évidence des erreurs ;
- Ranks & Records XUID sur une base v2 vierge ;
- EE Records XUID sur une base v2 indépendante et vierge ;
- revive natif réservé à l’Owner depuis le Chat/menu ;
- registre commun des maps et métadonnées de permissions Chat ;
- profils des 14 maps officielles de BO3 Zombies ;
- 123 commandes console serveur.

## Maps prises en charge

### BO3 et DLC

- Shadows of Evil
- The Giant
- Der Eisendrache
- Zetsubou No Shima
- Gorod Krovi
- Revelations

### Zombies Chronicles

- Nacht der Untoten
- Verrückt
- Shi No Numa
- Kino der Toten
- Ascension
- Shangri-La
- Moon
- Origins

Les maps personnalisées peuvent charger le cœur générique, mais les ouvertures, armes, musiques, événements et profils EE propres à la map ne sont pas garantis.

## Installation

1. Arrêter complètement le serveur dédié.
2. Sauvegarder `boiii/custom_scripts/` et `boiii/scriptdata/pintemod/`.
3. Supprimer les anciens scripts PinteMod pour éviter les doublons.
4. Copier le dossier `custom_scripts/` du paquet dans `boiii/`.
5. Conserver `tools/` à côté de `boiii/` pour utiliser la Live Console.
6. Modifier `boiii/custom_scripts/ezz_admin_config.gsc`.
7. Remplacer ou supprimer le XUID Owner fourni avant d’ouvrir un autre serveur public.
8. Redémarrer complètement puis lancer la vérification recommandée après installation.

Arborescence attendue :

```text
<Racine serveur>/
├── boiii/
│   └── custom_scripts/
│       ├── ezz_admin_00_banner.gsc
│       ├── ezz_admin_01_main.gsc
│       ├── ...
│       ├── ezz_admin_registry.gsc
│       └── ezz_admin_storage.gsc
└── tools/
    ├── Launch_PinteMod_LiveConsole.bat
    └── PinteMod_LiveConsole.ps1
```

`hotfix.gsc` est volontairement absent : il appartient à l’environnement de compatibilité BOIII, pas à PinteMod.

## Owner par défaut

La distribution publique contient un seul Owner de démarrage :

```text
Nom d’affichage : BiereFraiche
BOIII_XUID : 9cf34426f668fb8b
Rôle : owner
```

Aucun Admin, Moderator ou Helper n’est préconfiguré. Aucun `roles.json`, profil, record, vote, sanction, journal ou backup serveur n’est inclus.

Les autres propriétaires doivent remplacer ou supprimer ce XUID dans `ezz_admin_config.gsc`, ou attribuer leur Owner depuis la console dédiée :

```text
ezzidsetrole <PlayerName|BOIII_XUID|ClientNumber> owner
```

## Identité stable et ciblage sécurisé

L’authentification et les données persistantes utilisent le XUID hexadécimal stable fourni par BOIII.

Les commandes console acceptent :

```text
<PlayerName|BOIII_XUID|ClientNumber>
```

Exemples :

```text
ezzidentity 9cf34426f668fb8b
ezzidentity #0
ezzidentity client:0
ezzidentity BiereFraiche
```

Le pseudo n’est qu’un fallback local. Si deux joueurs ont exactement le même pseudo, PinteMod refuse ce sélecteur et demande le XUID ou le numéro client.

Le Chat et le menu transmettent directement le XUID ou le slot client. Ils n’insèrent plus le pseudo brut dans les commandes internes. Le votekick exécute `clientkick <numéro client>`.

Les guillemets, points-virgules et retours à la ligne sont refusés dans les commandes internes et les raisons de votekick.

## Rôles

| Niveau | Rôle | Accès typique |
|---:|---|---|
| 4 | Owner | permissions, revive et maintenance protégée |
| 3 | Admin | maps, manches, ouvertures, Events et actions serveur |
| 2 | Moderator | administration gameplay, armes, atouts et points |
| 1 | Helper | diagnostics et assistance limitée |
| 0 | User | menu public, votes, late join, rangs et records publics |

Les rôles persistants sont stockés dans :

```text
boiii/scriptdata/pintemod/identity/roles.json
```

## Commandes Chat

Le préfixe principal est `.` ; l’ancien préfixe `!` reste compatible.

Commandes publiques courantes :

```text
.menu
.spawn
.yes
.no
.votestatus
.votemap origins
.voterestart
.votekick <joueur> [raison]
.rank
.ranks
.record
.records 2
.eerecord
.eerecords 4
```

Exemples staff selon le rôle :

```text
.points 50000
.ammo
.weapon raygun
.perk jug
.god
.ignore
.respawn <joueur>
.revive <joueur>
.setrole <joueur> moderator
```

Toutes les commandes console figurent dans [`docs/COMMANDES_CONSOLE_FR.txt`](docs/COMMANDES_CONSOLE_FR.txt).

## Menu HUD

Ouverture :

```text
.menu
```

Contrôles :

- **Action Slot 2 / touche 2** : monter ;
- **Action Slot 3 / touche 4** : descendre ;
- **Utiliser / Recharger** : sélectionner ;
- **Mêlée** : retour ou fermeture.

Catégories : Community/Joueurs, Administration, Atouts, Armes, Manches, Power-Ups, Fun, Rankings & Records.

Le contenu dépend du rôle et de la map. Les valeurs internes des cibles sont des XUID/numéros clients ; les pseudos ne servent qu’à l’affichage.

## Community

- HUD de bienvenue et rappels publics ;
- late join public avec `.spawn` ou le Player Menu ;
- respawn administratif ;
- revive natif Owner pour un joueur réellement à terre ;
- vote de prochaine map sans interrompre la partie ;
- vote de redémarrage avec avertissement ;
- votekick protégé, cooldowns XUID et blocage de reconnexion jusqu’à la map suivante ;
- changement automatique de map en fin de partie ;
- présence liée au XUID malgré reconnexion ou changement de pseudo ;
- rapports de connexions, votes et modération.

### Spawn, respawn et revive

- `ezzjoin` / `.spawn` : late join public d’un spectateur éligible ;
- `ezzspawn` : respawn administratif d’un spectateur ;
- `ezzrevive` : réanimation native d’un joueur en last stand, Owner seulement via Chat/menu.

## Ranks & Records

Racine v2 indépendante :

```text
boiii/scriptdata/pintemod/ranks_v2/
```

Fonctionnalités :

- temps de jeu et sessions par XUID ;
- meilleure manche et position d’activité globale ;
- Top 5 par map et catégorie 1P/2P/3P/4P ;
- présence minimale de 70 % pour participer au record ;
- manche la plus élevée puis temps le plus court en cas d’égalité ;
- participants connectés ou déconnectés évalués par XUID ;
- partie automatiquement UNRANKED après une commande affectant le gameplay ;
- rollback des records créés plus tôt dans cette même partie ;
- audit, backup et reset protégé.

Commandes publiques :

```text
.rank
.ranks
.record
.records [1-4]
```

Maintenance :

```text
ezzrankstatus
ezzranktest suite <sélecteur>
ezzrankaudit
ezzrankbackup [label]
ezzrankreset prepare
ezzrankreset confirm <token>
```

Aucun record historique basé sur le pseudo n’est migré automatiquement.

## Easter Egg Records

Racine v2 indépendante :

```text
boiii/scriptdata/pintemod/easter_eggs_v2/
```

Les candidats diagnostiques conservent notamment : XUID des participants, titulaires actifs, joueurs exclus, temps, catégorie, statut ranked/unranked, motif d’acceptation ou de rejet et signature anti-doublon.

Les écritures officielles sont activées **map par map**. Une map reste `DIAGNOSTIC` jusqu’à ce que son secret principal soit terminé sur le serveur réel et que son signal natif soit confirmé.

Commandes principales :

```text
ezzeestatus
ezzeemaps
ezzeeplayers
ezzeetest suite
ezzeeaudit
ezzeecandidates <map>
ezzeevalidate <map> confirm
ezzeeofficial <map> enable
```

Ne jamais activer une map non validée. Voir [`docs/VALIDATION_EE_FR.txt`](docs/VALIDATION_EE_FR.txt).

## Écritures JSON sécurisées

`ezz_admin_storage.gsc` protège les registres Identity, Ranks et EE.

À chaque écriture :

1. création d’un `.tmp` ;
2. relecture et validation ;
3. sauvegarde de l’ancien fichier valide en `.bak` ;
4. écriture et vérification du fichier actif ;
5. restauration de l’ancienne version si la vérification échoue.

Les fichiers invalides sont conservés dans :

```text
boiii/scriptdata/pintemod/backups/corrupt/
```

Un `.bak` valide est restauré lorsqu’il existe. Cette méthode est récupérable mais ne constitue pas un renommage atomique natif du système de fichiers.

Diagnostics :

```text
ezzstoragestatus
ezzstoragetest suite
```

## Journaux et confidentialité

Configuration par défaut :

```gsc
level.pintemod_log_chat_messages = false;
level.pintemod_log_xuids = true;
level.pintemod_log_guids = false;
level.pintemod_log_max_size_kb = 2048;
```

Organisation :

```text
boiii/scriptdata/pintemod/logs/
├── current_session.json
├── sessions/<map>_s<counter>_<GetTime>/
│   ├── connections.log
│   ├── identity.log
│   ├── community.log
│   ├── ranks.log
│   ├── easter_eggs.log
│   ├── storage.log
│   ├── chat/
│   └── votekick/
└── archive/YYYY-MM-DD/       # créé par la Live Console
```

Chaque fichier reçoit un en-tête map/session et une rotation est déclenchée à la taille maximale configurée. Les messages Chat ordinaires ne sont pas sauvegardés par défaut. Les options XUID/GUID sont appliquées au texte de tous les journaux gérés.

## Live Console en lecture seule

Lancement :

```text
tools\Launch_PinteMod_LiveConsole.bat
```

Fonctions :

- détection automatique de la session et de la map ;
- résumé au démarrage et joueurs connectés déduits du journal ;
- suivi Chat, connexions, Community, votes, kicks, Identity, Ranks, EE, Menu et Storage ;
- mise en évidence des `[FAIL]`, corruptions, erreurs d’écriture, unresolved externals, clientfield mismatch et hitch warnings ;
- mise en évidence des records, candidats, Owner/Admin, UNRANKED et rollback ;
- filtres par catégorie ;
- recherche textuelle ;
- ouverture du dossier de logs ;
- export de la vue dans `tools/exports/` ;
- alerte sonore optionnelle pour les erreurs critiques ;
- archivage par date système des sessions terminées ;
- aucune commande envoyée au serveur.

Appuyer sur `H` pour l’aide clavier.

## Registres communs

`ezz_admin_registry.gsc` centralise :

- codes, noms et alias des maps ;
- collections de maps ;
- présence d’un secret principal et nombre minimum de joueurs EE ;
- rôle minimum des commandes Chat ;
- métadonnées des commandes qui affectent le gameplay.

Les gros modules déjà validés restent intacts dans leur structure générale afin d’éviter une régression majeure dans la v2.0.0. Leur dépendance aux tables dupliquées a toutefois été réduite.

```text
ezzregistrystatus
```

## Tests après installation

Après avoir rejoint une partie :

```text
ezztest
ezzidentity BiereFraiche
ezzidentitytest suite BiereFraiche
ezzstoragestatus
ezzstoragetest suite
ezzregistrystatus
ezzcommunitytest suite BiereFraiche
ezzrevivetest suite BiereFraiche
ezzranktest suite BiereFraiche
ezzeetest suite
ezzeeaudit
```

Résultats attendus :

```text
Identity : 19/19 PASS
Storage : 10/10 PASS
Community : 20/20 PASS
Revive : 10/10 PASS
Ranks : 17/17 PASS
EE : 20/20 PASS
Audit EE : 9/9 passed
```

Ces suites ont été validées sur un serveur dédié BOIII réel. Il reste recommandé de les relancer après installation afin de vérifier l’environnement local.

## Limitations connues

- détecteurs EE natifs non validés sur toutes les maps ;
- noclip volontairement indisponible ;
- aucune commande AFK ;
- aucun verrou de transition de manche ;
- profils spécifiques requis pour les custom maps ;
- pas de renommage atomique disponible côté GSC ;
- Live Console facultative et dépendante de Windows PowerShell.

## Contenu du paquet

```text
custom_scripts/             runtime PinteMod
tools/                      Live Console en lecture seule
docs/                       installation, commandes, vérification, EE et documentation développeur
README.md                   documentation anglaise
README_FR.md                documentation française complète
SECURITY.md                 politique de sécurité
THIRD_PARTY_NOTICES.md      composants et droits tiers
CHANGELOG_v2.0.0.txt        changelog de la version
LICENSE                     GNU GPL version 3
SHA256SUMS.txt              empreintes des fichiers
```

Le dossier `docs/` contient :

- `INSTALLATION_FR.txt` ;
- `COMMANDES_CONSOLE_FR.txt` ;
- `VERIFICATION_APRES_INSTALLATION_FR.txt` ;
- `VALIDATION_EE_FR.txt` ;
- `ARCHITECTURE.md` ;
- `AUDIT_VALIDATION_v2.0.0.txt` ;
- `FORUM_POST_FR.md`.

## Licence

Copyright © 2026 BiereFraiche.

PinteMod est distribué sous **GNU General Public License version 3**. Voir `LICENSE` et `THIRD_PARTY_NOTICES.md`.

La licence couvre uniquement le code propre à PinteMod. Elle ne donne aucun droit sur Call of Duty: Black Ops III, BOIII/Ezz ou d’autres composants propriétaires.

### Confidentialité des journaux Chat

Les messages Chat normaux ne sont pas écrits sur disque par défaut. Activez volontairement `level.pintemod_log_chat_messages = true;` dans `ezz_admin_config.gsc` uniquement si vous souhaitez alimenter le filtre Chat de la Live Console et inclure les messages dans les rapports de votekick. Les commandes, votes, connexions, erreurs et actions administratives restent journalisés. Les XUID sont journalisés par défaut ; les GUID ne le sont pas.
