# Security policy

## Supported version

Security fixes are provided for the latest published PinteMod release.

## Reporting a vulnerability

Do not publish an exploitable command-injection, permission-bypass, identity, file-corruption or remote-administration issue in a public forum before a fix is available.

Open a private GitHub security advisory for `BiereFraiche/PinteMod`, or contact the maintainer through the private contact method listed on the project profile. Include:

- affected PinteMod version;
- map and BOIII server build;
- exact reproduction steps;
- relevant console and `boiii/scriptdata/pintemod/logs/` extracts;
- whether the issue requires Owner/Admin permissions;
- whether the issue can corrupt records or execute a server command.

Remove unrelated player names and XUIDs from shared logs whenever possible.

## Security model

- Roles and persistent player data use BOIII_XUID.
- Internal Chat/menu targeting uses XUID or numeric client slot.
- Display names are metadata and may only be used as an unambiguous fallback.
- The Live Console is read-only.
- EE official writes remain disabled per map until the native detector is validated.
- Normal player Chat logging is disabled by default.
