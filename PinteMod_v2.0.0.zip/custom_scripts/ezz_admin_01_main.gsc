// ============================================================
// PinteMod Core v2.0.0
// Fichier : ezz_admin_01_main.gsc
// Créé par BiereFraiche et ChatGPT
//
// Point d'entrée autonome du framework dédié Zombies.
// ============================================================

autoexec function init()
{
    level.ezz_admin_loaded = true;
    level.ezz_admin_release = "2.0.0";

    println("^5[PinteMod]^7 Core v2.0.0 loaded");
    say("^3[PinteMod]^7 ^2v2.0 chargée^7");
}
