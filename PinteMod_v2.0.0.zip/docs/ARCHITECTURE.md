# PinteMod v2.0.0 architecture

## Runtime layout

PinteMod is loaded from flat GSC modules in `boiii/custom_scripts/`.

### Bootstrap

- `ezz_admin_00_banner.gsc`: startup banner
- `ezz_admin_01_main.gsc`: core bootstrap
- `ezz_admin_config.gsc`: public configuration and default Owner

### Shared infrastructure

- `ezz_admin_identity.gsc`: BOIII_XUID roles, target resolution and selector safety
- `ezz_admin_registry.gsc`: common map registry and shared Chat command metadata
- `ezz_admin_storage.gsc`: managed logs and recoverable JSON persistence

### User interfaces

- `ezz_admin_chat.gsc`: Chat parser and permission routing
- `ezz_admin_menu.gsc`: public/staff HUD menu
- `tools/PinteMod_LiveConsole.ps1`: optional read-only log viewer

### Community and records

- `ezz_admin_community.gsc`: presence, late join, voting and vote-kick
- `ezz_admin_ranks.gsc`: activity, ranked matches and round records
- `ezz_admin_ee_records.gsc`: EE profiles, candidates, diagnostics and records

### Gameplay modules

- `ezz_admin_commands.gsc`
- `ezz_admin_maps.gsc`
- `ezz_admin_events.gsc`
- `ezz_admin_music.gsc`
- `ezz_admin_navigation.gsc`
- `ezz_admin_perks.gsc`
- `ezz_admin_powerups.gsc`
- `ezz_admin_rounds.gsc`
- `ezz_admin_weapons.gsc`
- `ezz_admin_zombies.gsc`

## Identity flow

1. A connected entity exposes `getXuid(false)`.
2. PinteMod normalizes and validates the XUID.
3. Role lookup checks persistent runtime roles and configured XUID lists.
4. Chat/menu code converts the target entity to a stable selector.
5. Console callbacks resolve selectors in this order:
   - exact XUID;
   - numeric client slot (`0`, `#0`, `client:0`);
   - exact and unique display name.
6. Duplicate display names are rejected.

The display name is never an authority for permission or persistence.

## Storage flow

Protected JSON writes use:

```text
new JSON
  └─> path.tmp (write + readback + validation)
        └─> path.bak (previous valid active copy)
              └─> path (write + readback + validation)
                    ├─ success: remove .tmp
                    └─ failure: quarantine invalid active + restore previous
```

Invalid files found while loading are copied to `pintemod/backups/corrupt/` before fallback or restoration.

## Logging flow

All modules call `ezz_admin_storage::append_managed_log()` or `write_managed_log()`.

Logical paths such as `pintemod/logs/ranks.log` are redirected to:

```text
pintemod/logs/sessions/<map>_s<counter>_<GetTime>/ranks.log
```

The storage module applies:

- map/session header;
- configurable XUID and GUID redaction;
- per-file size rotation;
- common session manifest.

The optional Live Console watches that manifest and archives completed sessions by operating-system date.

## Shared registry

Map identity, display names, aliases, map collections, main-quest presence and minimum EE player counts are defined in `ezz_admin_registry.gsc`.

The same module contains Chat aliases, console routes, roles, map availability and gameplay-impact metadata. The v2.0.0 menu remains explicit rather than generated dynamically, because replacing its validated structure with a data-driven menu immediately before release would create unnecessary regression risk.

## Large modules

Community, Ranks, Menu and EE remain large modules in v2.0.0. Their internal interfaces and persistence have been hardened, but a physical split into many files is intentionally deferred until automated compile/runtime regression coverage exists.

A future non-breaking split can use:

```text
ezz_ee_profiles.gsc
ezz_ee_candidates.gsc
ezz_ee_storage.gsc
ezz_ee_tests.gsc

ezz_community_votes.gsc
ezz_community_presence.gsc
ezz_community_latejoin.gsc
ezz_community_votekick.gsc
```

This is a maintenance refactor, not a requirement for the v2.0.0 feature set.
