# [RELEASE] PinteMod v2.0.0

Bonjour à tous,

Je publie **PinteMod v2.0.0**, un framework GSC côté serveur pour les serveurs dédiés **BOIII Zombies**.

Cette version fournit une base d’administration, de communauté et de records pour les 14 maps Zombies officielles de Black Ops III. Aucun mod client n’est nécessaire.

## Principales fonctionnalités

- permissions persistantes par **BOIII_XUID** ;
- ciblage interne Chat/menu par XUID ou numéro client ;
- refus des pseudos en double et des chaînes de commande dangereuses ;
- rôles Owner, Admin, Moderator, Helper et User ;
- commandes console, commandes Chat et menu HUD ;
- points, munitions, God Mode, armes, atouts et Pack-a-Punch ;
- sauvegarde de position et téléportation ;
- gestion des manches, courant, passages et bonus ;
- votes de prochaine map, redémarrage et votekick liés au XUID ;
- late join et présence persistante pendant la map ;
- revive natif réservé à l’Owner depuis le Chat/menu ;
- Ranks & Records liés au XUID sur une base v2 neuve ;
- Easter Egg Records liés au XUID avec activation officielle map par map ;
- écritures JSON vérifiées, backups `.bak` et quarantaine des fichiers corrompus ;
- journaux par session avec rotation et paramètres de confidentialité ;
- Live Console PowerShell en lecture seule avec filtres, recherche, export et alertes ;
- boss, événements et musiques sur les maps compatibles ;
- **123 commandes console uniques**.

## Maps prises en charge

Shadows of Evil, The Giant, Der Eisendrache, Zetsubou No Shima, Gorod Krovi, Revelations, Nacht der Untoten, Verrückt, Shi No Numa, Kino der Toten, Ascension, Shangri-La, Moon et Origins.

## Identité et sécurité

Les permissions et données persistantes utilisent `player getXuid(false)` sous forme de **BOIII_XUID** hexadécimal.

Les commandes acceptent :

```text
<PlayerName|BOIII_XUID|ClientNumber>
```

Le pseudo est uniquement un fallback d’affichage et de ciblage lorsqu’il est unique. Deux pseudos identiques provoquent un refus. Les actions Chat/menu transmettent le XUID ou le slot client, et `clientkick` reçoit le numéro client courant.

## Records et données

La distribution ne contient aucun profil, record, log, vote, sanction, backup ou dossier `scriptdata` provenant du serveur de développement.

Les bases locales sont créées dans :

```text
pintemod/ranks_v2
pintemod/easter_eggs_v2
```

Les anciens records par pseudo ne sont ni migrés ni fusionnés automatiquement.

## Easter Egg Records

Le cœur EE est livré en mode sécurisé. Les structures, candidats, règles de présence et Top 5 sont disponibles, mais chaque détecteur natif doit être confirmé en terminant réellement le secret de la map concernée.

Une map non validée reste en mode `DIAGNOSTIC` avec les écritures officielles désactivées.

## Validation attendue

```text
Identity & ciblage      : 19/19
Safe Storage            : 10/10
Community / XUID        : 20/20
Revive                  : 10/10
Ranks & Records         : 17/17
EE Records              : 20/20
Audit EE officiel       : 9/9
```

## Installation

1. Arrêter complètement le serveur.
2. Sauvegarder les dossiers existants.
3. Supprimer les anciens scripts PinteMod.
4. Copier `custom_scripts/` dans `boiii/`.
5. Copier `tools/` à côté de `boiii/` pour la Live Console.
6. Modifier le XUID Owner dans `ezz_admin_config.gsc`.
7. Redémarrer puis suivre `docs/VERIFICATION_APRES_INSTALLATION_FR.txt`.

`hotfix.gsc` n’est pas inclus : il appartient à l’environnement BOIII.

## Owner par défaut

```text
BiereFraiche
BOIII_XUID : 9cf34426f668fb8b
```

Les autres propriétaires doivent remplacer ou supprimer cette entrée avant d’ouvrir leur serveur au public.

## Téléchargement

**Dernière release GitHub :** https://github.com/BiereFraiche/PinteMod/releases/latest

**Archive :** `PinteMod_v2.0.0.zip`

Vérifiez la somme SHA-256 publiée dans la release avant installation.

## Licence

PinteMod est distribué sous **GNU General Public License version 3**. Le paquet inclut `LICENSE` et `THIRD_PARTY_NOTICES.md`.

## Remarques

- `ezzspawn` réintègre un spectateur ; `ezzrevive` relève un joueur en last stand.
- Aucun système AFK, noclip ou verrou de transition des manches n’est inclus.
- La Live Console est strictement en lecture seule.
- Les logs de Chat ordinaires sont désactivés par défaut.
- Le dépôt ne contient aucune donnée privée du serveur de développement.

Merci aux testeurs de joindre la map, la version BOIII et les logs complets lors d’un signalement.

**Créé par BiereFraiche avec l’aide de ChatGPT.**
