﻿param(
    [string]$ServerRoot = "",
    [int]$InitialLines = 12,
    [switch]$EnableCriticalSound
)

$ErrorActionPreference = "Stop"
$Host.UI.RawUI.WindowTitle = "PinteMod v2.0.0 - Live Console"

function Resolve-ServerRoot {
    param([string]$RequestedRoot)

    if (-not [string]::IsNullOrWhiteSpace($RequestedRoot)) {
        $resolved = [System.IO.Path]::GetFullPath($RequestedRoot.Trim('"'))
        if (Test-Path -LiteralPath (Join-Path $resolved "boiii")) { return $resolved }
        throw "The supplied server root does not contain a boiii folder: $resolved"
    }

    $candidates = @(
        (Split-Path -Parent $PSScriptRoot),
        (Get-Location).Path,
        $PSScriptRoot
    ) | Select-Object -Unique

    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath (Join-Path $candidate "boiii")) {
            return [System.IO.Path]::GetFullPath($candidate)
        }
    }

    Write-Host "PinteMod could not automatically locate the server root." -ForegroundColor Yellow
    $entered = Read-Host "Folder that directly contains boiii"
    if ([string]::IsNullOrWhiteSpace($entered)) { throw "No server root supplied." }

    $resolved = [System.IO.Path]::GetFullPath($entered.Trim('"'))
    if (-not (Test-Path -LiteralPath (Join-Path $resolved "boiii"))) {
        throw "The selected folder does not contain boiii: $resolved"
    }
    return $resolved
}

function Ensure-Directory {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Read-SessionManifest {
    param([string]$Root)

    $manifestPath = Join-Path $Root "current_session.json"
    if (Test-Path -LiteralPath $manifestPath) {
        try {
            $raw = Get-Content -LiteralPath $manifestPath -Raw -ErrorAction Stop
            $manifest = $raw | ConvertFrom-Json -ErrorAction Stop
            if ($manifest.session_id) { return $manifest }
        }
        catch {
            Write-Host "[WARN] Invalid current_session.json: $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }

    $sessionsRoot = Join-Path $Root "sessions"
    if (Test-Path -LiteralPath $sessionsRoot) {
        $latest = Get-ChildItem -LiteralPath $sessionsRoot -Directory -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending | Select-Object -First 1
        if ($latest) {
            return [PSCustomObject]@{
                session_id = $latest.Name
                map = ($latest.Name -replace '_s\d+_\d+$', '')
                started_gettime = "unknown"
                fallback = $true
            }
        }
    }

    return [PSCustomObject]@{
        session_id = "waiting_for_server"
        map = "unknown"
        started_gettime = "unknown"
        fallback = $true
    }
}

function Get-SessionRoot {
    param($Manifest, [string]$Root)
    return Join-Path (Join-Path $Root "sessions") ([string]$Manifest.session_id)
}

function Get-SourceDefinitions {
    param([string]$SessionRoot)

    $sources = @(
        [PSCustomObject]@{ Tag="JOIN";      Category="JOIN";      Path=(Join-Path $SessionRoot "connections.log");         Color="Cyan" },
        [PSCustomObject]@{ Tag="CHAT";      Category="CHAT";      Path=(Join-Path $SessionRoot "chat\session.log");       Color="White" },
        [PSCustomObject]@{ Tag="COMMAND";   Category="CHAT";      Path=(Join-Path $SessionRoot "chat\commands.log");      Color="DarkGray" },
        [PSCustomObject]@{ Tag="COMMUNITY"; Category="COMMUNITY"; Path=(Join-Path $SessionRoot "community.log");           Color="Green" },
        [PSCustomObject]@{ Tag="VOTE";      Category="VOTE";      Path=(Join-Path $SessionRoot "vote_summary.log");        Color="Yellow" },
        [PSCustomObject]@{ Tag="KICK";      Category="KICK";      Path=(Join-Path $SessionRoot "votekick_summary.log");    Color="Magenta" },
        [PSCustomObject]@{ Tag="IDENTITY";  Category="IDENTITY";  Path=(Join-Path $SessionRoot "identity.log");            Color="DarkCyan" },
        [PSCustomObject]@{ Tag="RANKS";     Category="RANKS";     Path=(Join-Path $SessionRoot "ranks.log");               Color="Blue" },
        [PSCustomObject]@{ Tag="EE";        Category="EE";        Path=(Join-Path $SessionRoot "easter_eggs.log");         Color="DarkYellow" },
        [PSCustomObject]@{ Tag="MENU";      Category="MENU";      Path=(Join-Path $SessionRoot "menu.log");                Color="DarkGreen" },
        [PSCustomObject]@{ Tag="STORAGE";   Category="STORAGE";   Path=(Join-Path $SessionRoot "storage.log");             Color="DarkMagenta" }
    )

    $consoleCandidates = @(
        (Join-Path $script:ServerRoot "boiii\console.log"),
        (Join-Path $script:ServerRoot "boiii\boiii.log"),
        (Join-Path $script:ServerRoot "boiii\logs\console.log"),
        (Join-Path $script:ServerRoot "main\console_mp.log")
    ) | Select-Object -Unique

    foreach ($candidate in $consoleCandidates) {
        if (Test-Path -LiteralPath $candidate) {
            $sources += [PSCustomObject]@{ Tag="SERVER"; Category="ERROR"; Path=$candidate; Color="Gray" }
        }
    }

    return $sources
}

function Test-CriticalLine {
    param([string]$Text)
    return $Text -match '(?i)(\[FAIL\]|WRITE_FAILED|VERIFY_FAILED|CORRUPT|unresolved external|script error|fatal|exception|hitch warning|clientfield mismatch)'
}

function Get-LineColor {
    param([string]$DefaultColor, [string]$Text)
    if (Test-CriticalLine $Text) { return "Red" }
    if ($Text -match '(?i)(\[PASS\]|RECORD_|CANDIDATE_STORED|role=owner|role=admin)') { return "Green" }
    if ($Text -match '(?i)(UNRANKED|ROLLBACK|REJECTED|BLOCKED|warning)') { return "Yellow" }
    return $DefaultColor
}

function Test-LineVisible {
    param([string]$Category, [string]$Text)

    if ($script:ActiveFilter -eq "ERROR") { return (Test-CriticalLine $Text) }
    if ($script:ActiveFilter -ne "ALL" -and $Category -ne $script:ActiveFilter) { return $false }
    if (-not [string]::IsNullOrWhiteSpace($script:SearchText)) {
        return $Text.IndexOf($script:SearchText, [System.StringComparison]::OrdinalIgnoreCase) -ge 0
    }
    return $true
}

function Write-TaggedLine {
    param([string]$Tag, [string]$Category, [string]$Text, [string]$Color)

    if (-not (Test-LineVisible -Category $Category -Text $Text)) { return }

    $timestamp = Get-Date -Format "HH:mm:ss"
    $displayColor = Get-LineColor -DefaultColor $Color -Text $Text
    Write-Host "[$timestamp][$Tag] " -NoNewline -ForegroundColor $displayColor
    Write-Host $Text -ForegroundColor $displayColor

    $script:VisibleBuffer.Add("[$timestamp][$Tag] $Text") | Out-Null
    if ($script:VisibleBuffer.Count -gt 20000) { $script:VisibleBuffer.RemoveAt(0) }

    if ($script:CriticalSound -and (Test-CriticalLine $Text)) {
        try { [console]::Beep(900, 180) } catch { }
    }
}

function Show-Help {
    Write-Host ""
    Write-Host "Filters: [A]ll [C]hat [J]oin [U]Community [V]ote [K]ick" -ForegroundColor Cyan
    Write-Host "         [R]anks [E]E [X]Errors [M]enu [I]dentity [S]torage" -ForegroundColor Cyan
    Write-Host "Actions: [F]ind text [O]pen logs [P]export view [B]critical sound [H]elp [Q]uit" -ForegroundColor Gray
    Write-Host "The Live Console is read-only and never sends server commands." -ForegroundColor DarkGray
    Write-Host ""
}

function Show-StartupSummary {
    param($Manifest, [string]$SessionRoot, $Sources)

    Clear-Host
    Write-Host "============================================================" -ForegroundColor DarkCyan
    Write-Host " PinteMod v2.0.0 - Live Console" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor DarkCyan
    Write-Host " Server root : $script:ServerRoot" -ForegroundColor Gray
    Write-Host " Map         : $($Manifest.map)" -ForegroundColor Gray
    Write-Host " Session     : $($Manifest.session_id)" -ForegroundColor Gray
    Write-Host " Log folder  : $SessionRoot" -ForegroundColor Gray

    $available = @($Sources | Where-Object { Test-Path -LiteralPath $_.Path }).Count
    Write-Host " Sources     : $available/$($Sources.Count) currently created" -ForegroundColor Gray

    $identityRoles = @{}
    $identitySource = $Sources | Where-Object { $_.Tag -eq "IDENTITY" } | Select-Object -First 1
    if ($identitySource -and (Test-Path -LiteralPath $identitySource.Path)) {
        foreach ($line in (Get-Content -LiteralPath $identitySource.Path -Tail 300 -ErrorAction SilentlyContinue)) {
            if ($line -match 'IDENTITY_ATTACHED.*?xuid=([^|]+).*?role=([^|]+)') {
                $identityRoles[$matches[1].Trim()] = $matches[2].Trim()
            }
        }
    }

    $connections = $Sources | Where-Object { $_.Tag -eq "JOIN" } | Select-Object -First 1
    if ($connections -and (Test-Path -LiteralPath $connections.Path)) {
        $recent = Get-Content -LiteralPath $connections.Path -Tail 200 -ErrorAction SilentlyContinue
        $state = @{}
        foreach ($line in $recent) {
            if ($line -match '\[(JOIN|LEAVE)\]\s+(.+?)\s+\|\s+xuid=([^|]+)\|\s+client=([0-9-]+)') {
                $state[$matches[4]] = [PSCustomObject]@{ Event=$matches[1]; Name=$matches[2].Trim(); Xuid=$matches[3].Trim(); Client=$matches[4] }
            }
        }
        $connected = @($state.Values | Where-Object { $_.Event -eq "JOIN" })
        Write-Host " Players     : $($connected.Count) inferred from session log" -ForegroundColor Gray
        foreach ($entry in $connected) {
            $role = "unknown"
            if ($identityRoles.ContainsKey($entry.Xuid)) { $role = $identityRoles[$entry.Xuid] }
            Write-Host "   #$($entry.Client) $($entry.Name) | XUID=$($entry.Xuid) | role=$role" -ForegroundColor DarkCyan
        }
    }

    $detectedModules = New-Object 'System.Collections.Generic.HashSet[string]'
    foreach ($source in $Sources) {
        if (-not (Test-Path -LiteralPath $source.Path)) { continue }
        foreach ($line in (Get-Content -LiteralPath $source.Path -Tail 80 -ErrorAction SilentlyContinue)) {
            if ($line -match '(?i)(MODULE_LOADED|\bloaded\b)') { [void]$detectedModules.Add($source.Tag) }
        }
    }
    if ($detectedModules.Count -gt 0) {
        $moduleList = @($detectedModules | Sort-Object) -join ', '
        Write-Host " Modules/logs: $moduleList" -ForegroundColor Gray
    }

    Show-Help
}

function Archive-Session {
    param([string]$SessionRoot, [string]$SessionId)
    if (-not (Test-Path -LiteralPath $SessionRoot) -or $SessionId -eq "waiting_for_server") { return }

    try { $day = (Get-Item -LiteralPath $SessionRoot -ErrorAction Stop).LastWriteTime.ToString("yyyy-MM-dd") }
    catch { $day = Get-Date -Format "yyyy-MM-dd" }
    $archiveRoot = Join-Path (Join-Path $script:LogRoot "archive") $day
    Ensure-Directory $archiveRoot
    $destination = Join-Path $archiveRoot $SessionId
    if (-not (Test-Path -LiteralPath $destination)) {
        try { Copy-Item -LiteralPath $SessionRoot -Destination $destination -Recurse -Force -ErrorAction Stop }
        catch { Write-Host "[WARN] Session archive failed: $($_.Exception.Message)" -ForegroundColor Yellow }
    }
}

function Archive-CompletedSessions {
    param([string]$CurrentSessionId)

    $sessionsRoot = Join-Path $script:LogRoot "sessions"
    if (-not (Test-Path -LiteralPath $sessionsRoot)) { return }

    foreach ($directory in (Get-ChildItem -LiteralPath $sessionsRoot -Directory -ErrorAction SilentlyContinue)) {
        if ($directory.Name -eq $CurrentSessionId) { continue }
        if ($directory.Name -like "bootstrap_*") { continue }
        Archive-Session -SessionRoot $directory.FullName -SessionId $directory.Name
    }
}

function Export-VisibleView {
    $exports = Join-Path $PSScriptRoot "exports"
    Ensure-Directory $exports
    $path = Join-Path $exports ("PinteMod_LiveConsole_{0}.txt" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
    $header = @(
        "PinteMod v2.0.0 Live Console export",
        "Created: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')",
        "Server: $script:ServerRoot",
        "Session: $($script:Manifest.session_id)",
        "Map: $($script:Manifest.map)",
        "Filter: $script:ActiveFilter",
        "Search: $script:SearchText",
        ""
    )
    Set-Content -LiteralPath $path -Value ($header + $script:VisibleBuffer) -Encoding UTF8
    Write-Host "Exported: $path" -ForegroundColor Green
}

function Reset-SourceStates {
    param($Sources, [switch]$TailExisting)

    $script:FileStates = @{}

    foreach ($source in $Sources) {
        $position = [int64]0

        if (Test-Path -LiteralPath $source.Path) {
            if ($TailExisting) {
                foreach ($line in (Get-Content -LiteralPath $source.Path -Tail $InitialLines -ErrorAction SilentlyContinue)) {
                    Write-TaggedLine -Tag $source.Tag -Category $source.Category -Text ([string]$line) -Color $source.Color
                }
            }

            try { $position = [int64](Get-Item -LiteralPath $source.Path -ErrorAction Stop).Length }
            catch { $position = [int64]0 }
        }

        $script:FileStates[$source.Path] = [PSCustomObject]@{
            Position = $position
            Remainder = ""
        }
    }
}

function Read-NewSourceLines {
    param($Source)

    if (-not (Test-Path -LiteralPath $Source.Path)) { return }

    if (-not $script:FileStates.ContainsKey($Source.Path)) {
        $script:FileStates[$Source.Path] = [PSCustomObject]@{
            Position = [int64]0
            Remainder = ""
        }
    }

    $state = $script:FileStates[$Source.Path]

    try { $length = [int64](Get-Item -LiteralPath $Source.Path -ErrorAction Stop).Length }
    catch { return }

    # Rotation or rewrite truncated the active file.
    if ($length -lt [int64]$state.Position) {
        $state.Position = [int64]0
        $state.Remainder = ""
    }

    if ($length -eq [int64]$state.Position) { return }

    $stream = $null
    $reader = $null

    try {
        $stream = [System.IO.File]::Open(
            $Source.Path,
            [System.IO.FileMode]::Open,
            [System.IO.FileAccess]::Read,
            [System.IO.FileShare]::ReadWrite
        )
        [void]$stream.Seek([int64]$state.Position, [System.IO.SeekOrigin]::Begin)
        $encoding = [System.Text.UTF8Encoding]::new($false)
        $reader = [System.IO.StreamReader]::new(
            $stream,
            $encoding,
            $true,
            4096,
            $true
        )
        $chunk = $reader.ReadToEnd()
        $state.Position = [int64]$stream.Length
    }
    catch {
        Write-Host "[WARN] Cannot read $($Source.Path): $($_.Exception.Message)" -ForegroundColor Yellow
        return
    }
    finally {
        if ($reader) { $reader.Dispose() }
        if ($stream) { $stream.Dispose() }
    }

    if ([string]::IsNullOrEmpty($chunk)) { return }

    $combined = [string]$state.Remainder + $chunk
    $parts = [System.Text.RegularExpressions.Regex]::Split($combined, "`r?`n")
    $hasTrailingNewline = $combined.EndsWith("`n") -or $combined.EndsWith("`r")

    if ($hasTrailingNewline) {
        $state.Remainder = ""
        $completeCount = $parts.Count
    }
    else {
        $state.Remainder = [string]$parts[$parts.Count - 1]
        $completeCount = $parts.Count - 1
    }

    for ($index = 0; $index -lt $completeCount; $index++) {
        $line = [string]$parts[$index]
        if ($line.Length -eq 0) { continue }
        Write-TaggedLine -Tag $Source.Tag -Category $Source.Category -Text $line -Color $Source.Color
    }
}

function Process-Key {
    param([System.ConsoleKeyInfo]$Key)
    switch ($Key.Key) {
        "A" { $script:ActiveFilter = "ALL" }
        "C" { $script:ActiveFilter = "CHAT" }
        "J" { $script:ActiveFilter = "JOIN" }
        "U" { $script:ActiveFilter = "COMMUNITY" }
        "V" { $script:ActiveFilter = "VOTE" }
        "K" { $script:ActiveFilter = "KICK" }
        "R" { $script:ActiveFilter = "RANKS" }
        "E" { $script:ActiveFilter = "EE" }
        "X" { $script:ActiveFilter = "ERROR" }
        "M" { $script:ActiveFilter = "MENU" }
        "I" { $script:ActiveFilter = "IDENTITY" }
        "S" { $script:ActiveFilter = "STORAGE" }
        "F" {
            Write-Host ""
            $script:SearchText = Read-Host "Search text (empty clears)"
        }
        "O" { Start-Process explorer.exe -ArgumentList ('"{0}"' -f $script:SessionRoot) }
        "P" { Export-VisibleView }
        "B" {
            $script:CriticalSound = -not $script:CriticalSound
            Write-Host "Critical sound: $script:CriticalSound" -ForegroundColor Yellow
        }
        "H" { Show-Help }
        "Q" { $script:Quit = $true; return }
        default { return }
    }
    if ($Key.Key -in @("A","C","J","U","V","K","R","E","X","M","I","S")) {
        Write-Host "Filter: $script:ActiveFilter | Search: $script:SearchText" -ForegroundColor DarkGray
    }
}

$script:ServerRoot = Resolve-ServerRoot -RequestedRoot $ServerRoot
$script:LogRoot = Join-Path $script:ServerRoot "boiii\scriptdata\pintemod\logs"
Ensure-Directory $script:LogRoot
Ensure-Directory (Join-Path $script:LogRoot "sessions")

$script:ActiveFilter = "ALL"
$script:SearchText = ""
$script:CriticalSound = [bool]$EnableCriticalSound
$script:VisibleBuffer = New-Object 'System.Collections.Generic.List[string]'
$script:Quit = $false
$script:Manifest = Read-SessionManifest -Root $script:LogRoot
$script:SessionRoot = Get-SessionRoot -Manifest $script:Manifest -Root $script:LogRoot
$script:Sources = Get-SourceDefinitions -SessionRoot $script:SessionRoot
$script:FileStates = @{}
Archive-CompletedSessions -CurrentSessionId ([string]$script:Manifest.session_id)

Show-StartupSummary -Manifest $script:Manifest -SessionRoot $script:SessionRoot -Sources $script:Sources
Reset-SourceStates -Sources $script:Sources -TailExisting
Write-Host "----- LIVE OUTPUT -----" -ForegroundColor DarkGray

$lastManifestCheck = Get-Date

try {
    while (-not $script:Quit) {
        while ([console]::KeyAvailable) {
            Process-Key -Key ([console]::ReadKey($true))
        }

        if (((Get-Date) - $lastManifestCheck).TotalSeconds -ge 1) {
            $lastManifestCheck = Get-Date
            $newManifest = Read-SessionManifest -Root $script:LogRoot
            if ([string]$newManifest.session_id -ne [string]$script:Manifest.session_id) {
                Archive-Session -SessionRoot $script:SessionRoot -SessionId ([string]$script:Manifest.session_id)
                $script:Manifest = $newManifest
                $script:SessionRoot = Get-SessionRoot -Manifest $script:Manifest -Root $script:LogRoot
                $script:Sources = Get-SourceDefinitions -SessionRoot $script:SessionRoot
                Write-Host "New PinteMod session detected: $($script:Manifest.session_id) | map=$($script:Manifest.map)" -ForegroundColor Cyan
                Reset-SourceStates -Sources $script:Sources
            }
        }

        foreach ($source in $script:Sources) {
            Read-NewSourceLines -Source $source
        }

        Start-Sleep -Milliseconds 250
    }
}
finally {
    Archive-Session -SessionRoot $script:SessionRoot -SessionId ([string]$script:Manifest.session_id)
    Write-Host "PinteMod Live Console stopped." -ForegroundColor DarkGray
}
