# [RELEASE] PinteMod v2.0.0 FINAL — BOIII Zombies Dedicated Server Framework

Bonjour à tous,

Je publie aujourd’hui **PinteMod v2.0.0 FINAL**, un framework GSC complet destiné aux serveurs dédiés **BOIII Zombies**.

L’objectif de cette version est de proposer une base serveur stable, propre et facilement configurable, avec des outils d’administration, des fonctions communautaires et des systèmes de records utilisables sur les 14 maps Zombies officielles de Black Ops III.

## Principales fonctionnalités

- Permissions persistantes par **BOIII_XUID**, sans authentification par pseudo.
- Rôles Owner, Admin, Moderator, Helper et User.
- Commandes console et commandes Chat.
- Menu HUD filtré selon le rôle et la map.
- Gestion des points, munitions, God Mode, armes, atouts et Pack-a-Punch.
- Sauvegarde de position et téléportation.
- Contrôle des manches, du courant, des portes et du Pack-a-Punch.
- Power-ups permanents créés par PinteMod.
- Votes de prochaine map, restart et votekick liés au XUID.
- Late join avec état conservé après reconnexion.
- Réanimation administrative avec conservation de l’équipement et des atouts, réservée au rôle Owner.
- Ranks & Records liés au XUID avec une base v2 neuve.
- Easter Egg Records liés au XUID avec activation officielle sécurisée map par map.
- Boss et événements spéciaux sur les maps compatibles.
- Musiques secrètes/spéciales sur les maps prises en charge.
- **122 commandes console uniques**.

## Maps prises en charge

PinteMod contient des profils pour les 14 maps officielles :

Shadows of Evil, The Giant, Der Eisendrache, Zetsubou No Shima, Gorod Krovi, Revelations, Nacht der Untoten, Verrückt, Shi No Numa, Kino der Toten, Ascension, Shangri-La, Moon et Origins.

## Identité et sécurité

La v2 utilise `player getXuid(false)` sous la forme d’un identifiant hexadécimal stable nommé **BOIII_XUID**.

Les permissions fonctionnent en mode fail-closed : si l’identité n’est pas disponible, aucun privilège n’est accordé. Le pseudo n’est jamais utilisé comme solution de secours pour l’autorisation.

Le BOIII_XUID est un identifiant BOIII opaque et ne doit pas être présenté comme un SteamID64.

## Records et données

La distribution est neutre : elle ne contient aucun profil joueur, record, log, vote, sanction ou fichier `scriptdata` provenant du serveur de développement.

Les bases suivantes sont créées localement :

```text
pintemod/ranks_v2
pintemod/easter_eggs_v2
```

Les anciens records par pseudo ne sont ni migrés ni fusionnés automatiquement. Tous les serveurs démarrent donc avec une base v2 propre.

Les commandes d’administration qui modifient le gameplay rendent la partie actuelle non classée afin de protéger les records.

## Easter Egg Records

Le système EE est livré en mode sécurisé. Les structures, candidats, règles de présence et Top 5 ont été validés, mais chaque détecteur natif doit être confirmé en réussissant réellement le secret de la map concernée.

Tant qu’une map n’a pas été validée, ses records officiels restent désactivés. Cela permet d’utiliser PinteMod sans risquer d’enregistrer un faux record.

## Validation serveur

Les suites groupées suivantes ont été validées sur serveur réel :

```text
Identity & Permissions : 14/14
Community / XUID       : 20/20
Revive                 : 10/10
Ranks & Records        : 17/17
EE Records             : 20/20
Audit EE officiel      : 9/9
```

## Installation

1. Arrêtez complètement le serveur BOIII.
2. Copiez le dossier `custom_scripts/` dans le dossier `boiii/` du serveur.
3. Ne mélangez pas les fichiers v2.0 FINAL avec d’anciennes versions ou des hotfixs de développement.
4. Modifiez le propriétaire par défaut dans `custom_scripts/ezz_admin_config.gsc`.
5. Redémarrez le serveur et consultez les lignes de chargement PinteMod.

Le ZIP contient un guide d’installation, la liste complète des 122 commandes, le changelog, la procédure de validation EE et les sommes SHA-256.

## Propriétaire par défaut

La distribution conserve volontairement le créateur comme Owner par défaut :

```text
BiereFraiche
BOIII_XUID : 9cf34426f668fb8b
```

Les propriétaires d’autres serveurs doivent remplacer ou supprimer cette entrée avant d’ouvrir leur serveur au public. La procédure exacte est expliquée dans le README et dans `INSTALLATION_FR.txt`.

## Téléchargement

**GitHub / Release v2.0.0 :** [AJOUTER_ICI_LE_LIEN_DE_LA_RELEASE]

**Archive :** `PinteMod_v2.0_FINAL.zip`

Vérifiez la somme SHA-256 publiée dans la release avant installation.

## Remarques

- `ezzspawn` sert à réintégrer un spectateur ; `ezzrevive` relève un joueur réellement à terre.
- Le revive Chat/Menu est réservé au rôle Owner.
- Les anciennes commandes console ciblant un joueur peuvent nécessiter la casse exacte du pseudo.
- Aucun système AFK, noclip ou verrou de transition des manches n’est inclus.
- Le dépôt contient uniquement le framework et sa documentation, sans données privées de serveur.

Merci à toutes les personnes qui testeront PinteMod et remonteront les éventuels problèmes avec les logs complets et la map concernée.

**Créé par BiereFraiche avec l’aide de ChatGPT.**
