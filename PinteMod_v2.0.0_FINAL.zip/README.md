# PinteMod v2.0.0 FINAL

PinteMod is a complete server-side GSC administration and community framework for dedicated **Call of Duty: Black Ops III Zombies** servers running through **BOIII/Ezz**.

Created by **BiereFraiche** with development assistance from **ChatGPT**.

No compiled mod and no client-side download are required. Players connect normally; PinteMod runs from the server's `boiii/custom_scripts/` directory.

## Main features

- Stable player identity through `player getXuid(false)` (`BOIII_XUID`).
- Fail-closed permissions with no display-name authorization fallback.
- Persistent Owner, Admin, Moderator, Helper and User roles.
- Console and Chat command routing with XUID-aware logs.
- Complete HUD administration menu filtered by role and map.
- Public Player Menu opened with `.menu`.
- Primary Chat prefix `.` with legacy `!` compatibility.
- Welcome HUD and public late-join instructions.
- Safe public late join through `.spawn` or the Player Menu.
- Owner-only administrative revive through `.revive [player]`.
- Administrative spectator respawn through `.respawn [player]`.
- Points, ammunition, God Mode and zombie-ignore controls.
- Weapon management, Wonder Weapons and current-weapon Pack-a-Punch.
- Perk grant, toggle, removal and clear tools.
- Power-Ups and permanent PinteMod drops.
- Zombie and round controls.
- Map power, Pack-a-Punch and standard unlock utilities.
- Position save/load and targeted teleportation.
- Community next-map, restart and vote-kick systems bound to XUID.
- Vote-kicked players blocked from reconnecting until the next map.
- Late-join and presence state preserved across reconnects during a map.
- Automatic next-map scheduling without interrupting the current match.
- Ranks & Records stored by BOIII_XUID in a clean v2 database.
- Personal activity statistics and leaderboards.
- Top 5 round records for 1P, 2P, 3P and 4P categories.
- Easter Egg records stored by BOIII_XUID with secure per-map activation.
- Native-candidate diagnostics, active-holder rules and anti-duplicate signatures.
- Boss and special-event commands on supported maps.
- Secret/special music controls where supported.
- Profiles for all 14 official BO3 Zombies maps.
- **122 unique dedicated-server console commands**.

## Supported maps

PinteMod includes official profiles for all 14 BO3 Zombies maps:

- Shadows of Evil
- The Giant
- Der Eisendrache
- Zetsubou No Shima
- Gorod Krovi
- Revelations
- Nacht der Untoten
- Verrückt
- Shi No Numa
- Kino der Toten
- Ascension
- Shangri-La
- Moon
- Origins

Some actions depend on the native scripts of the current map. Quest doors, objectives and Pack-a-Punch requirements are not blindly bypassed when doing so could break progression.

## Menu

Open the menu with:

```text
.menu
```

The historical `!menu` form remains accepted.

### Controls

- **Key 2 / Action Slot 2:** Up
- **Key 4 / Action Slot 3:** Down
- **Use or Reload:** Select
- **Melee:** Back / Close

### Main sections

- Administration
- Perks
- Weapons
- Rounds
- Power-Ups
- Fun
- Community
- Rankings & Records
- Easter Egg Records

Menu entries depend on the player's XUID role and the current map. The revive entry is visible only to Owners.

## Chat commands

The main prefix is `.`. The legacy prefix `!` is also accepted.

Common public commands include:

```text
.menu
.spawn
.players
.map
.round
.yes
.no
.votestatus
.votemap <map>
.voterestart
.votekick <player> [reason]
.rank
.ranks
.record
.records [1-4]
.eerecord
.eerecords [1-4]
```

Administrative examples include:

```text
.godmode [player]
.points [player] <amount>
.weapon [player] <alias>
.perk [player] <alias>
.setround <round>
.respawn [player]
.revive [player]
```

`.spawn` is for public late join, `.respawn` restores a spectator administratively, and `.revive` raises a player who is genuinely in last stand. `.revive` is Owner-only.

The complete dedicated-console reference is supplied in [`COMMANDES_CONSOLE_FR.txt`](COMMANDES_CONSOLE_FR.txt).

## Roles and permissions

| Role | Level | Typical access |
|---|---:|---|
| Owner | 4 | Full administration, persistent role management and administrative revive |
| Admin | 3 | High-level administration and vote management |
| Moderator | 2 | Moderation and selected server tools |
| Helper | 1 | Limited assistance tools |
| User | 0 | Public community commands only |

The dedicated server console is considered a trusted administration interface and can execute server-console commands directly.

### Default Owner

The public package intentionally contains one configured Owner:

```text
Name: BiereFraiche
BOIII_XUID: 9cf34426f668fb8b
Role: owner
```

This entry is in:

```text
custom_scripts/ezz_admin_config.gsc
```

All Admin, Moderator and Helper arrays are empty by default. No persistent `roles.json` is included in the archive.

Other server owners must replace or remove the default XUID before opening their server publicly. Removing a role from `roles.json` does not override an Owner still configured in `ezz_admin_config.gsc`.

Useful identity commands:

```text
ezzidentitystatus
ezzidentities
ezzidentity <PlayerName|BOIII_XUID>
ezzidroles
ezzidsetrole <PlayerName|BOIII_XUID> <owner|admin|moderator|helper>
ezzidremoverole <PlayerName|BOIII_XUID>
```

## Identity and security

PinteMod uses `player getXuid(false)` and normalizes the returned hexadecimal value as a stable **BOIII_XUID**.

The value is treated as an opaque BOIII identity and must not be advertised as a SteamID64, because BOIII can operate without Steam.

Permissions are fail-closed:

- a missing or invalid XUID results in the User role;
- no administrator permission is granted by display name;
- changing a display name does not change the persistent identity;
- role, vote, sanction, presence and record state stay bound to the XUID.

Display names remain useful for current-player selection and human-readable logs. Some older console selectors remain case-sensitive, so use the exact name shown by `ezzplayers`.

## Community system

PinteMod includes:

- next-map voting without interrupting the current match;
- restart voting with a warning delay;
- protected and logged vote-kick;
- XUID-bound initiators, voters, targets and cooldowns;
- vote-kick reconnect blocking until the next map;
- public late join with map-session state preserved by XUID;
- public player information and player-list commands;
- occasional configurable Chat tips.

Public voting, menu use, music and ordinary late join do not make a match unranked.

## Administrative revive and respawn

These actions are intentionally separated:

- `ezzspawn <PlayerName>`: restores a current spectator to active play.
- `ezzjoin <PlayerName>`: applies the public late-join rules.
- `ezzrevive <PlayerName>`: revives a player currently in native last stand.

The Chat command `.revive [player]` and its menu entry are Owner-only. The native revive backend restores normal combat state; PinteMod also snapshots and restores the supported classic perks so the player keeps their equipment, points, ammunition and perks when the operation succeeds.

A successful administrative revive marks the current match unranked.

## Ranks & Records

PinteMod v2 stores persistent player and map data by BOIII_XUID.

### Personal statistics

```text
.rank
```

Displays information such as:

- BOIII_XUID identity;
- total playtime;
- number of sessions;
- global activity position;
- personal best round;
- current-match presence percentage;
- ranked or unranked status.

### Activity leaderboard

```text
.ranks
```

Displays the most active players and their best-round information.

### Map records

```text
.record
.records
.records 1
.records 2
.records 3
.records 4
```

Records are separated into 1P, 2P, 3P and 4P categories. Each map/category keeps a maximum of five entries.

Round records are ordered by:

1. highest round;
2. shortest time used as the tie-breaker for the same round.

A player must satisfy the configured match-presence threshold (70% by default) to be included as a record holder. Holder identities are stored as XUIDs; names are display metadata only.

### Ranked and unranked matches

A successful PinteMod command that directly changes gameplay marks the current match **UNRANKED**.

Examples include:

- points, ammunition, God Mode or zombie ignore;
- administrative revive or respawn;
- weapons, Pack-a-Punch or perk grants;
- teleportation;
- forced round changes or zombie elimination;
- power, door and Pack-a-Punch map utilities;
- permanent drops and administrative boss spawning.

When a match becomes unranked:

- no further records are accepted;
- eligible record changes from the same match are rolled back;
- activity time and session statistics can continue;
- the reason is announced and logged.

### Storage and maintenance

Active v2 data is created locally in:

```text
boiii/scriptdata/pintemod/ranks_v2/players/
boiii/scriptdata/pintemod/ranks_v2/maps/
boiii/scriptdata/pintemod/backups/ranks_v2/
```

Maintenance commands:

```text
ezzrankstatus
ezzrankmigrationstatus
ezzranktest suite <PlayerName>
ezzrankaudit
ezzrankbackup [label]
ezzrankreset prepare
ezzrankreset confirm <token>
ezzrankreset cancel
```

The v2 database starts empty. Legacy pseudo-based records are not automatically read, merged or migrated.

## Easter Egg Records

PinteMod v2 includes an XUID-based Easter Egg record framework for the nine official maps with a main quest:

- Shadows of Evil
- Der Eisendrache
- Zetsubou No Shima
- Gorod Krovi
- Revelations
- Ascension
- Shangri-La
- Moon
- Origins

The Giant, Nacht der Untoten, Verrückt, Shi No Numa and Kino der Toten are marked `NO_MAIN_QUEST` in this record system.

### Security model

- official writes are locked individually per map;
- the default status is `DIAGNOSTIC`;
- official records require a ranked match;
- completion players and active holders are tracked by XUID;
- presence and minimum-holder rules are enforced;
- candidate signatures prevent duplicate diagnostic entries;
- TEST storage is isolated from official storage;
- the clean v2 base does not import legacy pseudo records.

The grouped suite validates schemas, storage isolation, candidate handling and active-holder rules. It does **not** prove that a map's native completion signal is correct.

Each native detector must be confirmed by completing that map's real main quest on the dedicated server before official writes are enabled.

Recommended review sequence:

```text
ezzeestatus
ezzeemigrationstatus
ezzeemaps
ezzeeplayers
ezzeecandidates current
ezzeetest suite
ezzeeaudit
ezzeevalidate <map> confirm
ezzeeofficial <map> enable
```

Do not execute the final two commands until the real completion signal has been observed and reviewed. See [`VALIDATION_EE_FR.txt`](VALIDATION_EE_FR.txt).

Active v2 data is created under:

```text
boiii/scriptdata/pintemod/easter_eggs_v2/
```

## Validated boss events

The event module includes native boss spawning on compatible maps:

- Shadows of Evil: Margwa
- Origins: Panzer
- Der Eisendrache: Panzer
- Zetsubou No Shima: Thrasher
- Gorod Krovi: Mechz
- Revelations: Margwa variants and Panzer
- Moon: Astronaut

Bosses use native map actors and spawn at the targeted player's aimed ground position when the required backend exists.

## Special music

Configured native music states include:

- Shadows of Evil: Snakeskin Boots / Cold Hard Cash
- The Giant: native special `egg` state
- Der Eisendrache: Dead Again
- Gorod Krovi: Ace of Spades / Dead Ended
- Revelations: The Gift
- Verrückt: Lullaby for a Dead Man
- Shi No Numa: The One
- Kino der Toten: 115
- Ascension: Abracadavre
- Shangri-La: Pareidolia
- Moon: Coming Home / Nightmare
- Origins: Archangel

Dead Flowers is not enabled on Zetsubou No Shima because the expected native `musicCmd` registry entry was unavailable in the tested BOIII environment.

## Data storage and neutral distribution

The release archive contains no development-server data. Local files are created only after installation and use.

Typical paths:

```text
boiii/scriptdata/pintemod/identity/
boiii/scriptdata/pintemod/ranks_v2/
boiii/scriptdata/pintemod/easter_eggs_v2/
boiii/scriptdata/pintemod/logs/
boiii/scriptdata/pintemod/backups/
```

The ZIP contains no player profile, record, persistent role registry, log, backup, sanction, vote history or other `scriptdata` file.

## Installation

1. Stop the BOIII dedicated server completely.
2. Back up the current `boiii/custom_scripts/` folder and local data when needed.
3. Remove obsolete PinteMod v1.x files and development hotfixes.
4. Copy the supplied `custom_scripts/` directory into the server's `boiii/` directory.
5. Confirm that this path exists:

```text
<Server>/boiii/custom_scripts/ezz_admin_01_main.gsc
```

6. Review the default Owner entry in `custom_scripts/ezz_admin_config.gsc`.
7. Start the server and load a Zombies map.

Expected startup lines include:

```text
[PinteMod] Core v2.0.0 FINAL loaded
[PinteMod] Configuration v2.0.0 FINAL loaded
[PinteMod] Identity v2.0.2 FINAL loaded
[PinteMod] Community v2.0.0 FINAL loaded
[PinteMod] Ranks & Records v2.0.0 FINAL loaded
[PinteMod] Easter Egg Records v2.0.0 FINAL loaded
```

See [`INSTALLATION_FR.txt`](INSTALLATION_FR.txt) for the complete French setup and first-start checklist.

## Recommended first-start checks

Run these only after the player has fully joined the map:

```text
ezztest
ezzplayers
ezzidentitystatus
ezzidentities
ezzcommunitystatus
ezzrankstatus
ezzeestatus
```

Non-destructive validation suites:

```text
ezzidentitytest suite <PlayerName>
ezzcommunitytest suite <PlayerName>
ezzrevivetest suite <PlayerName>
ezzranktest suite <PlayerName>
ezzeetest suite
```

Expected grouped results:

```text
Identity:  14/14 PASS
Community: 20/20 PASS
Revive:    10/10 PASS
Ranks:     17/17 PASS
EE:        20/20 PASS
EE audit:   9/9 PASS
```

## Real-server validation completed

The following v2 foundations were validated on a real dedicated BOIII server:

- BOIII_XUID retrieval and persistence;
- fail-closed XUID authorization;
- persistent Owner role after restart;
- XUID-aware Chat authorization and logs;
- Community vote/presence state and late-join rules;
- Owner-only administrative revive;
- Ranks & Records clean XUID storage;
- record audit and backup;
- EE XUID schemas, clean storage, candidate rules and official-data isolation.

Native Easter Egg completion detectors remain locked for official writes until each real quest is validated map by map.

## Important behavior and limitations

- Player selectors in some older console commands remain case-sensitive.
- Player names containing spaces are not uniformly supported by every legacy selector.
- `ezzspawn`, `ezzjoin` and `ezzrevive` have different purposes; do not treat them as aliases.
- Gameplay-altering administration commands intentionally make the match unranked.
- Quest-specific map logic may still require native objectives.
- The missing `gamedata/constbaselines/...` warning sometimes printed by BOIII is external to PinteMod when the framework otherwise loads normally.
- No AFK commands are included.
- Noclip is not included.
- Round-transition locking is not included.

## Package contents

```text
custom_scripts/                 20 complete runtime files
README.md                       Complete GitHub documentation
README_FR.txt                   French release overview
INSTALLATION_FR.txt             French installation and role setup
COMMANDES_CONSOLE_FR.txt        Categorized reference for 122 console commands
VALIDATION_EE_FR.txt            Native Easter Egg validation procedure
FORUM_POST_FR.md                Ready-to-publish French forum announcement
CHANGELOG_v2.0.0.txt            Release changelog
SHA256SUMS.txt                  SHA-256 checksums
```

## Upgrade notes

Install v2.0 as one coherent package. Do not overlay individual development Lots or old hotfixes on top of the FINAL files.

Ranks v2 and EE Records v2 start from clean XUID databases. Legacy pseudo-based data is deliberately not imported.

## Credits

PinteMod was created by **BiereFraiche** with development assistance from **ChatGPT**.
