======================================================================
 PINTE MOD v2.0.0 FINAL — SERVEUR DÉDIÉ BOIII ZOMBIES
======================================================================

PinteMod est un framework serveur GSC pour BOIII Zombies.

Fonctionnalités principales :
- identité et permissions persistantes par BOIII_XUID ;
- commandes console et commandes Chat ;
- menu HUD filtré par rôle et par map ;
- outils joueurs, armes, atouts, manches, bonus et téléportation ;
- votes communautaires, late join et votekick liés au XUID ;
- réanimation administrative réservée au rôle Owner ;
- Ranks & Records liés au XUID avec base v2 indépendante ;
- EE Records liés au XUID avec validation officielle map par map ;
- compatibilité avec les 14 maps Zombies officielles de Black Ops III.

CONTENU DE LA DISTRIBUTION
----------------------------------------------------------------------

- custom_scripts/ : les 20 fichiers runtime complets ;
- README.md : documentation GitHub complète et détaillée en anglais ;
- FORUM_POST_FR.md : message de publication prêt à copier-coller ;
- INSTALLATION_FR.txt : installation et configuration des rôles ;
- COMMANDES_CONSOLE_FR.txt : guide des 122 commandes console ;
- VALIDATION_EE_FR.txt : procédure de validation des détecteurs EE ;
- CHANGELOG_v2.0.0.txt : résumé de la version ;
- SHA256SUMS.txt : empreintes des fichiers livrés.

AUCUNE DONNÉE SERVEUR EMBARQUÉE
----------------------------------------------------------------------

Le ZIP ne contient aucun profil, record, rôle persistant, journal,
sauvegarde, vote, sanction ni fichier provenant de boiii/scriptdata/.
Les données locales sont créées au premier démarrage du serveur.

IDENTITÉ
----------------------------------------------------------------------

PinteMod utilise player getXuid(false), exposé sous la forme d'un
identifiant hexadécimal stable appelé BOIII_XUID.

Ce BOIII_XUID doit être traité comme un identifiant opaque. Il ne faut pas
le présenter comme un SteamID64, notamment parce que BOIII peut fonctionner
sans Steam.

AVERTISSEMENT IMPORTANT POUR LES SERVEURS PUBLICS
----------------------------------------------------------------------

La distribution conserve volontairement le créateur comme Owner par défaut :

    BiereFraiche
    BOIII_XUID : 9cf34426f668fb8b

Avant d'ouvrir une installation au public, le propriétaire du serveur doit
remplacer ou supprimer cette entrée dans :

    custom_scripts/ezz_admin_config.gsc

Consulte INSTALLATION_FR.txt. Une simple suppression dans roles.json ne
neutralise pas un Owner encore présent dans la configuration GSC.

CRÉDITS
----------------------------------------------------------------------

PinteMod — créé par BiereFraiche et ChatGPT.
Version : 2.0.0 FINAL
