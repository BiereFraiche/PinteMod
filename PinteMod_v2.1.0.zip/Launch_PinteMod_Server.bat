@echo off
setlocal
title PinteMod v2.1.0
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0boiii\tools\PinteMod_Server_Launcher.ps1" -PackageRoot "%~dp0" %*
if errorlevel 1 (
    echo.
    echo PinteMod launcher stopped with an error.
    pause
)
endlocal
