# PinteMod v2.1.0

[English documentation](README.md)

PinteMod est un framework serveur d’administration, de communauté, de localisation et de records pour les serveurs dédiés **Call of Duty: Black Ops III Zombies** fonctionnant sous **BOIII/Ezz**.

Créé et maintenu par **BiereFraiche**, avec l’assistance de développement de ChatGPT.

Les joueurs n’ont aucun mod client à installer. PinteMod fonctionne depuis `boiii/custom_scripts/` et fournit des outils Windows optionnels pour la localisation GeoIP, les bannissements XUID persistants et une Live Console en lecture seule.

## Nouveautés principales de la v2.1.0

- correctif public Spawn / Late Join validé sur serveur réel ;
- permissions et données persistantes liées au `BOIII_XUID` ;
- localisation individuelle en français, anglais et espagnol ;
- choix manuel de langue et détection automatique optionnelle par GeoIP ;
- aucune conservation persistante des adresses IP par les outils PinteMod ;
- configuration RCON locale persistante et protégée avec Windows DPAPI ;
- Live Console nettoyée avec flux Chat et commandes séparés ;
- bannissements XUID permanents ou temporaires en UTC pour Owner/Admin ;
- profil EE Origins officiel et alias court `ezzeeval` ;
- journaux par session avec rotation et options de confidentialité ;
- Ranks, records de cartes et records EE dans des bases XUID isolées ;
- affichage uniforme et réduit au démarrage des modules ;
- modes de lancement local complet, serveur seul et outils distants ;
- lanceur principal placé directement à la racine de `UnrankedServer`.

## Cartes prises en charge

### BO3 principal et DLC

- Shadows of Evil
- The Giant
- Der Eisendrache
- Zetsubou No Shima
- Gorod Krovi
- Revelations

### Zombies Chronicles

- Nacht der Untoten
- Verrückt
- Shi No Numa
- Kino der Toten
- Ascension
- Shangri-La
- Moon
- Origins

Les cartes personnalisées peuvent charger le framework générique, mais leurs ouvertures, armes, musiques, événements et quêtes spécifiques ne sont pas garantis.

## Installation

1. arrêter complètement BOIII et tous les outils PinteMod ;
2. sauvegarder `boiii/custom_scripts/` et `boiii/scriptdata/pintemod/` ;
3. supprimer les anciens scripts PinteMod de `boiii/custom_scripts/` pour éviter les modules en double ;
4. extraire l’archive directement dans le dossier qui contient déjà `boiii` et `zone` ;
5. lancer `Launch_PinteMod_Server.bat` depuis la racine de `UnrankedServer` ;
6. au premier lancement, définir le mot de passe RCON local et sélectionner le lanceur BOIII existant ;
7. effectuer la validation recommandée avant d’ouvrir le serveur au public.

Structure attendue :

```text
<UnrankedServer>/
├── Launch_PinteMod_Server.bat
├── Launch_PinteMod_Server_Only.bat
├── Launch_PinteMod_Remote_Tools.bat
├── boiii/
│   ├── custom_scripts/
│   │   ├── ezz_admin_00_banner.gsc
│   │   ├── ezz_admin_01_main.gsc
│   │   ├── ...
│   │   └── ezz_admin_zombies.gsc
│   └── tools/
├── docs/
└── zone/
```

`hotfix.gsc` n’est volontairement pas fourni : il appartient à l’environnement de compatibilité BOIII, pas à PinteMod.

Voir [`docs/INSTALLATION_FR.txt`](docs/INSTALLATION_FR.txt) pour la procédure complète.

## Modes de lancement

### Mode local complet

```text
Launch_PinteMod_Server.bat
```

Lance le Ban Service, le serveur BOIII, le bridge GeoIP et la Live Console. Le premier lancement crée la configuration propre à la machine ; les suivants la réutilisent.

### Serveur uniquement

```text
Launch_PinteMod_Server_Only.bat
```

Lance BOIII avec la configuration locale mémorisée, sans démarrer les outils opérateur.

### VM, réseau local ou poste d’administration distant

```text
Launch_PinteMod_Remote_Tools.bat
```

Lance le Ban Service, GeoIP et la Live Console depuis une autre machine Windows ayant accès au RCON et à `boiii/scriptdata/pintemod`.

La configuration par défaut suppose que tous les composants tournent sur la même machine et utilise donc `127.0.0.1`. Depuis l’hôte d’une VM, une autre machine LAN ou un poste distant, il faut utiliser une adresse LAN/VPN stable, configurer les droits du partage et limiter le pare-feu. Les secrets DPAPI sont liés au compte Windows et à la machine qui les ont créés.

Voir [`docs/DEPLOIEMENT_LOCAL_VM_DISTANT_FR.txt`](docs/DEPLOIEMENT_LOCAL_VM_DISTANT_FR.txt).

## Propriétaire par défaut

La distribution publique contient un seul Owner bootstrap :

```text
Métadonnée d’affichage : BiereFraiche
BOIII_XUID : 9cf34426f668fb8b
Rôle : owner
```

Aucun Admin, Moderator ou Helper n’est préconfiguré. Aucune base de rôles active, profil joueur, record, base de bannissements, vote, journal ou sauvegarde serveur n’est distribué.

Les autres propriétaires doivent remplacer ou retirer ce XUID dans `boiii/custom_scripts/ezz_admin_config.gsc`, ou attribuer leur propre rôle depuis la console dédiée :

```text
ezzidsetrole <PlayerName|BOIII_XUID|ClientNumber> owner
```

## Identité stable et ciblage sécurisé

L’authentification, les permissions, les langues, les bannissements et les données persistantes utilisent le XUID hexadécimal fourni par BOIII.

Les commandes console peuvent cibler un joueur connecté avec :

```text
<PlayerName|BOIII_XUID|ClientNumber>
```

Exemples :

```text
ezzidentity 9cf34426f668fb8b
ezzidentity #0
ezzidentity client:0
ezzidentity BiereFraiche
```

Le pseudo n’est qu’un raccourci lorsque le résultat est sans ambiguïté. Si deux joueurs utilisent le même nom, PinteMod refuse le sélecteur par pseudo et exige un XUID ou un numéro client.

Le Chat et le menu transportent en interne un XUID ou un slot client au lieu de faire confiance au pseudo brut. Les séparateurs de commandes dangereux et les retours à la ligne sont rejetés avant l’exécution serveur.

## Rôles

| Niveau | Rôle | Accès habituel |
|---:|---|---|
| 4 | Owner | Permissions, bannissements, revive et maintenance protégée |
| 3 | Admin | Bannissements, cartes, manches, ouvertures, Events et commandes serveur |
| 2 | Moderator | Administration de partie, armes, perks et points |
| 1 | Helper | Diagnostics en lecture et aide limitée aux joueurs |
| 0 | User | Menu public, votes, Late Join, rangs et records publics |

Les changements persistants de rôles sont stockés localement dans :

```text
boiii/scriptdata/pintemod/identity/roles.json
```

## Commandes Chat

Le préfixe principal est `.`. L’ancien préfixe `!` reste accepté.

Exemples publics :

```text
.menu
.spawn
.lang fr
.lang en
.lang es
.lang auto
.yes
.no
.votestatus
.votemap origins
.voterestart
.votekick <joueur> [raison]
.rank
.ranks
.record
.records 2
.eerecord
.eerecords 4
```

Exemples staff selon le rôle :

```text
.points 50000
.ammo
.weapon raygun
.perk jug
.god
.ignore
.respawn <joueur>
.revive <joueur>
.setrole <joueur> moderator
.ban <joueur|xuid> 2h raison
.unban <joueur|xuid>
.baninfo <joueur|xuid>
.banlist
```

La référence complète des commandes console se trouve dans [`docs/COMMANDES_CONSOLE_FR.txt`](docs/COMMANDES_CONSOLE_FR.txt).

## Menu

Ouvrir le menu avec :

```text
.menu
```

Contrôles actuellement affichés dans le HUD serveur :

- **Action Slot 2 / touche 2 :** monter ;
- **Action Slot 4 / touche 4 :** descendre ;
- **Utiliser / Recharger :** sélectionner ;
- **Mêlée :** retour ou fermeture.

Les sections comprennent Communauté / Joueurs, Administration, Perks, Armes, Manches, Power-Ups, Fun et Rangs & Records. Le contenu est filtré selon le rôle et la carte active. Les cibles internes restent des XUID/slots client ; les pseudos ne servent qu’à l’affichage.

## Fonctions communautaires

- HUD de bienvenue et rappels publics ;
- Late Join public avec `.spawn` ou le menu Joueurs ;
- respawn administratif des spectateurs ;
- revive natif réservé à l’Owner pour un joueur à terre ;
- vote de prochaine carte sans interrompre la partie ;
- vote de redémarrage avec avertissement ;
- vote-kick protégé avec blocage de reconnexion ;
- changement automatique de carte après la partie ;
- suivi de présence résistant aux reconnexions et changements de pseudo ;
- rapports Live de connexion, votes et modération.

### Spawn, respawn et revive

Ces opérations sont distinctes :

- `ezzjoin` / `.spawn` : Late Join public d’un spectateur éligible ;
- `ezzspawn` : respawn administratif d’un spectateur ;
- `ezzrevive` : revive natif d’un joueur à terre, réservé à l’Owner dans le Chat/menu.

## Bannissements XUID persistants

Les bannissements complètent le kick et le vote-kick. Ils sont liés au `BOIII_XUID` et ne stockent aucune adresse IP.

Commandes console :

```text
ezzban <Player|BOIII_XUID|ClientNumber> [30m|2h|7d|4w|perm] [raison]
ezzunban <Player|BOIII_XUID|ClientNumber>
ezzbaninfo <Player|BOIII_XUID|ClientNumber>
ezzbanlist
ezzbanstatus
ezzbantest suite
```

Commandes Chat Owner/Admin :

```text
.ban <Player|BOIII_XUID> [durée] [raison]
.unban <Player|BOIII_XUID>
.baninfo <Player|BOIII_XUID>
.banlist
```

Règles d’autorisation :

- un Owner peut bannir Admin, Moderator, Helper et User, mais pas un autre Owner ;
- un Admin peut bannir Moderator, Helper et User, mais pas Owner/Admin ;
- le self-ban est refusé ;
- le XUID bootstrap Owner fourni est protégé.

Les expirations temporaires sont maintenues en UTC par `PinteMod_Ban_Service.ps1` et survivent aux changements de carte, reconnexions et redémarrages tant que le service est disponible. Bannir un joueur connecté marque la partie actuelle UNRANKED.

Les données locales se trouvent sous :

```text
boiii/scriptdata/pintemod/bans/
```

Voir [`docs/BANNISSEMENTS_FR.txt`](docs/BANNISSEMENTS_FR.txt).

## Localisation et GeoIP

Langues intégrées :

```text
fr  Français
en  English
es  Español
```

Le choix manuel du joueur est prioritaire sur GeoIP et restauré par XUID :

```text
.lang fr
.lang en
.lang es
.lang auto
```

Le bridge GeoIP lit temporairement l’adresse d’une nouvelle connexion par RCON, résout le pays et la langue en mémoire, puis ne conserve pas cette adresse. PinteMod stocke uniquement le XUID, le code pays lorsque nécessaire et la préférence de langue. BOIII peut malgré tout afficher la réponse brute de `status` dans sa console native.

Le bridge regroupe les demandes en attente et réutilise un instantané `status` validé pendant une courte durée afin de limiter le bruit de la console native. D’autres langues pourront être ajoutées selon les pays réellement observés sur le serveur.

Voir [`docs/LOCALISATION_GEOIP_FR.txt`](docs/LOCALISATION_GEOIP_FR.txt).

## Ranks & Records

Les rangs utilisent la racine de stockage isolée :

```text
boiii/scriptdata/pintemod/ranks_v2/
```

Fonctions :

- temps de jeu et statistiques de sessions par XUID ;
- meilleure manche et position d’activité globale ;
- Top 5 par carte et catégorie 1P/2P/3P/4P ;
- présence minimale de 70 % pour participer à un record ;
- meilleure manche prioritaire, puis temps le plus court en cas d’égalité ;
- gestion des participants connectés et déconnectés éligibles par XUID ;
- protection UNRANKED automatique après une commande qui affecte le gameplay ;
- rollback des records personnels/équipe créés plus tôt dans la même partie ;
- commandes d’audit, sauvegarde et réinitialisation protégée.

Commandes publiques :

```text
.rank
.ranks
.record
.records [1-4]
```

Maintenance :

```text
ezzrankstatus
ezzranktest suite <selector>
ezzrankaudit
ezzrankbackup [label]
ezzrankreset prepare
ezzrankreset confirm <token>
```

Aucun ancien record basé sur le pseudo n’est importé automatiquement.

## Records Easter Egg

Le stockage EE utilise une base v2 séparée :

```text
boiii/scriptdata/pintemod/easter_eggs_v2/
```

Le système structurel enregistre notamment les XUID de complétion, les détenteurs actifs, les participants exclus, le temps, la catégorie de joueurs, l’état ranked/unranked, la raison d’acceptation/rejet et une signature anti-doublon.

Les écritures officielles sont contrôlées **carte par carte**. Un profil reste en diagnostic tant que son signal natif de fin de quête principale n’a pas été confirmé sur un serveur réel. Le profil Origins est validé pour les écritures officielles dans la v2.1.0.

Commandes utiles :

```text
ezzeestatus
ezzeemaps
ezzeeplayers
ezzeetest suite
ezzeeaudit
ezzeecandidates <map>
ezzeevalidate <map> confirm
ezzeeval <map>
ezzeeofficial <map> enable
```

Ne pas activer les écritures officielles sur une carte non validée. Voir [`docs/VALIDATION_EE_FR.txt`](docs/VALIDATION_EE_FR.txt).

## Stockage JSON protégé

Les registres Identity, Ranks et EE utilisent `ezz_admin_storage.gsc`.

Pour chaque écriture protégée, PinteMod :

1. écrit un fichier `.tmp` ;
2. le relit et le valide ;
3. conserve l’ancienne version valide en `.bak` ;
4. écrit et vérifie le fichier actif ;
5. restaure la version précédente si la vérification échoue.

Les JSON invalides trouvés au chargement sont copiés dans :

```text
boiii/scriptdata/pintemod/backups/corrupt/
```

Un `.bak` valide est restauré lorsqu’il existe. Il s’agit d’une stratégie récupérable en deux phases utilisant les fonctions fichiers de BOIII, pas d’un renommage atomique garanti par le système de fichiers.

Diagnostics :

```text
ezzstoragestatus
ezzstoragetest suite
```

## Journaux et confidentialité

La configuration publique actuelle contient notamment :

```gsc
level.pintemod_log_chat_messages = true;
level.pintemod_log_xuids = true;
level.pintemod_log_guids = false;
level.pintemod_log_max_size_kb = 2048;
```

Les journaux sont regroupés par carte/session sous :

```text
boiii/scriptdata/pintemod/logs/
├── current_session.json
├── sessions/<map>_s<counter>_<GetTime>/
│   ├── connections.log
│   ├── identity.log
│   ├── community.log
│   ├── ranks.log
│   ├── easter_eggs.log
│   ├── storage.log
│   ├── bans.log
│   ├── chat/
│   └── votekick/
└── archive/YYYY-MM-DD/
```

La journalisation du Chat normal est activée dans la configuration publique v2.1.0 afin que la Live Console affiche les messages et conserve les éléments utiles à la modération. Le propriétaire du serveur doit informer les joueurs lorsque la réglementation applicable l’exige et peut désactiver cette option dans `ezz_admin_config.gsc`. Les GUID restent désactivés. Les règles de masquage XUID/GUID sont appliquées centralement aux journaux gérés.

## Live Console en lecture seule

Les lanceurs local complet et outils distants démarrent automatiquement la Live Console. Elle peut aussi être lancée directement avec :

```text
boiii\tools\Launch_PinteMod_LiveConsole.bat
```

La Live Console :

- détecte le manifeste de carte/session actif ;
- sépare les messages Chat des commandes ;
- suit connexions, Communauté, votes, kicks, bans, Identity, Ranks, EE, Storage et Localisation ;
- met en évidence les erreurs, données corrompues et événements importants ;
- masque le bruit de diagnostic courant par défaut ;
- affiche les diagnostics sur demande avec `D` ;
- propose filtres, recherche, export et ouverture du dossier actif ;
- peut jouer un son court pour les erreurs critiques ;
- archive les sessions terminées selon la date du système ;
- n’envoie jamais de commande au serveur.

Le filtre `N` affiche les bannissements et expirations. L’aide clavier est affichée au démarrage et avec `H`.

## Registres partagés

`ezz_admin_registry.gsc` centralise :

- les codes et noms des cartes officielles ;
- les alias de cartes et collections ;
- la présence des quêtes principales et le minimum de joueurs EE ;
- les rôles minimums des commandes Chat ;
- les métadonnées d’impact gameplay utilisées par la protection des records.

Diagnostic :

```text
ezzregistrystatus
```

## État des validations

La base suivante a été validée sur un serveur dédié BOIII réel :

```text
Community                  24/24 PASS
Localization               14/14 PASS
Spawn / Late Join          PASS
GeoIP local et extérieur   PASS
COUNTRY_ANNOUNCED          PASS
Chat Live Console          PASS
Séparation Chat/commandes  PASS
RCON persistant            PASS
g_password reste vide      PASS
Détection automatique root PASS
Origins EE officiel        PASS
Alias ezzeeval              PASS
Démarrage console propre   PASS
```

Le Ban Service, l’expiration des bans temporaires et les modes Server Only / Remote Tools ont été ajoutés après cette validation de base. Avant ouverture publique, exécuter :

```text
ezzbantest suite
```

Résultat statique attendu :

```text
[PinteMod Ban] RESULT 8/8 PASS | failed=0
```

Puis effectuer les tests réels de reconnexion, expiration et hiérarchie décrits dans [`docs/BANNISSEMENTS_FR.txt`](docs/BANNISSEMENTS_FR.txt) et [`docs/VALIDATION_v2.1.0_FR.txt`](docs/VALIDATION_v2.1.0_FR.txt).

## Limites connues

- BOIII peut afficher un bloc natif `status` pour un nouveau lot de connexions GeoIP ;
- les signaux natifs de fin EE ne sont pas encore validés sur toutes les cartes ;
- un ban temporaire peut rester actif jusqu’au retour du Ban Service si celui-ci était arrêté au moment de l’expiration ;
- un déploiement distant nécessite une configuration manuelle LAN/VPN, pare-feu et partage ;
- le noclip est volontairement indisponible ;
- aucune commande AFK n’est incluse ;
- aucun verrou de transition de manche n’est inclus ;
- les cartes personnalisées nécessitent leurs propres profils ;
- GSC ne fournit pas de renommage atomique réel ; les fichiers `.tmp` et `.bak` réduisent les risques ;
- les outils opérateur nécessitent Windows PowerShell.

## Contenu du paquet public

```text
Launch_PinteMod_Server.bat             Lanceur local complet
Launch_PinteMod_Server_Only.bat        Lanceur BOIII uniquement
Launch_PinteMod_Remote_Tools.bat       Outils VM/LAN/VPN
boiii/custom_scripts/                   Sources GSC PinteMod
boiii/tools/                            GeoIP, Ban Service et Live Console
docs/                                   Installation, architecture et validation
README.md                               Documentation GitHub principale
README_FR.md                            Documentation française complète
SECURITY.md                             Politique sécurité reconnue par GitHub
THIRD_PARTY_NOTICES.md                  Mentions légales et tierces
CHANGELOG_v2.1.0.txt                    Journal des changements
LICENSE                                 GNU GPL version 3
SHA256SUMS.txt                          Empreintes des fichiers de la version
```

L’architecture détaillée et l’inventaire du paquet se trouvent dans [`docs/`](docs/) :

- `ARCHITECTURE.md` ;
- `PACKAGE_MANIFEST_v2.1.0.txt` ;
- `INSTALLATION_FR.txt` ;
- `COMMANDES_CONSOLE_FR.txt` ;
- `DEPLOIEMENT_LOCAL_VM_DISTANT_FR.txt` ;
- `LOCALISATION_GEOIP_FR.txt` ;
- `BANNISSEMENTS_FR.txt` ;
- `VALIDATION_EE_FR.txt` ;
- `VALIDATION_v2.1.0_FR.txt`.

## Fichiers locaux à ne jamais publier

```text
zone/pintemod_server_secrets.cfg
boiii/tools/*.local.json
boiii/tools/*.secret.txt
boiii/scriptdata/pintemod/
```

Ces chemins sont couverts par les fichiers `.gitignore` fournis.

## Licence

Copyright © 2026 BiereFraiche.

PinteMod est distribué sous **GNU General Public License version 3**. Voir `LICENSE` et `THIRD_PARTY_NOTICES.md`.

Cette licence couvre uniquement les sources propres à PinteMod. Elle n’accorde aucun droit sur Call of Duty: Black Ops III, BOIII/Ezz ou tout composant propriétaire externe.
