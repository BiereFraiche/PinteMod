param(
    [string]$PackageRoot = "",
    [string]$ServerRoot = "",
    [string]$ServerLauncher = "",
    [switch]$ServerOnly
)

$ErrorActionPreference = "Stop"
$Host.UI.RawUI.WindowTitle = "PinteMod v2.1.0"

$createdNew = $false
$mutex = New-Object System.Threading.Mutex($false, "Global\PinteMod_v2_1_ServerLauncher", [ref]$createdNew)
if (-not $createdNew) {
    throw "PinteMod is already being launched by another instance."
}

function Write-Utf8NoBom {
    param([string]$Path, [string]$Content)
    [System.IO.File]::WriteAllText($Path, $Content, [System.Text.UTF8Encoding]::new($false))
}

function Resolve-PinteModLayout {
    param([string]$RequestedRoot, [string]$RequestedPackageRoot)

    function Test-Candidate {
        param([string]$Candidate)
        if ([string]::IsNullOrWhiteSpace($Candidate)) { return $null }
        try { $full = [System.IO.Path]::GetFullPath($Candidate.Trim('"')) }
        catch { return $null }

        $nestedBoiii = Join-Path $full "boiii"
        if ((Test-Path -LiteralPath (Join-Path $nestedBoiii "custom_scripts")) -and
            (Test-Path -LiteralPath (Join-Path $nestedBoiii "tools"))) {
            return [pscustomobject]@{ ServerRoot = $full; BoiiiRoot = $nestedBoiii }
        }

        if ((Split-Path -Leaf $full) -ieq "boiii" -and
            (Test-Path -LiteralPath (Join-Path $full "custom_scripts")) -and
            (Test-Path -LiteralPath (Join-Path $full "tools"))) {
            return [pscustomobject]@{ ServerRoot = (Split-Path -Parent $full); BoiiiRoot = $full }
        }
        return $null
    }

    foreach ($seed in @($RequestedRoot, $RequestedPackageRoot, $PSScriptRoot, (Get-Location).Path) | Select-Object -Unique) {
        $candidate = $seed
        for ($depth = 0; $depth -lt 7 -and $candidate; $depth++) {
            $result = Test-Candidate -Candidate $candidate
            if ($result) { return $result }
            $parent = Split-Path -Parent $candidate
            if (-not $parent -or $parent -eq $candidate) { break }
            $candidate = $parent
        }
    }

    $entered = Read-Host "Folder that directly contains boiii"
    $result = Test-Candidate -Candidate $entered
    if (-not $result) { throw "Invalid server folder: $entered" }
    return $result
}

function Get-LauncherCandidates {
    param([string]$Root)
    $excluded = @(
        "Launch_PinteMod_Server.bat",
        "Launch_PinteMod_GeoIP_Bridge.bat",
        "Launch_PinteMod_LiveConsole.bat",
        "Configure_PinteMod_Server_Secrets.bat",
        "Launch_PinteMod_Server_Only.bat",
        "Launch_PinteMod_Remote_Tools.bat"
    )
    $items = Get-ChildItem -LiteralPath $Root -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Extension -in @('.bat', '.cmd') -and $_.Name -notin $excluded }

    $preferred = New-Object System.Collections.Generic.List[object]
    foreach ($item in $items) {
        try { $content = Get-Content -LiteralPath $item.FullName -Raw -ErrorAction Stop }
        catch { continue }
        if ($item.Name -match '(?i)(boiii|server|zombies|start|launch)' -or
            $content -match '(?i)(boiii(?:\.exe)?|blackops3|server_zm|dedicated)') {
            $preferred.Add($item) | Out-Null
        }
    }
    return @($preferred | Sort-Object FullName -Unique)
}

function Resolve-ServerLauncherPath {
    param([string]$Requested, [string]$Root, [object]$Config)

    foreach ($value in @($Requested, [string]$Config.server_launcher)) {
        if ([string]::IsNullOrWhiteSpace($value)) { continue }
        $candidate = $value
        if (-not [System.IO.Path]::IsPathRooted($candidate)) { $candidate = Join-Path $Root $candidate }
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            return [System.IO.Path]::GetFullPath($candidate)
        }
    }

    $candidates = @(Get-LauncherCandidates -Root $Root)
    if ($candidates.Count -eq 1) { return $candidates[0].FullName }
    if ($candidates.Count -gt 1) {
        Write-Host "Several server launchers were found:" -ForegroundColor Yellow
        for ($i = 0; $i -lt $candidates.Count; $i++) {
            Write-Host (" [{0}] {1}" -f ($i + 1), $candidates[$i].Name) -ForegroundColor Gray
        }
        $choice = Read-Host "Choose the server launcher number"
        $index = 0
        if ([int]::TryParse($choice, [ref]$index) -and $index -ge 1 -and $index -le $candidates.Count) {
            return $candidates[$index - 1].FullName
        }
    }

    $entered = Read-Host "Full path to your existing BOIII server .bat or .cmd"
    if (-not (Test-Path -LiteralPath $entered -PathType Leaf)) {
        throw "Server launcher not found: $entered"
    }
    return [System.IO.Path]::GetFullPath($entered)
}

function Test-ToolAlreadyRunning {
    param([string]$ScriptPath)
    try {
        $escaped = [regex]::Escape([System.IO.Path]::GetFullPath($ScriptPath))
        return [bool](Get-CimInstance Win32_Process -ErrorAction Stop |
            Where-Object { $_.CommandLine -and $_.CommandLine -match $escaped } |
            Select-Object -First 1)
    }
    catch { return $false }
}

function Start-PinteModTool {
    param([string]$ScriptPath, [string]$Title)
    if (Test-ToolAlreadyRunning -ScriptPath $ScriptPath) {
        Write-Host "[SKIP] $Title is already running." -ForegroundColor Yellow
        return $null
    }
    $args = @('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $ScriptPath + '"'))
    return Start-Process -FilePath 'powershell.exe' -ArgumentList $args -WorkingDirectory (Split-Path -Parent $ScriptPath) -PassThru
}

$toolProcesses = New-Object System.Collections.Generic.List[object]
try {
    $layout = Resolve-PinteModLayout -RequestedRoot $ServerRoot -RequestedPackageRoot $PackageRoot
    $serverRootPath = $layout.ServerRoot
    $boiiiRoot = $layout.BoiiiRoot
    $toolsRoot = Join-Path $boiiiRoot 'tools'
    $zoneRoot = Join-Path $serverRootPath 'zone'

    $secretCfg = Join-Path $zoneRoot 'pintemod_server_secrets.cfg'
    $bridgeSecret = Join-Path $toolsRoot 'PinteMod_GeoIP_Bridge.secret.txt'
    if (-not (Test-Path -LiteralPath $secretCfg) -or -not (Test-Path -LiteralPath $bridgeSecret)) {
        Write-Host "PinteMod RCON has not been configured on this server." -ForegroundColor Yellow
        Write-Host "The password is created locally and is never included in the public package." -ForegroundColor Gray
        & (Join-Path $toolsRoot 'Configure_PinteMod_Server_Secrets.ps1') -ServerRoot $serverRootPath
        if (-not (Test-Path -LiteralPath $secretCfg) -or -not (Test-Path -LiteralPath $bridgeSecret)) {
            throw "RCON configuration was not completed."
        }
    }

    $examplePath = Join-Path $toolsRoot 'PinteMod_Server_Launcher.example.json'
    $localPath = Join-Path $toolsRoot 'PinteMod_Server_Launcher.local.json'
    if (Test-Path -LiteralPath $localPath) {
        $config = Get-Content -LiteralPath $localPath -Raw | ConvertFrom-Json -ErrorAction Stop
    }
    elseif (Test-Path -LiteralPath $examplePath) {
        $config = Get-Content -LiteralPath $examplePath -Raw | ConvertFrom-Json -ErrorAction Stop
    }
    else {
        $config = [pscustomobject]@{
            server_launcher = ''
            server_process_name = 'boiii'
            tool_start_delay_seconds = 5
            server_start_timeout_seconds = 90
            launch_ban_service = $true
            launch_geoip = $true
            launch_live_console = $true
        }
    }

    if (-not $config.PSObject.Properties['launch_ban_service']) {
        $config | Add-Member -NotePropertyName launch_ban_service -NotePropertyValue $true
    }
    if (-not $config.PSObject.Properties['launch_geoip']) {
        $config | Add-Member -NotePropertyName launch_geoip -NotePropertyValue $true
    }
    if (-not $config.PSObject.Properties['launch_live_console']) {
        $config | Add-Member -NotePropertyName launch_live_console -NotePropertyValue $true
    }

    $launcherPath = Resolve-ServerLauncherPath -Requested $ServerLauncher -Root $serverRootPath -Config $config
    $relativeLauncher = $launcherPath
    if ($launcherPath.StartsWith($serverRootPath, [System.StringComparison]::OrdinalIgnoreCase)) {
        $relativeLauncher = $launcherPath.Substring($serverRootPath.Length).TrimStart('\')
    }
    $config.server_launcher = $relativeLauncher
    Write-Utf8NoBom -Path $localPath -Content ($config | ConvertTo-Json -Depth 6)

    Write-Host "============================================================" -ForegroundColor DarkCyan
    Write-Host " PinteMod v2.1.0" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor DarkCyan
    Write-Host " Server root : $serverRootPath" -ForegroundColor Gray
    Write-Host " Launcher    : $launcherPath" -ForegroundColor Gray
    Write-Host " RCON        : configured locally" -ForegroundColor Green
    Write-Host ""

    if (-not $ServerOnly -and [bool]$config.launch_ban_service) {
        $p = Start-PinteModTool -ScriptPath (Join-Path $toolsRoot 'PinteMod_Ban_Service.ps1') -Title 'Ban Service'
        if ($p) {
            $toolProcesses.Add($p) | Out-Null
            Write-Host "[OK] Ban Service started before BOIII." -ForegroundColor Green
            Start-Sleep -Milliseconds 750
        }
    }

    $processName = [string]$config.server_process_name
    if ([string]::IsNullOrWhiteSpace($processName)) { $processName = 'boiii' }
    $existingIds = @((Get-Process -Name $processName -ErrorAction SilentlyContinue).Id)

    $quotedLauncher = '"' + $launcherPath + '"'
    $serverLauncherProcess = Start-Process -FilePath 'cmd.exe' -ArgumentList @('/c', $quotedLauncher) -WorkingDirectory (Split-Path -Parent $launcherPath) -PassThru
    Write-Host "[OK] BOIII server launcher started." -ForegroundColor Green

    $delay = [int]$config.tool_start_delay_seconds
    if ($delay -lt 0) { $delay = 0 }
    Start-Sleep -Seconds $delay

    if (-not $ServerOnly -and [bool]$config.launch_geoip) {
        $p = Start-PinteModTool -ScriptPath (Join-Path $toolsRoot 'PinteMod_GeoIP_Bridge.ps1') -Title 'GeoIP bridge'
        if ($p) { $toolProcesses.Add($p) | Out-Null; Write-Host "[OK] GeoIP bridge started." -ForegroundColor Green }
    }
    if (-not $ServerOnly -and [bool]$config.launch_live_console) {
        $p = Start-PinteModTool -ScriptPath (Join-Path $toolsRoot 'PinteMod_LiveConsole.ps1') -Title 'Live Console'
        if ($p) { $toolProcesses.Add($p) | Out-Null; Write-Host "[OK] Live Console started." -ForegroundColor Green }
    }

    $timeout = [int]$config.server_start_timeout_seconds
    if ($timeout -lt 10) { $timeout = 10 }
    $deadline = (Get-Date).AddSeconds($timeout)
    $serverProcess = $null
    do {
        $serverProcess = Get-Process -Name $processName -ErrorAction SilentlyContinue |
            Where-Object { $_.Id -notin $existingIds } |
            Select-Object -First 1
        if ($serverProcess) { break }
        if ($serverLauncherProcess.HasExited) {
            Start-Sleep -Milliseconds 500
        } else {
            Start-Sleep -Seconds 1
        }
    } while ((Get-Date) -lt $deadline)

    if ($serverProcess) {
        Write-Host "[OK] Monitoring server process PID $($serverProcess.Id)." -ForegroundColor Green
        Wait-Process -Id $serverProcess.Id
    }
    elseif (-not $serverLauncherProcess.HasExited) {
        Write-Host "[WARN] BOIII process name was not detected; monitoring the server launcher instead." -ForegroundColor Yellow
        Wait-Process -Id $serverLauncherProcess.Id
    }
    else {
        Write-Host "[WARN] The server launcher exited before a '$processName' process was detected." -ForegroundColor Yellow
        Write-Host "PinteMod tools will stay open. Press Ctrl+C here to close the tools." -ForegroundColor Gray
        while ($true) { Start-Sleep -Seconds 2 }
    }
}
finally {
    foreach ($process in $toolProcesses) {
        try {
            if ($process -and -not $process.HasExited) { Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue }
        }
        catch { }
    }
    if ($mutex) { $mutex.ReleaseMutex() | Out-Null; $mutex.Dispose() }
}
