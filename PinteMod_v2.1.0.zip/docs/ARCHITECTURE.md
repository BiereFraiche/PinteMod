# PinteMod v2.1.0 architecture

## Public installation layout

- `Launch_PinteMod_Server.bat`: local all-in-one launcher at the server root.
- `Launch_PinteMod_Server_Only.bat`: BOIII-only launcher.
- `Launch_PinteMod_Remote_Tools.bat`: remote/VM administration tools launcher.
- `boiii/custom_scripts/`: server-side GSC modules.
- `boiii/tools/`: PowerShell services and read-only operator tools.
- `docs/`: French installation, deployment, moderation and validation guides.

## Runtime modules

- `ezz_admin_config.gsc`: public defaults and bootstrap Owner XUID.
- `ezz_admin_identity.gsc`: authoritative BOIII_XUID identity and persistent roles.
- `ezz_admin_storage.gsc`: validated JSON writes with temporary and backup recovery.
- `ezz_admin_registry.gsc`: shared maps, permissions and command metadata.
- `ezz_admin_community.gsc`: votes, Spawn/Late Join, presence and public workflow.
- `ezz_admin_ranks.gsc`: persistent ranks and map records.
- `ezz_admin_ee_records.gsc`: EE profiles, candidates and official records.
- `ezz_admin_localization.gsc`: per-recipient FR/EN/ES text and language persistence.
- `ezz_admin_bans.gsc`: role checks, XUID ban requests, join rejection and console/Chat commands.

## Local services

- `PinteMod_Ban_Service.ps1`: UTC expiration, active XUID markers and ban history. No IP storage.
- `PinteMod_GeoIP_Bridge.ps1`: RCON/IP-to-country bridge; addresses are processed in memory only.
- `PinteMod_LiveConsole.ps1`: read-only managed-log viewer with a Ban filter.
- `PinteMod_Server_Launcher.ps1`: first-run RCON setup and process orchestration.
- `PinteMod_Remote_Tools_Launcher.ps1`: VM/LAN/VPN tools orchestration.

## Ban request flow

1. Owner/Admin requests a ban through console or Chat.
2. GSC verifies actor role, target hierarchy, self-ban and protected Owner rules.
3. GSC writes a local request under `scriptdata/pintemod/bans/requests/`.
4. Ban Service timestamps the record in UTC, persists `bans.json` and creates an active marker by XUID.
5. GSC kicks a connected target or rejects the XUID on a future connection.
6. Ban Service removes temporary markers when their UTC expiration is reached.

## Local-only data

Runtime data belongs under `boiii/scriptdata/pintemod/` and is intentionally absent from the public package. RCON secrets, DPAPI payloads and `*.local.json` files are also excluded.
